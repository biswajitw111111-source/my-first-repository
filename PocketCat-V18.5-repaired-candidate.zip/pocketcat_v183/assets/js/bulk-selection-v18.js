(() => {
 'use strict';
 const formats=['zip','tar','tar.gz','tar.bz2','7z','rar','tar.xz','gz','bz2','xz'];
 const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
 const csrf=()=>window.POCKETCAT_CSRF||window.FILE_PAGE?.csrf||window.CSRF||document.querySelector('input[name="_csrf"]')?.value||'';
 const ids=()=>$$('.file-select:checked').map(x=>Number(x.value)).filter(Boolean);
 const mediaIds=()=>$$('.media-check:checked').map(x=>Number(x.value)).filter(Boolean);
 function setupBar(bar,checks,scope,publicShare=''){
   if(!bar)return;bar.dataset.selectionBar='1';
   const selectAll=document.createElement('button');selectAll.type='button';selectAll.className='btn small secondary';selectAll.textContent='Select all';selectAll.dataset.bulkSelectAll='';
   const clear=document.createElement('button');clear.type='button';clear.className='btn small secondary';clear.textContent='Deselect all';clear.dataset.bulkClear='';
   const count=document.createElement('span');count.className='bulk-action-status';count.setAttribute('aria-live','polite');
   const mode=document.createElement('select');mode.setAttribute('aria-label','Download mode');mode.innerHTML='<option value="original">Original format</option><option value="unified" selected>One unified archive</option><option value="separate">Separate archives</option>';
   const fmt=document.createElement('select');fmt.setAttribute('aria-label','Archive format');fmt.innerHTML=formats.map(f=>`<option value="${f}" ${f==='zip'?'selected':''}>.${f}</option>`).join('');
   const dl=document.createElement('button');dl.type='button';dl.className='btn small';dl.textContent='Download';
   const spacer=document.createElement('span');spacer.className='selection-spacer';
   bar.append(selectAll,clear,count,spacer);
   if(scope==='files'){
     const del=$('#deleteSelected');if(del)del.textContent='Quick bulk delete';
   } else if(scope==='media'){
     const del=$$('.media-bulkbar button').find(b=>/Delete selected/i.test(b.textContent));if(del)del.textContent='Quick bulk delete';
   }
   const menu=document.createElement('div');menu.className='bulk-download-menu';menu.append(mode,fmt,dl);bar.appendChild(menu);mode.addEventListener('change',()=>{fmt.disabled=mode.value==='original';});
   function update(){const selected=checks().filter(x=>x.checked);bar.classList.toggle('is-visible',selected.length>0);count.textContent=`${selected.length} item${selected.length===1?'':'s'} selected`;selectAll.disabled=!checks().length;}
   selectAll.addEventListener('click',()=>{checks().forEach(x=>x.checked=true);update()});clear.addEventListener('click',()=>{checks().forEach(x=>x.checked=false);update()});checks().forEach(x=>x.addEventListener('change',update));
   dl.addEventListener('click',async()=>{
     const selected=checks().filter(x=>x.checked).map(x=>Number(x.value)).filter(Boolean);if(!selected.length)return;
     if(mode.value==='original'||mode.value==='separate'){
       for(const id of selected){const payload={ids:[id],mode:mode.value==='original'?'original':'unified',format:fmt.value};if(scope==='media')payload.source='media';if(publicShare)payload.share_token=publicShare;await streamDownload(payload,mode.value==='original'?null:`${fmt.value}`);}
     }else{const payload={ids:selected,mode:mode.value,format:fmt.value};if(scope==='media')payload.source='media';if(publicShare)payload.share_token=publicShare;await streamDownload(payload);}
   });update();
 }
 async function streamDownload(payload){
   const btn=$$('.bulk-download-menu button').find(b=>b.textContent==='Download');if(btn)btn.disabled=true;
   try{const r=await fetch('/api/bulk-download.php',{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf()},credentials:'same-origin',body:JSON.stringify(payload)});if(!r.ok){const t=await r.text();throw Error(t||'Download failed');}const blob=await r.blob();const cd=r.headers.get('Content-Disposition')||'';const m=cd.match(/filename="?([^";]+)"?/i);const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=m?m[1]:'pocketcat-download.'+payload.format;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),30000);}catch(e){alert(e.message||'Download failed.')}finally{if(btn)btn.disabled=false;}
 }
 document.addEventListener('DOMContentLoaded',()=>{
   const fileBar=$('.bulk-bar');if(fileBar){setupBar(fileBar,()=>$$('.file-select'),'files');$('#selectAllFiles')?.addEventListener('change',e=>{$$('.file-select').forEach(x=>x.checked=e.target.checked);fileBar.querySelector('[data-bulk-clear]')?.click();if(e.target.checked)fileBar.querySelector('[data-bulk-select-all]')?.click()});}
   const mediaBar=$('.media-bulkbar');if(mediaBar){setupBar(mediaBar,()=>$$('.media-check'),'media');$('#selectAll')?.addEventListener('change',e=>{$$('.media-check').forEach(x=>x.checked=e.target.checked);mediaBar.querySelector('[data-bulk-select-all]')?.click()});}
   const pubBar=$('.public-bulkbar');if(pubBar)setupBar(pubBar,()=>$$('.public-file-select'),'public',window.PUBLIC_SHARE_TOKEN||'');
 });
})();
