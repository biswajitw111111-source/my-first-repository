# PocketCat V11.45 — Code Editor Cancel Button Removal

- Removed the standalone top-level `Cancel` button from Live Code Editor Pro.
- Removed its obsolete JavaScript event handling and CSS.
- Kept the existing `Edit Code` toggle, which changes to `Cancel Edit` while editing and safely restores the original code/title.
- Kept the History panel `Cancel` control for bulk-selection mode.
