# PocketCat V18.5 — Universal paths and guarded OTA updates

## Implemented
- Added `includes/path-resolver.php`, anchored to the real application directory and independently resolving the server document root when available.
- Centralized the core local file-storage and upload-engine directory roots, with symlink and path-boundary checks.
- Added an administrator-only OTA dashboard at `/admin/updates/`, wired into existing admin navigation and CSRF/auth conventions.
- Added package signature verification using Ed25519 (libsodium), SHA-256 file inventory validation, compatibility checks, protected-path filtering, ZIP/TAR capability detection, isolated staging, archive limits, a protected backup, a durable update journal, exclusive lock, and best-effort rollback of replaced/new files.
- Added redacted structured JSONL updater logs and an error details panel with a real clipboard copy action and manual-select fallback.
- Updated `VERSION` from the stale `17.8` value to `18.5` for the delivered release.

## Package contract
A signed package is a ZIP or TAR container containing `manifest.json`, `manifest.sig`, and `files/<relative-path>` entries. `manifest.sig` is base64 Ed25519 detached signature over the exact bytes of `manifest.json`. The manifest must contain `format_version: 1`, `application: "PocketCat"`, `target_version` greater than the installed version (the V18.5 release package uses `18.5`), `min_source_version`, `max_source_version`, and a `files` object mapping relative paths to SHA-256 hex digests. The trusted public key is a base64-encoded 32-byte Ed25519 public key in the private updater directory at `updates/update-public-key.pem` (the updater directory is placed outside the public document root when the hosting layout permits it). No private signing key belongs on the website.

## Important limitations
- The current package environment did not include `ZipArchive`, `PDO_MYSQL`, `bz2`, or `xz` extensions. ZIP/TAR update installation was therefore not verified in this environment. The updater reports missing capabilities and rejects unsupported formats rather than pretending they work.
- The updater intentionally rejects package-declared database migrations until a project-specific migration runner and isolated database verification are available. It does not remove files declared absent from a package.
- The public key must be provisioned securely out-of-band before any package can pass validation. No trusted key is generated or embedded automatically.
- PHP syntax validation relies on the host PHP CLI being available and callable. If unavailable, packages containing PHP files fail validation rather than silently skipping syntax checks.
- Atomic multi-file deployment is not available on ordinary shared hosting. The implementation uses a lock, verified per-file backup, write-ahead journal, controlled replacement, best-effort rollback, and hash-verified recovery for interrupted updates; ambiguous recovery states require manual review.
- End-to-end production regression, live DB, mobile browser, and all-format tests require the target hosting environment and an isolated test database; they are not claimed as passed here.
