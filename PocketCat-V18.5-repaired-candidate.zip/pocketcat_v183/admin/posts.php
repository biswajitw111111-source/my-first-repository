<?php $_GET['type']='post'; require __DIR__.'/content-list.php';
