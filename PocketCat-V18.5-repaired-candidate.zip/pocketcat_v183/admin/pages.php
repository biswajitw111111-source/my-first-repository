<?php $_GET['type']='page'; require __DIR__.'/content-list.php';
