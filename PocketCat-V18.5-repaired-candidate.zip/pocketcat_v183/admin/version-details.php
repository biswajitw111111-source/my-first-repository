<?php
require __DIR__.'/../bootstrap.php';
require_admin();

$root=dirname(__DIR__);
$versionFile=$root.'/VERSION';
$currentVersion=trim((string)@file_get_contents($versionFile));
if($currentVersion===''){$currentVersion='18.5';}
$releaseFile=$root.'/CHANGELOG-V18.5-UNIVERSAL-PATHS-OTA.md';
$releaseText=is_file($releaseFile)?trim((string)@file_get_contents($releaseFile)):'';
$releaseDate='2026-10-03';
$title='Version Details';
require __DIR__.'/../includes/header.php';
?>
<div class="page-head version-details-head">
  <div>
    <span class="eyebrow">Administration · Release Management</span>
    <h1>Version details</h1>
    <p>Current PocketCat release with the V18.5 universal path resolution, guarded OTA updates, protected backups and rollback diagnostics.</p>
  </div>
  <div class="version-current-badge"><span>Current version</span><strong>V<?=e($currentVersion)?></strong></div>
</div>
<section class="card version-release-card">
  <div class="page-head">
    <div>
      <span class="eyebrow">Current release</span>
      <h2>PocketCat V<?=e($currentVersion)?></h2>
      <p class="muted">Release details are bundled with this deployment so the admin panel remains self-documenting.</p>
    </div>
    <span class="planned release-live">CURRENT</span>
  </div>
  <div class="version-meta-grid">
    <div><span>Version</span><strong>V<?=e($currentVersion)?></strong></div>
    <div><span>Release date</span><strong><?=e($releaseDate)?></strong></div>
    <div><span>Release file</span><strong><?=e(basename($releaseFile))?></strong></div>
    <div><span>Scope</span><strong>V18.4 → V18.5</strong></div>
  </div>
</section>
<section class="card version-changes-card">
  <div class="page-head">
    <div><span class="eyebrow">V18.5 · V18.4 → V18.5</span><h2>All V18.5 changes</h2><p class="muted">Release notes describe the current path management and guarded OTA updater changes.</p></div>
    <a class="btn small secondary" href="/admin/">Admin Dashboard</a>
  </div>
  <?php if($releaseText!==''): ?>
    <pre class="version-notes"><?=e($releaseText)?></pre>
  <?php else: ?>
    <p class="muted">V18.5 release notes are not available.</p>
  <?php endif; ?>
</section>
<?php require __DIR__.'/../includes/footer.php'; ?>
