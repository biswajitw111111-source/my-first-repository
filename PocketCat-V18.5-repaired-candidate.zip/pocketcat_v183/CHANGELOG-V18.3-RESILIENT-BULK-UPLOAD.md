# PocketCat V18.3 — Resilient Bulk Upload

## Changelog

- **File Storage & Sharing uploader** → transient network/server failures previously surfaced as terminal errors and retry/cancel state could lose progress → added bounded exponential auto-retry, verified-offset probing after uncertain chunk responses, pause/resume, bulk selection actions, remove-from-queue handling, inline missing-file recovery, and non-blocking completion toasts.
- **Media Library uploader** → retries initialized new sessions, cancellation discarded the token, and successful uploads reloaded the page → preserve the resumable session and server-confirmed offset, recover transient errors automatically, add pause/resume and selected batch actions, create media cards in-place after server finalization, update counters, and remove the upload page reload.
- **Chunk upload API** → a lost completion response could make a completed session unrecoverable → status can report completed sessions and repeated media completion returns the existing media asset when already persisted.
- **Mobile/accessibility** → dense queue controls and long paths could overflow narrow layouts → responsive wrapping, touch-friendly controls, live status/toast announcements, focus-visible styles inherited from the existing design system, and inline missing-file warnings.
- **Versioning** → V18.2 asset cache references could keep old uploader scripts loaded → bumped relevant asset cache versions to V18.3.

## Compatibility and safety

- Uses the existing `/api/files.php` upload/storage implementation and `/api/upload-chunk.php` resumable media upload protocol; no separate upload storage is introduced.
- Existing server-side login, CSRF, ownership, upload policy, file type checks, and path sanitization remain authoritative.
- Upload binaries are not stored in localStorage. Existing folder structure, share/download APIs, public URL creation, and media management remain in place.

## Validation performed

- JavaScript syntax checks for the File Storage uploader and Media Library inline uploader.
- PHP syntax checks for `files/index.php`, `media/index.php`, and `api/upload-chunk.php`.
- Static review of upload completion and retry paths, including lost chunk responses and repeated media completion.

## Deployment note

This patch reuses the existing `upload_sessions` schema. Ensure the current V18.2 database migrations have been applied before deployment. End-to-end network-fault testing should also be performed on the target hosting/storage provider because this archive does not include live credentials or a production database.
