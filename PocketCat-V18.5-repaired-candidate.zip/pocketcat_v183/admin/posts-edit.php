<?php $_GET['type']='post'; require __DIR__.'/content-edit.php';
