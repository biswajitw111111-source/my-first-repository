# V10.2
- Added standalone Code Editor / Code Sharing module.
- Added worker-based Prism highlighting.
- Added responsive day/night editor, size modes, statistics, live preview, export, share, history, pagination, search highlighting, bulk deletion and forking.
- Added code snippet version storage, categories, privacy, password protection, expiry and view-once behavior.
- Added dynamic QR route for code share pages.
