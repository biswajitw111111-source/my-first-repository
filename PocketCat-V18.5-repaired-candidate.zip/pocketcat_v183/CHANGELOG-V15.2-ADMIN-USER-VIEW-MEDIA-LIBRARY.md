# PocketCat V15.2 — Admin User View Media Library Fix

- Admin accounts now see the **Media Library** in the normal User View.
- Admin View continues to hide the user Media Library option.
- `/media/` remains blocked while Admin View is active, but is available when the admin switches to User View.
- Media resumable uploads follow the same User View/Admin View rule.
- Existing Admin CMS media management remains separate under `/admin/media/`.
