# PocketCat V11.40 — Historical Analytics Release

This document records the original V11.40 analytics implementation. Review Analytics / Review Intelligence was subsequently removed in V11.43; the current product contains Advanced Website Analytics & Tracking only.
