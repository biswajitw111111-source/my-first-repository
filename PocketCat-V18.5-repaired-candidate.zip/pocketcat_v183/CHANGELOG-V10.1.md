# PocketCat V10.1 — Unified Governance

- Added database-backed Dynamic Policy Engine.
- Added configurable Free/Basic/Premium URL + file capability matrix.
- Added real-time request-time policy evaluation.
- Added emergency feature kill switches and global infrastructure controls.
- Added white-label policy metadata.
- Added IP/CIDR/country governance rules.
- Added central link/file registry and global moderation actions.
- Added per-user quota/feature overrides.
- Added custom admin RBAC roles.
- Added secure support impersonation with audit trail.
- Added password reset-link generation from Super Admin.
- Added user tier/status governance and asset purge.
- Added API token revocation governance.
- Added failed webhook delivery visibility.
- Added policy and impersonation audit tables.
- Added dynamic retention cleanup for link/file analytics.
- Added runtime enforcement to URL and file endpoints.
- Added magic-byte MIME gate to the background file scan worker.
