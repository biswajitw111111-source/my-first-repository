<?php
declare(strict_types=1);

/** Central filesystem boundary for PocketCat. The application root is anchored to this file,
 * never to the request working directory or an assumed hosting document-root name. */
final class PocketCatPaths {
    private static ?string $appRoot = null;
    public static function appRoot(): string {
        if (self::$appRoot === null) {
            $root = realpath(dirname(__DIR__));
            if ($root === false || !is_dir($root)) throw new RuntimeException('Application root could not be resolved safely.');
            self::$appRoot = rtrim($root, DIRECTORY_SEPARATOR);
        }
        return self::$appRoot;
    }
    public static function publicRoot(): ?string {
        $doc = (string)($_SERVER['DOCUMENT_ROOT'] ?? '');
        if ($doc === '') return null;
        $real = realpath($doc);
        return $real !== false && is_dir($real) ? rtrim($real, DIRECTORY_SEPARATOR) : null;
    }
    public static function uploadRoot(): string {
        $app=self::appRoot();$legacy=$app.'/uploads';if(is_link($legacy))throw new RuntimeException('The application uploads directory is a symbolic link; storage writes are blocked for safety.');if(is_dir($legacy))return $legacy;
        $public=self::publicRoot();if($public!==null&&$public!==$app){$publicUploads=$public.'/uploads';if(is_link($publicUploads))throw new RuntimeException('The public uploads directory is a symbolic link; storage writes are blocked for safety.');return $publicUploads;}
        return $legacy;
    }
    public static function privateRoot(): string {
        $app=self::appRoot();$public=self::publicRoot();
        if($public===null) return $app.'/storage';
        if($app===$public || str_starts_with($app,rtrim($public,'/\\').DIRECTORY_SEPARATOR)) return dirname($public).'/.pocketcat-private-'.substr(hash('sha256',$app),0,12);
        return $app.'/storage';
    }
    public static function path(string $area, string $relative = ''): string {
        $private=self::privateRoot();
        $roots = [
            'app' => self::appRoot(), 'public' => self::publicRoot(),
            'assets' => self::appRoot().'/assets', 'storage' => self::appRoot().'/storage',
            'uploads' => self::uploadRoot(), 'files' => self::uploadRoot().'/files',
            'media' => self::uploadRoot().'/media', 'temp' => self::appRoot().'/storage/tmp',
            'updates' => $private.'/updates', 'staging' => $private.'/updates/staging',
            'packages' => $private.'/updates/packages', 'backups' => $private.'/updates/backups',
            'logs' => $private.'/updates/logs', 'locks' => $private.'/updates/locks',
            'config' => self::appRoot().'/config.php', 'database' => self::appRoot().'/database'
        ];
        if (!array_key_exists($area, $roots) || $roots[$area] === null) throw new RuntimeException('Requested filesystem location is not available.');
        $base = rtrim((string)$roots[$area], '/\\');
        if ($relative === '') return $base;
        if (str_contains($relative, "\0") || str_starts_with($relative, '/') || str_starts_with($relative, '\\\\') || preg_match('/^[A-Za-z]:/', $relative)) throw new RuntimeException('Unsafe relative path rejected.');
        $parts = preg_split('~[\\\\/]~', $relative) ?: [];
        foreach ($parts as $part) if ($part === '' || $part === '.' || $part === '..') throw new RuntimeException('Unsafe relative path segment rejected.');
        $candidate = $base.DIRECTORY_SEPARATOR.implode(DIRECTORY_SEPARATOR, $parts);
        self::assertWithin($candidate, $base);
        return $candidate;
    }
    public static function assertWithin(string $candidate, string $base): void {
        $baseReal = realpath($base);
        $parent = is_dir($candidate) ? $candidate : dirname($candidate);
        while (!file_exists($parent) && dirname($parent) !== $parent) $parent = dirname($parent);
        $parentReal = realpath($parent);
        if ($parentReal === false) throw new RuntimeException('Filesystem parent cannot be resolved.');
        $boundary = $baseReal !== false ? rtrim($baseReal, '/\\') : rtrim($base, '/\\');
        $prefix = $boundary.DIRECTORY_SEPARATOR;
        if ($parentReal !== $boundary && !str_starts_with($parentReal.DIRECTORY_SEPARATOR, $prefix)) throw new RuntimeException('Filesystem operation would escape its approved directory.');
        if (is_link($candidate)) throw new RuntimeException('Symbolic-link targets are not allowed for sensitive file operations.');
    }
    public static function ensureDir(string $area, int $mode = 0750): string {
        $dir = self::path($area);
        $privateArea=in_array($area,['updates','staging','packages','backups','logs','locks'],true);$uploadArea=in_array($area,['uploads','files','media'],true);
        if($privateArea && self::publicRoot()===null) throw new RuntimeException('Public document root is unavailable; private update storage cannot be guaranteed.');
        $root = $privateArea ? self::privateRoot() : ($uploadArea ? self::uploadRoot() : self::appRoot());
        if($privateArea && !is_dir($root) && !@mkdir($root,0700,true) && !is_dir($root)) throw new RuntimeException('Cannot create a private update directory outside the public document root.');
        if($privateArea && (is_link($root)||!is_writable($root))) throw new RuntimeException('Private update storage is not safely writable.');
        if($uploadArea && !is_dir($root) && !@mkdir($root,0750,true) && !is_dir($root)) throw new RuntimeException('Cannot create the resolved upload root safely.');
        self::assertWithin($dir, $root);
        if (!is_dir($dir) && !@mkdir($dir, $mode, true) && !is_dir($dir)) throw new RuntimeException('Cannot create required directory: '.$area.'. Check hosting write permissions.');
        if (is_link($dir) || !is_writable($dir)) throw new RuntimeException('Required directory is not safely writable: '.$area.'.');
        self::assertWithin($dir, $root);
        return $dir;
    }
}
function pc_path(string $area, string $relative = ''): string { return PocketCatPaths::path($area, $relative); }

/** Resolve a stored public upload URL back to the upload root without trusting its path. */
function pc_upload_path_from_url(string $url): string {
    $path=parse_url($url,PHP_URL_PATH);
    if(!is_string($path)||!str_starts_with($path,'/uploads/')) throw new RuntimeException('Stored asset path is outside the upload namespace.');
    $relative=substr($path,strlen('/uploads/'));
    return PocketCatPaths::path('uploads',$relative);
}
