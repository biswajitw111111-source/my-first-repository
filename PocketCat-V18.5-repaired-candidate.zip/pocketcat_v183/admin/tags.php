<?php $_GET['type']='tag'; require __DIR__.'/taxonomies.php';
