# PocketCat V18.4 — Production Expansion Layer

## Implemented in this package
- Extended the existing file workspace schema using guarded, additive compatibility migrations.
- Added owner-scoped Trash listing, soft-delete, restore with skip/replace/auto-rename conflict policies, and explicit permanent-delete operations.
- Changed single and bulk file deletion to soft-delete so the original storage object is retained until permanent deletion or retention cleanup.
- Added configurable retention cleanup for trashed objects (default 30 days, clamped to 1–90 days) and explicit object-driver handling.
- Added owner-scoped favorites, quota summary, advanced server-side search, paginated activity history, media collections and collection membership APIs.
- Added share revocation through the existing share/link tables; revocation deletes the share manifest and disables the associated short link in the same transaction.
- Added activity records for critical file and collection mutations. Audit metadata filters keys likely to contain tokens, passwords, secrets, URLs, or paths.
- Added a responsive Trash panel to File Storage with restore and permanent-delete actions, accessible status announcements, and CSRF-protected requests.
- Added database indexes and foreign keys for favorites, activity, collections, collection items and idempotency-operation records.

## Database migration
- `database/migration-v18.4-production-expansion.sql` is the additive migration script.
- The existing `ensure_file_workspace_schema()` compatibility routine applies guarded changes for existing installations at bootstrap.
- Existing file objects, folders, media rows, and links are not dropped or rebuilt.

## APIs added (`/api/files.php?action=...`)
- `trash_list`, `trash`, `restore`, `permanent_delete`
- `favorite_toggle`, `favorites`, `quota`, `advanced_search`, `activity`
- `collection_list`, `collection_create`, `collection_rename`, `collection_delete`, `collection_add`, `collection_remove`
- `share_revoke`

All actions use the existing session/API-token authentication boundary; browser POST requests require the existing CSRF header. Resource ownership is checked server-side.

## Security and lifecycle changes
- Normal deletion no longer immediately unlinks the physical object.
- Permanent deletion requires an owner-owned item already in Trash and checks for other file-object references to the object key before deleting storage.
- Trash restore checks path conflicts and never accepts arbitrary filesystem paths from the client.
- Cleanup only permanently removes soft-deleted files after the configured retention period; expired files retain existing expiry cleanup behavior.
- Share revocation disables the related short link and removes the share manifest transactionally.

## Verification
- PHP syntax validation was run for modified PHP entry points and cleanup worker.
- JavaScript syntax validation and full regression/security integration tests are documented as required before deployment; they require a target database, configured storage driver, and browser/network test environment.

## Known limitations / not yet verified
- This is an incremental expansion, not verification of every item in the 112-point request. Version retention and quota reservation/commit, end-to-end SHA-256 integrity scans, orphan reconciliation, session/device management, 2FA/passkey enrollment, archive-bomb defenses, global command palette, and full share-management UI are not complete here.
- Favorite and collection APIs are integrated with the existing canonical file records but dedicated Media Library controls are not yet exposed in the UI.
- The current host environment does not provide the production database or storage credentials; migrations and race-condition behavior must be exercised against a staging clone before release.
- The Trash panel operates without a full-page reload, but the restored file's full preview card is not rehydrated in-place; the existing file listing may need a normal navigation refresh to display it.
