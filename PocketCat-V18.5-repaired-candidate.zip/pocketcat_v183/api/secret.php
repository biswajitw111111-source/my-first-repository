<?php
require __DIR__.'/../bootstrap.php';
require_login();
if($_SERVER['REQUEST_METHOD']!=='POST') json_response(['ok'=>false,'error'=>'POST required.'],405);
$provided=(string)($_SERVER['HTTP_X_CSRF_TOKEN']??$_POST['_csrf']??'');
if(!hash_equals((string)($_SESSION['_csrf']??''),$provided)) json_response(['ok'=>false,'error'=>'Security token expired.'],419);
$u=current_user();
$scope=(string)post('scope',''); $key=(string)post('key','');
$system=['bedrock_api_key','aws_access_key_id','aws_secret_access_key','aws_session_token','bedrock_relay_token','file_storage_access_key','file_storage_secret_key','smtp_password','safe_browsing_api_key'];
$userAi=['bedrock_api_key'=>'bedrock_api_key_encrypted','aws_access_key_id'=>'aws_access_key_encrypted','aws_secret_access_key'=>'aws_secret_key_encrypted','aws_session_token'=>'aws_session_token_encrypted','bedrock_relay_token'=>'relay_token_encrypted'];
if($scope==='system'){
  if(($u['role']??'')!=='admin' || !is_admin_view()) json_response(['ok'=>false,'error'=>'Admin access required.'],403);
  if(!in_array($key,$system,true)) json_response(['ok'=>false,'error'=>'Secret field is not allowed.'],400);
  $value=secret_setting($key,'');
}elseif($scope==='user_ai'){
  if(!isset($userAi[$key])) json_response(['ok'=>false,'error'=>'Secret field is not allowed.'],400);
  $s=db()->prepare('SELECT '.$userAi[$key].' FROM user_ai_settings WHERE user_id=?');$s->execute([(int)$u['id']]);
  $value=decrypt_secret((string)($s->fetchColumn()?:''));
}else json_response(['ok'=>false,'error'=>'Invalid secret scope.'],400);
json_response(['ok'=>true,'configured'=>$value!=='','value'=>$value]);
