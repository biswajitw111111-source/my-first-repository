<?php $_GET['type']='category'; require __DIR__.'/taxonomies.php';
