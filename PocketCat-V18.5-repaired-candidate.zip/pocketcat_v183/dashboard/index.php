<?php
require __DIR__.'/../bootstrap.php';require_login();$u=current_user();$id=$u['id'];
$q=db()->prepare('SELECT COUNT(*) FROM tasks WHERE user_id=?');$q->execute([$id]);$a=(int)$q->fetchColumn();
$q=db()->prepare("SELECT COUNT(*) FROM tasks WHERE user_id=? AND status='Completed'");$q->execute([$id]);$b=(int)$q->fetchColumn();
$q=db()->prepare('SELECT COUNT(*) FROM projects WHERE user_id=?');$q->execute([$id]);$c=(int)$q->fetchColumn();
$q=db()->prepare('SELECT COUNT(*) FROM notes WHERE user_id=?');$q->execute([$id]);$d=(int)$q->fetchColumn();
$q=db()->prepare("SELECT title,status,priority,due_date FROM tasks WHERE user_id=? ORDER BY created_at DESC LIMIT 6");$q->execute([$id]);$recent=$q->fetchAll();
$months=[];for($i=5;$i>=0;$i--){$dt=new DateTime("first day of -{$i} month");$q=db()->prepare("SELECT COUNT(*) FROM tasks WHERE user_id=? AND created_at>=? AND created_at<?");$from=$dt->format('Y-m-d 00:00:00');$to=(clone $dt)->modify('+1 month')->format('Y-m-d 00:00:00');$q->execute([$id,$from,$to]);$months[]=['label'=>$dt->format('M'),'value'=>(int)$q->fetchColumn()];}
$max=max(1,max(array_column($months,'value')));$demo=demo_growth_series();$demoMax=max(1,max(array_column($demo,'value')));
$isAdmin=(current_user()['role']??'')==='admin';$title='Dashboard';require __DIR__.'/../includes/header.php';
?>
<div class="page-head"><?php if($isAdmin): ?><div class="install-note" style="width:100%"><strong>User View</strong> · You are seeing the normal customer dashboard. Use the <a href="/admin/toggle/">Admin</a> button in the top bar when you need administration.</div><?php endif;?><div><span class="eyebrow"><?=e(ui_label("dashboard","Dashboard"))?></span><h1>Good to see you, <?=e($u['full_name'])?>.</h1><p>Your personal overview of tasks, notes and projects.</p></div><a class="btn" href="/tasks/create/">+ New Task</a></div>
<div class="stats"><div class="card stat"><span><?=e(ui_label("tasks","Tasks"))?></span><strong><?=$a?></strong></div><div class="card stat"><span><?=e(ui_label("completed","Completed"))?></span><strong><?=$b?></strong></div><div class="card stat"><span><?=e(ui_label("projects","Projects"))?></span><strong><?=$c?></strong></div><div class="card stat"><span><?=e(ui_label("notes","Notes"))?></span><strong><?=$d?></strong></div></div>
<section class="card" style="margin-bottom:18px"><div class="page-head"><div><h2>6-month user growth demo</h2><p class="muted">Presentation-only sample starting at 10,000 users with 5%, 10%, 15%, 25% and 10% monthly increases.</p></div><span class="planned">DEMO DATA</span></div><div class="chart-wrap large-chart"><?php foreach($demo as $m):$h=max(8,round($m['value']/$demoMax*100));?><div class="chart-col"><span class="chart-value"><?=number_format($m['value'])?></span><div class="bar" style="height:<?=$h?>%"></div><span class="chart-label"><?=e($m['label'])?></span></div><?php endforeach;?></div></section>

<div class="grid-main">
<section class="card"><h2>Your task activity</h2><p class="muted">Tasks created over the last six months.</p><div class="chart-wrap"><?php foreach($months as $m):$h=max(8,round($m['value']/$max*100));?><div class="chart-col"><span class="chart-value"><?=$m['value']?></span><div class="bar" style="height:<?=$h?>%"></div><span class="chart-label"><?=$m['label']?></span></div><?php endforeach;?></div></section>
<section class="card"><h2>Quick actions</h2><div class="quick"><a href="/tasks/create/">Create a task</a><a href="/notes/create/">Write a note</a><a href="/projects/create/">Start a project</a><a href="/ai/">Ask AI</a></div></section>
</div>
<section class="card"><div class="page-head"><div><h2>Recent tasks</h2><p class="muted">Your latest work.</p></div><a class="btn secondary small" href="/tasks/">View all</a></div>
<?php if(!$recent):?><p class="muted">No tasks yet. Create your first task to get started.</p><?php else:foreach($recent as $t):?><div style="display:flex;justify-content:space-between;gap:15px;padding:13px 0;border-bottom:1px solid var(--line)"><div><strong><?=e($t['title'])?></strong><div class="muted"><?=e($t['status'])?> · <?=e($t['priority'])?></div></div><a href="/tasks/edit/?id=<?=$t['id']?>">Edit</a></div><?php endforeach;endif;?></section>
<?php require __DIR__.'/../includes/footer.php'; ?>
