# PocketCat V11.5 — Enterprise Navigation Menu Manager

- Added normalized navigation menu storage with Header/Footer/Sidebar locations.
- Added accessible admin manager with accordion source selectors and three-dot contextual actions.
- Added button-driven Move Up/Down, Indent/Outdent, property editing and unlink/remove.
- Added page, post and category source discovery.
- Added custom links with target/nofollow support.
- Added quick page creation and draft post creation.
- Added optimistic version checking and transactional persistence.
- Added public header/footer integration with safe fallback navigation.
- Added small built-in CMS post/category fallback so quick-created items have a real persistence path when no existing post tables are present.
- Added responsive/touch-friendly styling and keyboard Escape action closing.
