<?php
declare(strict_types=1);
require __DIR__.'/support-chat.php';
