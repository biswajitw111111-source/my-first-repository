# PocketCat V11.29 — Responsive AI Users & Billing Fix

- Customer AI Access now changes from the oversized 15-column table into stacked customer cards on narrow/tablet widths.
- Added explicit field labels to every responsive AI credential/configuration cell.
- Credential/status boxes and action buttons no longer collapse into single-character vertical columns.
- Billing uses content-aware 3/2/1 column behavior so desktop-site mode on phones does not squeeze three cards into a narrow content area.
- Active plan is rendered as a disabled Current plan button and clearly marked as Your current plan.
- Payment methods remain two-column where there is room and one-column on small phones.
