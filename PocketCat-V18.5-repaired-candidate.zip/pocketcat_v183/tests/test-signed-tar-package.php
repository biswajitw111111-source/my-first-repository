<?php
declare(strict_types=1);
$_SERVER['DOCUMENT_ROOT']=realpath(dirname(__DIR__));
function current_user(): array { return ['id'=>0]; }
require __DIR__.'/../includes/path-resolver.php';
require __DIR__.'/../includes/ota-updater.php';
$root=PocketCatPaths::appRoot();$hadStorage=is_dir($root.'/storage');$tmp=sys_get_temp_dir().'/pc-signed-tar-'.bin2hex(random_bytes(5));mkdir($tmp,0700,true);
$private=PocketCatPaths::privateRoot();$hadPrivate=is_dir($private);$keyFile=$private.'/updates/update-public-key.pem';$oldKey=is_file($keyFile)?file_get_contents($keyFile):null;$stage='';
try {
 if(!is_dir(dirname($keyFile))&&!mkdir(dirname($keyFile),0700,true))throw new RuntimeException('cannot create private test directory');
 $pair=sodium_crypto_sign_keypair();$pub=sodium_crypto_sign_publickey($pair);$sec=sodium_crypto_sign_secretkey($pair);file_put_contents($keyFile,base64_encode($pub));
 $version="18.6\n";$payload="safe update test\n";$files=['VERSION'=>hash('sha256',$version),'test-update.txt'=>hash('sha256',$payload)];
 $manifest=['format_version'=>1,'application'=>'PocketCat','source_version'=>'18.5','min_source_version'=>'18.5','max_source_version'=>'18.5','target_version'=>'18.6','release_id'=>'test-only','build_timestamp'=>gmdate('c'),'files'=>$files,'migrations'=>[]];$raw=json_encode($manifest,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);$sig=base64_encode(sodium_crypto_sign_detached($raw,$sec));
 $tarPath=$tmp.'/signed.tar';$tar=new PharData($tarPath);$tar->addFromString('manifest.json',$raw);$tar->addFromString('manifest.sig',$sig);$tar->addFromString('files/VERSION',$version);$tar->addFromString('files/test-update.txt',$payload);unset($tar);
 $badPath=$tmp.'/bad-signature.tar';$bad=new PharData($badPath);$bad->addFromString('manifest.json',$raw);$bad->addFromString('manifest.sig',base64_encode(str_repeat('x',64)));$bad->addFromString('files/VERSION',$version);$bad->addFromString('files/test-update.txt',$payload);unset($bad);$badRejected=false;try{PocketCatUpdater::inspect($badPath);}catch(Throwable $expected){$badRejected=str_contains($expected->getMessage(),'signature');}if(!$badRejected)throw new RuntimeException('Invalid package signature was not rejected.');echo "PASS invalid Ed25519 signature rejected before installation\n";
 $result=PocketCatUpdater::inspect($tarPath);$stage=$result['stage'];if($result['target_version']!=='18.6'||$result['added']!==['test-update.txt']||$result['modified']!==['VERSION'])throw new RuntimeException('Preview did not match expected signed package inventory.');echo "PASS signed TAR package signature, hashes, version checks, extraction and preview\n";
 $gzPath=$tmp.'/signed.tar.gz';file_put_contents($gzPath,gzencode((string)file_get_contents($tarPath)));$gzResult=PocketCatUpdater::inspect($gzPath);if($gzResult['format']!=='tar.gz'||$gzResult['target_version']!=='18.6')throw new RuntimeException('TAR.GZ preview failed.');PocketCatUpdater::discardStage($gzResult['stage']);echo "PASS signed TAR.GZ package signature, extraction and preview\n";
 $fixtureRel='tests/.recovery-fixture.txt';$fixture=$root.'/'.$fixtureRel;if(is_file($fixture))throw new RuntimeException('Recovery fixture already exists.');$backupName='recovery-fixture';$backupDir=pc_path('backups',$backupName);mkdir($backupDir,0700);mkdir($backupDir.'/tests',0700);file_put_contents($backupDir.'/'.$fixtureRel,"previous state\n");file_put_contents($fixture,"updated state\n");$journal=['operation_id'=>'recovery-test','state'=>'installing','backup'=>$backupName,'planned'=>[$fixtureRel],'created'=>[],'expected_hashes'=>[$fixtureRel=>hash('sha256',"updated state\n")]];file_put_contents(pc_path('updates','journal.json'),json_encode($journal));$recovery=PocketCatUpdater::recoverInterrupted();if(($recovery['status']??'')!=='recovered'||file_get_contents($fixture)!=="previous state\n")throw new RuntimeException('Interrupted update recovery failed to restore the verified backup.');echo "PASS interrupted-update recovery restores a hash-verified backup\n";@unlink($fixture);@unlink($backupDir.'/tests/.recovery-fixture.txt');@rmdir($backupDir.'/tests');@rmdir($backupDir);@unlink(pc_path('updates','journal.json'));
} catch(Throwable $e){fwrite(STDERR,"FAIL signed TAR package: ".$e->getMessage()."\n");exitCode: { $GLOBALS['pc_test_failed']=1; }}
finally {
 if($stage!=='')PocketCatUpdater::discardStage($stage);
 if($oldKey===null)@unlink($keyFile);else @file_put_contents($keyFile,$oldKey);
 if(!$hadPrivate){$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($private,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST);foreach($it as $f){$f->isDir()&&!$f->isLink()?@rmdir($f->getPathname()):@unlink($f->getPathname());}@rmdir($private);}
 foreach(glob($tmp.'/*')?:[] as $f)@unlink($f);@rmdir($tmp);
 if(!$hadStorage){@rmdir($root.'/storage/tmp');@rmdir($root.'/storage');}
}
if(!empty($GLOBALS['pc_test_failed']))exit(1);
