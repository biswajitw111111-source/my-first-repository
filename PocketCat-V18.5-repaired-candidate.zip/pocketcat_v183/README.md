# PocketCat V18.5 — Universal Paths & Guarded OTA Updates

This release adds centralized filesystem path resolution, upload-root selection for split application/public roots, hardened media archive extraction, and an administrator-only signed-package OTA updater with change previews, protected paths, verified file backups, an update journal, hash-verified interrupted-update recovery, and redacted diagnostics.

The existing PHP application, authentication, MySQL/PDO layer, File Storage & Sharing, Media Library, Links & Analytics, and user-generated data models are retained. No database schema migration is required for the path-management changes. The OTA updater deliberately rejects packages declaring database migrations until a project-specific migration runner and isolated DB verification are available.

- Release notes: `CHANGELOG-V18.5-UNIVERSAL-PATHS-OTA.md`
- OTA package format, key setup, hosting requirements and recovery: `docs/V18.5-OTA-OPERATIONS.md`
- Actual packaging-environment checks and limitations: `QA-REPORT-V18.5.md`
- Administrator updater: `/admin/updates/`

**Deployment note:** This is a guarded, capability-aware updater, not a claim of universal archive support. Provision the Ed25519 public key out-of-band, confirm the host has required extensions and private writable storage, and test on a staging copy with a separate database before production use. Unsupported formats or unsafe host layouts are rejected.
