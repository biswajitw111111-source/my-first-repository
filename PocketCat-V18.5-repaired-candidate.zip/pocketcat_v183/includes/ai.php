<?php
function ai_estimate_units(string $text):int{
    $text=trim($text); if($text==='')return 1;
    preg_match_all('/\S+/u',$text,$m); return max(1,count($m[0]));
}
function ai_usage_limits(?array $u=null):array{
    $u=$u?:current_user();$p=plan_limits((string)($u['plan']??'free'));
    return ['seconds'=>(int)$p['ai_seconds']];
}
function ai_usage_limit():int{return ai_usage_limits()['seconds'];}
function ai_usage(int $uid):array{
    try{
        $s=db()->prepare('SELECT active_seconds FROM ai_usage_daily WHERE user_id=? AND usage_date=CURDATE()');$s->execute([$uid]);$r=$s->fetch();
        return $r?:['active_seconds'=>0];
    }catch(Throwable $e){return ['active_seconds'=>0];}
}
function ai_is_premium(?array $u=null):bool{$u=$u?:current_user();return function_exists('policy_testing_mode')&&policy_testing_mode() || ($u&&((($u['role']??'')==='admin')||(($u['plan']??'free')==='premium')));}
function ai_seconds_remaining(int $uid,?array $u=null):float{
    $u=$u?:current_user();if(ai_is_premium($u))return INF;
    $lim=ai_usage_limits($u)['seconds'];$x=ai_usage($uid);return max(0.0,$lim-(float)($x['active_seconds']??0));
}
function ai_input_remaining(int $uid,?array $u=null):int{ $x=ai_seconds_remaining($uid,$u); return is_infinite($x)?PHP_INT_MAX:(int)floor($x); }
function ai_output_remaining(int $uid,?array $u=null):int{ return ai_input_remaining($uid,$u); }
function ai_remaining(int $uid,?array $u=null):int{return ai_input_remaining($uid,$u);}
function ai_remaining_label(int $uid,?array $u=null):string{
    $u=$u?:current_user();if(ai_is_premium($u))return 'Unlimited AI time';
    $sec=ai_seconds_remaining($uid,$u);$h=floor($sec/3600);$m=floor(($sec%3600)/60);$s=floor($sec%60);
    if($h>0)return $h.'h '.str_pad((string)$m,2,'0',STR_PAD_LEFT).'m remaining today';
    return $m.'m '.str_pad((string)$s,2,'0',STR_PAD_LEFT).'s remaining today';
}
function ai_reserve_input(int $uid,int $units):bool{
    // Backward-compatible gate for older callers. No tokens are consumed anymore.
    return ai_is_premium() || ai_seconds_remaining($uid)>=0.001;
}
function ai_release_input(int $uid,int $units):void{ /* Token quota removed; nothing to release. */ }
function ai_add_output(int $uid,int $units):void{ /* Token quota removed; active time is charged by ai_add_active_time(). */ }
function ai_add_active_time(int $uid,float $seconds,?array $u=null):void{
    $u=$u?:current_user();if(ai_is_premium($u)||$seconds<=0)return;
    $remaining=ai_seconds_remaining($uid,$u);$charge=min($seconds,$remaining);if($charge<=0)return;
    try{
        $s=db()->prepare('INSERT INTO ai_usage_daily(user_id,usage_date,input_units,output_units,active_seconds,updated_at) VALUES(?,CURDATE(),0,0,?,NOW()) ON DUPLICATE KEY UPDATE active_seconds=active_seconds+VALUES(active_seconds),updated_at=NOW()');
        $s->execute([$uid,round($charge,3)]);
    }catch(Throwable $e){}
}
function ai_global_credentials():array{
    return [
        'api_key'=>secret_setting('bedrock_api_key',''),
        'access_key'=>secret_setting('aws_access_key_id',''),
        'secret_key'=>secret_setting('aws_secret_access_key',''),
        'session_token'=>secret_setting('aws_session_token',''),
        'region'=>setting('aws_region','us-east-1'),
        'model'=>setting('bedrock_model_id','openai.gpt-oss-120b'),
        'endpoint'=>rtrim((string)setting('bedrock_endpoint_url',''),'/'),
        'api_mode'=>setting('bedrock_api_mode','openai'),
        'auth_type'=>setting('bedrock_auth_type','api_key'),
        'transport'=>setting('bedrock_transport','relay'),
        'relay_url'=>rtrim((string)setting('bedrock_relay_url',''),'/'),
        'relay_token'=>secret_setting('bedrock_relay_token',''),
        'source'=>'admin',
    ];
}
function ai_user_credentials(int $uid):?array{
    if($uid<=0)return null;
    try{$s=db()->prepare('SELECT * FROM user_ai_settings WHERE user_id=?');$s->execute([$uid]);$r=$s->fetch();if(!$r)return null;
        return [
            'api_key'=>decrypt_secret((string)($r['bedrock_api_key_encrypted']??'')),
            'access_key'=>decrypt_secret((string)($r['aws_access_key_encrypted']??'')),
            'secret_key'=>decrypt_secret((string)($r['aws_secret_key_encrypted']??'')),
            'session_token'=>decrypt_secret((string)($r['aws_session_token_encrypted']??'')),
            'region'=>(string)($r['region']??''),'model'=>(string)($r['model_id']??''),'endpoint'=>rtrim((string)($r['endpoint_url']??''),'/'),
            'api_mode'=>(string)($r['api_mode']??''),'transport'=>(string)($r['transport']??''),'relay_url'=>rtrim((string)($r['relay_url']??''),'/'),
            'relay_token'=>decrypt_secret((string)($r['relay_token_encrypted']??'')),'source'=>'user'
        ];
    }catch(Throwable $e){return null;}
}
function ai_credentials(?int $uid=null):array{
    $global=ai_global_credentials(); if(!$uid)return $global;
    $user=ai_user_credentials($uid); if(!$user)return $global;
    foreach(['api_key','access_key','secret_key','session_token','region','model','endpoint','api_mode','transport','relay_url','relay_token'] as $k){
        if(isset($user[$k]) && (string)$user[$k]!=='')$global[$k]=$user[$k];
    }
    $global['source']='user'; return $global;
}
function ai_user_settings_status(int $uid):array{
    $r=ai_user_credentials($uid);$g=ai_global_credentials();
    return [
        'configured'=>($r&&((($r['api_key']??'')!=='')||((($r['access_key']??'')!==''&&($r['secret_key']??'')!=='')||(($r['relay_url']??'')!==''&&($r['relay_token']??'')!=='')))),
        'api_key'=>(bool)($r['api_key']??''),'access_key'=>(bool)($r['access_key']??''),'secret_key'=>(bool)($r['secret_key']??''),'session_token'=>(bool)($r['session_token']??''),'relay_token'=>(bool)($r['relay_token']??''),
        'region'=>(string)($r['region']??$g['region']),'model'=>(string)($r['model']??$g['model']),'endpoint'=>(string)($r['endpoint']??$g['endpoint']),
        'api_mode'=>(string)($r['api_mode']??$g['api_mode']),'transport'=>(string)($r['transport']??$g['transport']),'relay_url'=>(string)($r['relay_url']??$g['relay_url']),
        'source'=>(string)($r['source']??'admin')
    ];
}
function ai_mask_secret(string $v):string{ if($v==='')return 'Not configured'; $n=strlen($v); return $n<=8?str_repeat('•',max(0,$n-4)).substr($v,-4):str_repeat('•',8).substr($v,-4); }
function ai_save_user_settings(int $uid,array $data):void{
    $allowed=['region','model_id','endpoint_url','api_mode','transport','relay_url'];$vals=[];foreach($allowed as $k)$vals[$k]=trim((string)($data[$k]??''));
    $secretMap=['bedrock_api_key'=>'bedrock_api_key_encrypted','aws_access_key_id'=>'aws_access_key_encrypted','aws_secret_access_key'=>'aws_secret_key_encrypted','aws_session_token'=>'aws_session_token_encrypted','bedrock_relay_token'=>'relay_token_encrypted'];
    $transport=(string)$vals['transport'];
    $activeSecrets=$transport==='relay'?['bedrock_relay_token']:(($transport==='direct'&&$vals['api_mode']==='converse')?['aws_access_key_id','aws_secret_access_key','aws_session_token']:['bedrock_api_key']);
    foreach($activeSecrets as $in){$col=$secretMap[$in];$v=trim((string)($data[$in]??''));if($v!==''&&!secret_is_masked_input($v))$vals[$col]=encrypt_secret($v);}
    $existing=false;try{$q=db()->prepare('SELECT user_id FROM user_ai_settings WHERE user_id=?');$q->execute([$uid]);$existing=(bool)$q->fetchColumn();}catch(Throwable $e){}
    if(!$existing){
        $cols=['user_id'];$place=['?'];$params=[$uid];foreach($allowed as $k){$cols[]=$k;$place[]='?';$params[]=$vals[$k];}foreach($secretMap as $in=>$col){$cols[]=$col;$place[]='?';$params[]=$vals[$col]??null;}db()->prepare('INSERT INTO user_ai_settings('.implode(',',$cols).',updated_at) VALUES('.implode(',',$place).',NOW())')->execute($params);
    }else{
        $sets=[];$params=[];foreach($allowed as $k){$sets[]="$k=?";$params[]=$vals[$k];}foreach($secretMap as $in=>$col){if(array_key_exists($col,$vals)){$sets[]="$col=?";$params[]=$vals[$col];}}$params[]=$uid;db()->prepare('UPDATE user_ai_settings SET '.implode(',',$sets).',updated_at=NOW() WHERE user_id=?')->execute($params);
    }
    foreach($secretMap as $in=>$col){if(($data['clear_'.$in]??'')==='1')db()->prepare("UPDATE user_ai_settings SET $col=NULL,updated_at=NOW() WHERE user_id=?")->execute([$uid]);}
}
function ai_openai_compatible(array $c):bool{
    $mode=(string)($c['api_mode']??'auto');
    if($mode==='responses'||$mode==='openai')return true;
    if($mode==='converse')return false;
    $endpoint=(string)($c['endpoint']??'');
    $model=(string)($c['model']??'');
    return $c['api_key']!=='' && (stripos($endpoint,'/openai/v1')!==false || stripos($endpoint,'/responses')!==false || str_starts_with($model,'openai.'));
}
function ai_openai_base_url(array $c):string{
    $endpoint=rtrim((string)($c['endpoint']??''),'/');
    $model=(string)($c['model']??'');
    // Keep an explicitly configured Bedrock endpoint intact. Current AWS
    // OpenAI-compatible APIs support gpt-oss-120b on both bedrock-runtime
    // (/openai/v1) and bedrock-mantle (/v1). Do not silently rewrite one to
    // the other because that can make a valid customer configuration fail.
    $mantle='https://bedrock-mantle.'.rawurlencode((string)$c['region']).'.api.aws/v1';
    if($endpoint!==''){
        $endpoint=preg_replace('~/responses$~','',$endpoint);
        if(preg_match('~/openai/v1$~',$endpoint))return $endpoint;
        if(preg_match('~/v1$~',$endpoint))return $endpoint;
        return $endpoint.'/openai/v1';
    }
    return $mantle;
}

function ai_url(string $region,string $model,string $action,string $endpoint=''):string{
    $model=trim($model);
    if($endpoint!==''){
        if(strpos($endpoint,'{model}')!==false||strpos($endpoint,'{action}')!==false)return str_replace(['{model}','{action}'],[rawurlencode($model),$action],$endpoint);
        if(preg_match('~/model/[^/]+/(?:converse|converse-stream)$~',$endpoint))return preg_replace('~/(?:converse|converse-stream)$~','/'.$action,$endpoint);
        if(preg_match('~/converse(?:-stream)?$~',$endpoint))return preg_replace('~/converse(?:-stream)?$~','/'.$action,$endpoint);
        return rtrim($endpoint,'/').'/model/'.rawurlencode($model).'/'.$action;
    }
    return 'https://bedrock-runtime.'.rawurlencode($region).'.amazonaws.com/model/'.rawurlencode($model).'/'.$action;
}

function ai_network_test(?int $uid=null):array{
    $c=ai_credentials($uid);
    if(($c['transport']??'auto')==='relay' || $c['relay_url']!==''){
        if($c['relay_url']==='')return [false,'Relay mode is enabled but the Relay URL is empty.'];
        $url=rtrim($c['relay_url'],'/').'/health';
        $parts=parse_url($url);$host=$parts['host']??'';
        if($host==='')return [false,'Invalid Bedrock relay URL.'];
        $resolved=gethostbyname($host);
        if($resolved===$host)return [false,"DNS lookup failed for relay host $host."];
        if(!function_exists('curl_init'))return [false,'PHP cURL is not enabled on this server.'];
        $headers=['accept'=>'application/json'];
        if($c['relay_token']!=='')$headers['x-pocketcat-relay-token']=$c['relay_token'];
        $ch=curl_init($url);
        curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_HEADER=>false,CURLOPT_NOBODY=>false,CURLOPT_TIMEOUT=>15,CURLOPT_CONNECTTIMEOUT=>8,CURLOPT_HTTPHEADER=>array_map(fn($k)=>$k.': '.$headers[$k],array_keys($headers)),CURLOPT_HTTP_VERSION=>CURL_HTTP_VERSION_1_1,CURLOPT_IPRESOLVE=>CURL_IPRESOLVE_V4,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2]);
        $out=curl_exec($ch);$errno=curl_errno($ch);$err=curl_error($ch);$http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$ip=(string)curl_getinfo($ch,CURLINFO_PRIMARY_IP);curl_close($ch);
        if($out===false)return [false,"Relay network error (cURL #$errno): $err. InfinityFree must allow outbound HTTPS to the relay host."];
        if($http<200||$http>=300)return [false,"Relay returned HTTP $http. Check the Relay URL and shared token."];
        return [true,"HTTPS reached relay $host (IP $ip) with HTTP $http."];
    }
    $region=trim((string)$c['region']);
    if($region==='')return [false,'AWS Region is empty.'];
    $url=rtrim($c['endpoint']!==''?$c['endpoint']:'https://bedrock-runtime.'.rawurlencode($region).'.amazonaws.com','/').'/';
    $parts=parse_url($url);$host=$parts['host']??'';
    if($host==='')return [false,'Invalid Bedrock endpoint.'];
    $resolved=gethostbyname($host);
    if($resolved===$host)return [false,"DNS lookup failed for $host. The hosting server cannot resolve the AWS hostname."];
    if(!function_exists('curl_init'))return [false,'PHP cURL is not enabled on this server.'];
    $ch=curl_init($url);curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_HEADER=>false,CURLOPT_NOBODY=>true,CURLOPT_TIMEOUT=>15,CURLOPT_CONNECTTIMEOUT=>8,CURLOPT_HTTP_VERSION=>CURL_HTTP_VERSION_1_1,CURLOPT_IPRESOLVE=>CURL_IPRESOLVE_V4,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2]);
    curl_exec($ch);$errno=curl_errno($ch);$err=curl_error($ch);$http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$ip=(string)curl_getinfo($ch,CURLINFO_PRIMARY_IP);$connect=(float)curl_getinfo($ch,CURLINFO_CONNECT_TIME);curl_close($ch);
    if($errno!==0){
        if($errno===7)return [false,"DNS resolved $host to $resolved, but the server could not open TCP/HTTPS connection to port 443 (cURL #7). This is a hosting outbound-network restriction, not an AWS API-key or model error."];
        return [false,"Network request failed (cURL #$errno): $err. Resolved IP: $resolved."];
    }
    return [true,"HTTPS reached $host (IP $ip) with HTTP $http in ".number_format($connect,3).'s. A 4xx/404 here can be normal because this was only a connectivity check.'];
}

function ai_test_connection(?int $uid=null):array{
    $c=ai_credentials($uid);
    // Relay mode intentionally does not require Bedrock credentials on the
    // PHP host. The Worker owns the Bedrock API key and forwards the request.
    // This mirrors Cline's separation between provider configuration and the
    // actual transport credentials, and avoids a false failure on shared
    // hosting when only the relay token is configured here.
    $usingRelay=ai_uses_relay($c);
    if(!$usingRelay && !$c['api_key']&&(!$c['access_key']||!$c['secret_key']))return [false,'No Bedrock credentials are configured. Save an API key or AWS Access Key / Secret Key first.'];
    if($c['region']===''||$c['model']==='')return [false,'AWS Region and model / inference profile ID are required.'];
    if($usingRelay && $c['relay_token']==='')return [false,'Relay is enabled but the shared relay token is missing. Save the same RELAY_TOKEN used by the Cloudflare Worker.'];
    if(ai_openai_compatible($c)){
        // Use Chat Completions for the health check: it is the same simple
        // OpenAI-compatible path used by normal PocketCat chat and avoids
        // false 'HTTP 200 but no text' results from reasoning-only responses.
        [$ok,$text]=ai_chat_completions_request([['role'=>'user','content'=>'Reply with exactly: PocketCat Bedrock connection OK']],$c,4096);
        return $ok?[true,'Bedrock OpenAI-compatible connection OK: '.$text]:[false,$text];
    }
    $payload=json_encode(['messages'=>[['role'=>'user','content'=>[['text'=>'Reply with exactly: PocketCat Bedrock connection OK']]]],'inferenceConfig'=>['maxTokens'=>16,'temperature'=>0]],JSON_UNESCAPED_SLASHES);
    $url=ai_url($c['region'],$c['model'],'converse',$c['endpoint']);
    [$ok,$raw]=ai_http($url,$payload,$c,false);
    if(!$ok)return [false,$raw];
    $data=json_decode($raw,true);$text=ai_extract_text($data);
    return [true,$text!==''?'Bedrock connection OK: '.$text:'Bedrock returned HTTP 200, but no text content was present.'];
}
function ai_openai_extract_text(array $data):string{
    if(isset($data['output_text'])&&is_string($data['output_text']))return $data['output_text'];
    $text='';
    foreach(($data['output']??[]) as $item){
        foreach(($item['content']??[]) as $content){
            if(isset($content['text'])&&is_string($content['text']))$text.=$content['text'];
        }
    }
    return $text;
}
function ai_openai_usage(array $data):int{
    $u=$data['usage']??($data['response']['usage']??[]);
    return (int)($u['output_tokens']??$u['outputTokens']??0);
}
function aws_sign(string $method,string $url,array $headers,string $body,string $access,string $secret,string $region,string $service='bedrock') :array{
    $parts=parse_url($url);$host=$parts['host'];$path=$parts['path']??'/';$query=$parts['query']??'';$amz=date('Ymd\THis\Z');$date=substr($amz,0,8);
    $headers['host']=$host;$headers['x-amz-date']=$amz;ksort($headers);$canonHeaders='';foreach($headers as $k=>$v)$canonHeaders.=strtolower($k).':'.trim(preg_replace('/\s+/',' ',(string)$v))."\n";$signed=implode(';',array_keys($headers));$payloadHash=hash('sha256',$body);
    $canonical=$method."\n".$path."\n".$query."\n".$canonHeaders."\n".$signed."\n".$payloadHash;
    $scope="$date/$region/$service/aws4_request";$string="AWS4-HMAC-SHA256\n$amz\n$scope\n".hash('sha256',$canonical);$kDate=hash_hmac('sha256',$date,'AWS4'.$secret,true);$kRegion=hash_hmac('sha256',$region,$kDate,true);$kService=hash_hmac('sha256',$service,$kRegion,true);$kSigning=hash_hmac('sha256','aws4_request',$kService,true);$sig=hash_hmac('sha256',$string,$kSigning);
    $headers['Authorization']="AWS4-HMAC-SHA256 Credential=$access/$scope, SignedHeaders=$signed, Signature=$sig";return $headers;
}
function ai_uses_relay(array $cred):bool{
    $transport=(string)($cred['transport']??'relay');
    $relay=(string)($cred['relay_url']??'');
    // Stable production path: if a relay is configured, use it unless the
    // administrator/customer explicitly selected Direct to AWS.
    return $relay!=='' && $transport!=='direct';
}
function ai_relay_url(array $cred,string $url):string{
    if(!ai_uses_relay($cred))return $url;
    $relay=rtrim((string)$cred['relay_url'],'/');
    // Preserve the requested OpenAI-compatible API path so normal Chat
    // Completions calls are not accidentally sent to /responses.
    $path=parse_url($url,PHP_URL_PATH) ?: '/responses';
    $target=str_ends_with($path,'/chat/completions')?'/chat/completions':'/responses';
    $relay=preg_replace('~/(?:responses|chat/completions)$~','',$relay);
    return $relay.$target;
}
function ai_http(string $url,string $body,array $cred,bool $stream=false,?callable $onChunk=null):array{
    $usingRelay=ai_uses_relay($cred);
    if($usingRelay){
        $url=ai_relay_url($cred,$url);
        $headers=['content-type'=>'application/json','accept'=>$stream?'text/event-stream':'application/json'];
        if($cred['relay_token']!=='')$headers['x-pocketcat-relay-token']=$cred['relay_token'];
    }else{
        $headers=['content-type'=>'application/json','accept'=>$stream?'text/event-stream':'application/json'];
        if($cred['api_key']!=='')$headers['authorization']='Bearer '.$cred['api_key'];
        elseif($cred['access_key']!==''&&$cred['secret_key']!==''){
            if($cred['session_token']!=='')$headers['x-amz-security-token']=$cred['session_token'];
            $headers=aws_sign('POST',$url,$headers,$body,$cred['access_key'],$cred['secret_key'],$cred['region']);
        }else return [false,'Configure a Bedrock API key or AWS Access Key / Secret Key in Admin → AWS Bedrock.'];
    }
    if(!function_exists('curl_init'))return [false,'PHP cURL is not enabled on this server. Enable the cURL extension in hosting/PHP settings.'];
    $ch=curl_init($url);$out='';
    $opts=[CURLOPT_POST=>true,CURLOPT_RETURNTRANSFER=>!$stream,CURLOPT_HEADER=>false,CURLOPT_TIMEOUT=>90,CURLOPT_CONNECTTIMEOUT=>15,CURLOPT_HTTPHEADER=>array_map(fn($k)=>$k.': '.$headers[$k],array_keys($headers)),CURLOPT_POSTFIELDS=>$body,CURLOPT_HTTP_VERSION=>CURL_HTTP_VERSION_1_1,CURLOPT_IPRESOLVE=>CURL_IPRESOLVE_V4,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2];
    curl_setopt_array($ch,$opts);
    if($stream){curl_setopt($ch,CURLOPT_WRITEFUNCTION,function($ch,$chunk)use(&$out,$onChunk){$out.=$chunk;if($onChunk)$onChunk($chunk);return strlen($chunk);});}
    $bodyOut=curl_exec($ch);$http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$errno=curl_errno($ch);$err=curl_error($ch);curl_close($ch);
    if($bodyOut===false){
        $detail=$err!==''?$err:'Unknown cURL transport error';
        $parts=parse_url($url);$host=$parts['host']??'the relay/Bedrock endpoint';
        $resolved=$host!==''?gethostbyname($host):'';
        if($errno===6)$hint="DNS could not resolve $host.";
        elseif($errno===7)$hint=($resolved!==$host?"DNS resolved $host to $resolved, but the hosting server cannot establish an outbound TCP/HTTPS connection to $host port 443.":"The hosting server cannot establish an outbound TCP/HTTPS connection to $host port 443.");
        elseif(in_array($errno,[35,51,53,60],true))$hint="TLS/SSL negotiation failed between the hosting server and $host.";
        else $hint="Check outbound HTTPS, DNS, firewall and TLS support on the hosting server.";
        return [false,($usingRelay?'Relay':'Bedrock').' transport error (cURL #'.$errno.'): '.$detail.'. '.$hint];
    }
    if($http<200||$http>=300){
        $d=json_decode($out!==''?$out:$bodyOut,true);
        $message=$d['message']??$d['Message']??($d['error']['message']??'');
        if(is_array($message))$message=json_encode($message);
        return [false,$message!==''?($usingRelay?'Relay HTTP ':'Bedrock HTTP ').$http.': '.$message:($usingRelay?'Relay returned HTTP ':'Bedrock returned HTTP ').$http.'. Verify the relay/region/model/credentials.'];
    }
    return [true,$out!==''?$out:$bodyOut];
}

function ai_extract_text(array $data):string{
    $chunks=$data['output']['message']['content']??[];$text='';foreach($chunks as $c)if(isset($c['text']))$text.=$c['text'];return $text;
}

function ai_responses_request(array $input,array $c,bool $agent=false):array{
    // Compatibility wrapper. Agent mode intentionally uses the Chat
    // Completions tool-calling contract because it is supported by the
    // OpenAI-compatible Bedrock path and by PocketCat relays.
    if($agent)return ai_chat_completions_agent_request($input,$c);
    $base=ai_openai_base_url($c);$url=rtrim($base,'/').'/responses';
    $body=['model'=>$c['model'],'input'=>$input,'store'=>false,'max_output_tokens'=>4096,'temperature'=>0.3,'stream'=>false];
    [$ok,$raw]=ai_http($url,json_encode($body,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE),$c,false);
    if(!$ok)return [false,$raw];$data=json_decode($raw,true);if(!is_array($data))return [false,'Bedrock returned invalid JSON.'];
    $out=ai_openai_extract_text($data);return $out!==''?[true,$out]:[false,'Bedrock returned no text.'];
}
function ai_chat_completions_agent_request(array $messages,array $c):array{
    $url=rtrim(ai_openai_base_url($c),'/').'/chat/completions';
    $tools=[];foreach(ai_agent_tools() as $tool){$tools[]=['type'=>'function','function'=>['name'=>$tool['name'],'description'=>$tool['description'],'parameters'=>$tool['parameters']]];}
    $working=$messages;
    for($round=0;$round<5;$round++){
        $payload=['model'=>$c['model'],'messages'=>$working,'tools'=>$tools,'tool_choice'=>'auto','max_completion_tokens'=>4096,'temperature'=>0.2,'stream'=>false];
        [$ok,$raw]=ai_http($url,json_encode($payload,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE),$c,false);if(!$ok)return [false,$raw];
        $data=json_decode($raw,true);if(!is_array($data))return [false,'Bedrock returned invalid JSON.'];
        $choice=$data['choices'][0]??[];$message=$choice['message']??[];$calls=$message['tool_calls']??[];
        if(!$calls){$content=$message['content']??$choice['text']??'';if(is_array($content)){$x='';foreach($content as $part)if(isset($part['text']))$x.=$part['text'];$content=$x;}$text=trim((string)$content);if($text!=='')return [true,$text];$reasoning=$message['reasoning_content']??$message['reasoning']??'';return [false,trim((string)$reasoning)!==''?'Bedrock returned reasoning but no final text. Increase the model output budget or verify the model configuration.':'Bedrock returned an empty response. Verify the model configuration.'];}
        $working[]=['role'=>'assistant','content'=>$message['content']??null,'tool_calls'=>$calls];
        foreach($calls as $call){$name=(string)($call['function']['name']??'');$args=(string)($call['function']['arguments']??'{}');$result=ai_execute_agent_tool($name,$args);$working[]=['role'=>'tool','tool_call_id'=>(string)($call['id']??''),'content'=>$result];}
    }
    return [false,'Agent reached the tool-call limit before producing a final answer.'];
}
function ai_converse_messages(array $input):array{
    $messages=[];foreach($input as $m){$role=(($m['role']??'user')==='assistant')?'assistant':'user';$content=(string)($m['content']??'');$messages[]=['role'=>$role,'content'=>[['text'=>$content]]];}return $messages;
}
function ai_converse_request(array $input,array $c):array{
    $url=ai_url($c['region'],$c['model'],'converse',$c['endpoint']);$body=['messages'=>ai_converse_messages($input),'inferenceConfig'=>['maxTokens'=>4096,'temperature'=>0.2]];
    [$ok,$raw]=ai_http($url,json_encode($body,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE),$c,false);if(!$ok)return [false,$raw];$data=json_decode($raw,true);if(!is_array($data))return [false,'Bedrock returned invalid JSON.'];$text=trim(ai_extract_text($data));return $text!==''?[true,$text]:[false,'Bedrock returned no text. Verify the Bedrock model access, region, credentials, and model ID.'];
}
function ai_converse_agent_request(array $input,array $c):array{
    $url=ai_url($c['region'],$c['model'],'converse',$c['endpoint']);$toolSpecs=[];foreach(ai_agent_tools() as $tool)$toolSpecs[]=['toolSpec'=>['name'=>$tool['name'],'description'=>$tool['description'],'inputSchema'=>['json'=>$tool['parameters']]]];$messages=ai_converse_messages($input);
    for($round=0;$round<5;$round++){
        $body=['messages'=>$messages,'inferenceConfig'=>['maxTokens'=>4096,'temperature'=>0.2],'toolConfig'=>['tools'=>$toolSpecs]];[$ok,$raw]=ai_http($url,json_encode($body,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE),$c,false);if(!$ok)return [false,$raw];$data=json_decode($raw,true);if(!is_array($data))return [false,'Bedrock returned invalid JSON.'];$assistant=$data['output']['message']??[];$blocks=$assistant['content']??[];$uses=[];$text='';foreach($blocks as $block){if(isset($block['text']))$text.=$block['text'];if(isset($block['toolUse']))$uses[]=$block['toolUse'];}
        if(!$uses){$text=trim($text);return $text!==''?[true,$text]:[false,'Bedrock returned no text.'];}
        $messages[]=$assistant;$results=[];foreach($uses as $use){$name=(string)($use['name']??'');$result=ai_execute_agent_tool($name,json_encode($use['input']??[],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));$decoded=json_decode($result,true);$results[]=['toolResult'=>['toolUseId'=>(string)($use['toolUseId']??''),'content'=>[['json'=>is_array($decoded)?$decoded:['result'=>$result]]]]];}$messages[]=['role'=>'user','content'=>$results];
    }
    return [false,'Agent reached the tool-call limit before producing a final answer.'];
}
function ai_agent_tools():array{
    return [
        ['type'=>'function','name'=>'search_workspace','description'=>'Search the current user tasks, notes and projects by title or text.','parameters'=>['type'=>'object','properties'=>['query'=>['type'=>'string']],'required'=>['query']]],
        ['type'=>'function','name'=>'create_task','description'=>'Create one task for the current user. Use only when explicitly requested.','parameters'=>['type'=>'object','properties'=>['title'=>['type'=>'string'],'description'=>['type'=>'string'],'priority'=>['type'=>'string','enum'=>['Low','Medium','High']],'due_date'=>['type'=>'string']],'required'=>['title']]],
        ['type'=>'function','name'=>'create_note','description'=>'Create one note for the current user. Use only when explicitly requested.','parameters'=>['type'=>'object','properties'=>['title'=>['type'=>'string'],'content'=>['type'=>'string']],'required'=>['title','content']]],
        ['type'=>'function','name'=>'create_project','description'=>'Create one project for the current user. Use only when explicitly requested.','parameters'=>['type'=>'object','properties'=>['name'=>['type'=>'string'],'description'=>['type'=>'string'],'status'=>['type'=>'string','enum'=>['Planning','Active','Completed','Archived']]],'required'=>['name']]],
    ];
}
function ai_execute_agent_tool(string $name,string $arguments):string{
    $args=json_decode($arguments,true);if(!is_array($args))$args=[];$uid=(int)(current_user()['id']??0);if($uid<=0)return json_encode(['ok'=>false,'error'=>'Not authenticated.']);
    try{
        if($name==='search_workspace'){
            $q='%'.trim((string)($args['query']??'')).'%';$out=['tasks'=>[],'notes'=>[],'projects'=>[]];
            foreach(['tasks'=>"SELECT id,title,status,priority,due_date FROM tasks WHERE user_id=? AND (title LIKE ? OR description LIKE ?) ORDER BY updated_at DESC LIMIT 10",'notes'=>"SELECT id,title,updated_at FROM notes WHERE user_id=? AND (title LIKE ? OR content LIKE ?) ORDER BY updated_at DESC LIMIT 10",'projects'=>"SELECT id,name AS title,status,due_date FROM projects WHERE user_id=? AND (name LIKE ? OR description LIKE ?) ORDER BY updated_at DESC LIMIT 10"] as $k=>$sql){$s=db()->prepare($sql);$s->execute([$uid,$q,$q]);$out[$k]=$s->fetchAll();}return json_encode(['ok'=>true,'results'=>$out],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        }
        if($name==='create_task'){
            if(plan_limit_reached('tasks',$uid))return json_encode(['ok'=>false,'error'=>'Task plan limit reached.']);$title=trim((string)($args['title']??''));if($title==='')return json_encode(['ok'=>false,'error'=>'Task title is required.']);$priority=in_array(($args['priority']??'Medium'),['Low','Medium','High'],true)?$args['priority']:'Medium';$due=trim((string)($args['due_date']??''));if($due!==''&&!preg_match('/^\d{4}-\d{2}-\d{2}$/',$due))$due='';db()->prepare("INSERT INTO tasks(user_id,title,description,status,priority,due_date,created_at,updated_at) VALUES(?,?,?,'Todo',?,?,NOW(),NOW())")->execute([$uid,mb_substr($title,0,220),mb_substr((string)($args['description']??''),0,5000),$priority,$due!==''?$due:null]);increment_counter('tasks_created_counter');return json_encode(['ok'=>true,'created'=>'task','id'=>(int)db()->lastInsertId(),'title'=>$title],JSON_UNESCAPED_UNICODE);
        }
        if($name==='create_note'){
            if(plan_limit_reached('notes',$uid))return json_encode(['ok'=>false,'error'=>'Note plan limit reached.']);$title=trim((string)($args['title']??''));$content=trim((string)($args['content']??''));if($title===''||$content==='')return json_encode(['ok'=>false,'error'=>'Note title and content are required.']);db()->prepare('INSERT INTO notes(user_id,title,content,created_at,updated_at) VALUES(?,?,?,NOW(),NOW())')->execute([$uid,mb_substr($title,0,220),$content]);increment_counter('notes_created_counter');return json_encode(['ok'=>true,'created'=>'note','id'=>(int)db()->lastInsertId(),'title'=>$title],JSON_UNESCAPED_UNICODE);
        }
        if($name==='create_project'){
            if(plan_limit_reached('projects',$uid))return json_encode(['ok'=>false,'error'=>'Project plan limit reached.']);$name=trim((string)($args['name']??''));if($name==='')return json_encode(['ok'=>false,'error'=>'Project name is required.']);$status=in_array(($args['status']??'Planning'),['Planning','Active','Completed','Archived'],true)?$args['status']:'Planning';db()->prepare("INSERT INTO projects(user_id,name,description,status,created_at,updated_at) VALUES(?,?,?,?,NOW(),NOW())")->execute([$uid,mb_substr($name,0,180),mb_substr((string)($args['description']??''),0,5000),$status]);increment_counter('projects_created_counter');return json_encode(['ok'=>true,'created'=>'project','id'=>(int)db()->lastInsertId(),'name'=>$name],JSON_UNESCAPED_UNICODE);
        }
    }catch(Throwable $e){return json_encode(['ok'=>false,'error'=>'Tool failed: '.$e->getMessage()],JSON_UNESCAPED_UNICODE);}
    return json_encode(['ok'=>false,'error'=>'Unknown tool.']);
}
function ai_chat_completions_request(array $messages,array $c,int $maxTokens=4096):array{
    $base=rtrim(ai_openai_base_url($c),'/');
    $url=$base.'/chat/completions';
    // AWS documents max_completion_tokens as an OpenAI field, but its
    // compatibility layer also maps it to the native maxTokens field. Keep
    // the request conservative and use max_tokens for broad compatibility.
    $payload=['model'=>$c['model'],'messages'=>$messages,'max_completion_tokens'=>$maxTokens,'temperature'=>0.2,'stream'=>false];
    [$ok,$raw]=ai_http($url,json_encode($payload,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE),$c,false);if(!$ok)return [false,$raw];
    $data=json_decode($raw,true);if(!is_array($data))return [false,'Bedrock returned invalid JSON.'];
    $choice=$data['choices'][0]??[];
    $content=$choice['message']['content']??$choice['text']??'';
    if(is_array($content)){ $x='';foreach($content as $part){if(isset($part['text']))$x.=$part['text'];elseif(isset($part['content']))$x.=(string)$part['content'];}$content=$x; }
    $text=trim((string)$content);
    if($text!=='')return [true,$text];
    $reasoning=$choice['message']['reasoning_content']??$choice['message']['reasoning']??'';
    if(is_array($reasoning)){ $x='';foreach($reasoning as $part)if(isset($part['text']))$x.=$part['text'];$reasoning=$x; }
    if(trim((string)$reasoning)!=='')return [false,'Bedrock returned reasoning but no final text. Increase the model output budget or verify the model configuration.'];
    $finish=(string)($choice['finish_reason']??'unknown');
    return [false,'Bedrock returned an empty response (finish_reason: '.$finish.'). Verify the Bedrock model access, API key permissions, region, and model ID.'];
}
function ai_chat(string $prompt):array{
    $prompt=trim($prompt);if($prompt==='')return [false,'Enter a prompt first.'];$u=current_user();if(!$u)return [false,'Please log in to use the AI assistant.','LOGIN_REQUIRED'];
    if(!ai_is_premium($u)&&ai_seconds_remaining((int)$u['id'],$u)<0.001)return [false,'Your daily AI active-time allowance is exhausted. Please upgrade your plan.','LIMIT_REACHED'];
    $c=ai_credentials((int)$u['id']);if(!ai_uses_relay($c)&&!$c['api_key']&&(!$c['access_key']||!$c['secret_key']))return [false,'Amazon Bedrock credentials are not configured. Add your Bedrock settings in My Settings → AWS Bedrock, or use the administrator default.'];
    $started=microtime(true);
    $maxTokens=ai_is_premium($u)?4096:4096;
    $messages=[['role'=>'user','content'=>$prompt]];
    [$ok,$text]=ai_openai_compatible($c)?ai_chat_completions_request($messages,$c,$maxTokens):[false,'This AI configuration requires an OpenAI-compatible Bedrock endpoint for chat.'];
    if(!$ok)return [false,$text];
    ai_add_active_time((int)$u['id'],microtime(true)-$started,$u);log_event('ai_request',(int)$u['id']);return [true,$text];
}
function ai_stream(string $prompt):void{
    $u=current_user();$remaining=ai_seconds_remaining((int)$u['id'],$u);if(!ai_is_premium($u)&&$remaining<0.001){http_response_code(429);echo 'data: '.json_encode(['error'=>'Your daily AI active-time allowance is exhausted. Please upgrade your plan.'])."\n\n";return;}
    $started=microtime(true);
    $c=ai_credentials();if(!ai_uses_relay($c)&&!$c['api_key']&&(!$c['access_key']||!$c['secret_key'])){http_response_code(503);echo 'data: '.json_encode(['error'=>'Amazon Bedrock credentials are not configured.'])."\n\n";return;}    $maxTokens=ai_is_premium($u)?1200:900;
    header('Content-Type: text/event-stream');header('Cache-Control: no-cache');header('X-Accel-Buffering: no');
    $assembled='';$actualOutputTokens=0;
    if(ai_openai_compatible($c)){
        $payload=json_encode(['model'=>$c['model'],'messages'=>[['role'=>'user','content'=>trim($prompt)]],'max_completion_tokens'=>$maxTokens,'temperature'=>0.3,'stream'=>true],JSON_UNESCAPED_SLASHES);
        $url=rtrim(ai_openai_base_url($c),'/').'/chat/completions';$buffer='';
        [$ok,$raw]=ai_http($url,$payload,$c,true,function($chunk)use(&$assembled,&$actualOutputTokens,&$buffer){
            $buffer.=$chunk;
            while(($sep=strpos($buffer,"\n\n"))!==false){
                $event=substr($buffer,0,$sep);$buffer=substr($buffer,$sep+2);
                foreach(preg_split('/\r?\n/',$event) as $line){
                    if(strncmp($line,'data:',5)!==0)continue;
                    $json=trim(substr($line,5));if($json===''||$json==='[DONE]')continue;$j=json_decode($json,true);if(!is_array($j))continue;
                    if(($j['type']??'')==='error'){echo 'data: '.json_encode(['error'=>$j['message']??'Bedrock Responses API error'],JSON_UNESCAPED_UNICODE)."\n\n";continue;}
                    $delta='';
                    if(isset($j['choices'][0]['delta']['content']))$delta=(string)$j['choices'][0]['delta']['content'];
                    elseif(($j['type']??'')==='response.output_text.delta')$delta=(string)($j['delta']??'');
                    if($delta!==''){$assembled.=$delta;echo 'data: '.json_encode(['delta'=>$delta],JSON_UNESCAPED_UNICODE)."\n\n";@ob_flush();@flush();}
                    if(isset($j['usage']))$actualOutputTokens=ai_openai_usage($j);
                }
            }
        });
        if(!$ok){echo 'data: '.json_encode(['error'=>$raw],JSON_UNESCAPED_UNICODE)."\n\n";return;}
        if($assembled!=='')ai_add_active_time((int)$u['id'],microtime(true)-$started,$u);echo 'data: '.json_encode(['done'=>true])."\n\n";return;
    }
    $payload=json_encode(['messages'=>[['role'=>'user','content'=>[['text'=>trim($prompt)]]]],'inferenceConfig'=>['maxTokens'=>$maxTokens,'temperature'=>0.3]],JSON_UNESCAPED_SLASHES);$url=ai_url($c['region'],$c['model'],'converse-stream',$c['endpoint']);$buffer='';
    [$ok,$raw]=ai_http($url,$payload,$c,true,function($chunk)use(&$assembled,&$actualOutputTokens,&$buffer){
        $buffer.=$chunk;$pos=0;$len=strlen($buffer);
        while($pos+12<=$len){$total=unpack('N',substr($buffer,$pos,4))[1]??0;if($total<16)break;if($pos+$total>$len)break;$headerLen=unpack('N',substr($buffer,$pos+4,4))[1]??0;$payloadLen=$total-$headerLen-16;if($payloadLen<0)break;$payload=substr($buffer,$pos+12+$headerLen,$payloadLen);$j=json_decode($payload,true);if(is_array($j)){ $actualOutputTokens=(int)($j['metadata']['usage']['outputTokens']??$j['usage']['outputTokens']??$actualOutputTokens); $delta=$j['contentBlockDelta']['delta']['text']??$j['delta']['text']??'';if($delta!==''){ $assembled.=$delta;echo 'data: '.json_encode(['delta'=>$delta],JSON_UNESCAPED_UNICODE)."\n\n";@ob_flush();@flush(); }}$pos+=$total;}
        if($pos>0)$buffer=substr($buffer,$pos);
    });
    if(!$ok){echo 'data: '.json_encode(['error'=>$raw],JSON_UNESCAPED_UNICODE)."\n\n";}else{if($assembled!=='')ai_add_active_time((int)$u['id'],microtime(true)-$started,$u);echo 'data: '.json_encode(['done'=>true])."\n\n";}
}
