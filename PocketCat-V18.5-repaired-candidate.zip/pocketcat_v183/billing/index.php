<?php
require __DIR__.'/../bootstrap.php';
if(!current_user()){redirect('/login/?next=/billing/');}
$u=current_user();$currentPlan=(string)($u['plan']??'free');
$title='Plans & Billing';require __DIR__.'/../includes/header.php';
?>
<div class="testing-mode-banner"><strong>Testing Mode / All Features Unlocked</strong><span>All registered users have free, unlimited access to platform features during website testing. Paid-plan and subscription checks are bypassed.</span></div>
<div class="page-head billing-page-head"><div><span class="eyebrow">Plans & Billing</span><h1>Testing Mode</h1><p>Plan cards remain visible for UI preview, but checkout and upgrade workflows are disabled while all features are unlocked.</p></div><div class="actions"><a class="btn secondary" href="/settings/">Billing Information</a><div class="billing-current-plan"><span>Database plan</span><strong><?=e(ucfirst($currentPlan))?></strong></div></div></div>
<div class="plan-grid billing-plans">
<article class="card plan-card plan-active"><span class="badge">FREE</span><span class="plan-current-badge">Testing access</span><h2>$0</h2><ul><li>Unlimited Tasks</li><li>Unlimited Projects</li><li>Unlimited Notes</li><li>Unlimited AI active usage</li><li>Unlimited storage & file limits</li><li>Advanced Website Analytics</li></ul><button class="btn secondary full disabled-btn" type="button" disabled>Testing Mode Active</button></article>
<article class="card plan-card"><span class="badge">BASIC</span><div class="price">$3<small>/ month</small></div><ul><li>Preview of Basic plan</li><li>Unlimited access in testing mode</li><li>All premium features unlocked</li><li>Manual payment workflow disabled</li></ul><button class="btn full disabled-btn" type="button" disabled>Checkout Disabled</button></article>
<article class="card plan-card"><span class="badge">PREMIUM</span><div class="price">$6<small>/ month</small></div><ul><li>Preview of Premium plan</li><li>Unlimited Tasks / Projects / Notes</li><li>Unlimited AI active usage</li><li>Advanced Website Analytics & Tracking</li><li>Conversion goals, UTM & live visitors</li></ul><button class="btn full disabled-btn" type="button" disabled>Checkout Disabled</button></article>
</div>
<section class="card testing-access-card"><div><span class="eyebrow">TEST ENVIRONMENT</span><h2>All Features Unlocked</h2><p class="muted">Your account's stored Free, Basic or Premium plan does not restrict access in this testing build. No payment request, subscription approval or checkout action is created from this page.</p></div><a class="btn secondary" href="/dashboard/">Open Workspace</a></section>
<?php require __DIR__.'/../includes/footer.php'; ?>
