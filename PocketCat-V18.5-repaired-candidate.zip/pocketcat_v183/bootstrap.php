<?php
declare(strict_types=1);
require __DIR__.'/includes/path-resolver.php'; require __DIR__.'/includes/functions.php'; require __DIR__.'/includes/policy.php'; require __DIR__.'/includes/database.php'; require __DIR__.'/includes/csrf.php'; require __DIR__.'/includes/auth.php'; require __DIR__.'/includes/admin-auth.php'; require __DIR__.'/includes/mail.php'; require __DIR__.'/includes/ai.php'; require __DIR__.'/includes/links.php'; require __DIR__.'/includes/maxmind-reader.php'; require __DIR__.'/includes/geoip-updater.php'; require __DIR__.'/includes/geo.php'; require __DIR__.'/includes/files.php'; require __DIR__.'/includes/upload-engine.php'; require __DIR__.'/includes/asset-catalog.php'; require __DIR__.'/includes/cloud-storage.php'; require __DIR__.'/includes/code.php'; require __DIR__.'/includes/visual-engine.php'; require __DIR__.'/includes/editor-suite.php'; require __DIR__.'/includes/menu-manager.php'; require __DIR__.'/includes/qr.php'; require __DIR__.'/includes/docs.php'; require __DIR__.'/includes/cms.php'; require __DIR__.'/includes/analytics.php'; require __DIR__.'/includes/ota-updater.php';
if(function_exists('upload_prepare_directories')){try{upload_prepare_directories();}catch(Throwable $e){error_log('[PocketCat upload dirs] '.$e->getMessage());}}
if(session_status()!==PHP_SESSION_ACTIVE){$secure=!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off';session_set_cookie_params(['httponly'=>true,'secure'=>$secure,'samesite'=>'Lax','path'=>'/']);session_start();}
if(!is_installed()){
    $requestPath=parse_url($_SERVER['REQUEST_URI']??'/',PHP_URL_PATH)?:'/';
    if(strpos(rtrim($requestPath,'/'),'/install')!==0)redirect('/install/');
}
ensure_platform_schema();
if(function_exists('ensure_file_workspace_schema')){try{ensure_file_workspace_schema();}catch(Throwable $e){error_log('[PocketCat file schema] '.$e->getMessage());}}
if(function_exists('ensure_advanced_analytics_schema')){ try{ ensure_advanced_analytics_schema(db()); }catch(Throwable $e){ error_log('[PocketCat analytics bootstrap] '.$e->getMessage()); } }
ensure_code_schema();
ensure_visual_schema();
editor_suite_schema();
if (is_installed()) { menu_schema(); qr_schema(); docs_schema(); ensure_cms_schema(); if(function_exists('cms_publish_scheduled')){ cms_publish_scheduled(); } }
if(function_exists('policy_flag') && policy_flag('maintenance_mode',false)){ $path=parse_url($_SERVER['REQUEST_URI']??'/',PHP_URL_PATH)?:'/'; $allowed=(strpos($path,'/admin')===0||strpos($path,'/login')===0||strpos($path,'/logout')===0||strpos($path,'/install')===0); if(!$allowed && PHP_SAPI!=='cli'){http_response_code(503);header('Retry-After: 300');exit('PocketCat is temporarily under maintenance.');}}
