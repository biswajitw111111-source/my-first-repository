# PocketCat V11.52 — Multi-File Upload + Single-File Download

## Code Workspace
- Added multi-file upload to Workspace Pro.
- Select multiple text/code files in one operation and load them into the browser-local workspace.
- Duplicate names are preserved with safe numeric suffixes.
- Every workspace file now has its own download action.
- Added Download current file in the workspace toolbar.
- Project ZIP export remains available.

## Media Library
- Kept multi-file selection and sequential resumable uploads for shared-hosting reliability.
- Successful uploads now show an explicit Download action in the upload result.
- Every media card now exposes an explicit single-file Download action.
