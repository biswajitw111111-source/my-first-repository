<?php
require __DIR__.'/../bootstrap.php';require_login();
header('X-PocketCat-AI-Endpoint: 1'); if($_SERVER['REQUEST_METHOD']!=='POST')json_response(['ok'=>false,'error'=>'POST required.'],405);verify_csrf();
$uid=(int)current_user()['id'];$action=(string)post('action','send');
try {
if($action==='new'){ $s=db()->prepare('INSERT INTO conversations(user_id,title,created_at,updated_at) VALUES(?,?,NOW(),NOW())');$s->execute([$uid,'New chat']);json_response(['ok'=>true,'conversation_id'=>(int)db()->lastInsertId()]); }
if($action==='history'){ $s=db()->prepare('SELECT id,title,updated_at FROM conversations WHERE user_id=? ORDER BY updated_at DESC');$s->execute([$uid]);json_response(['ok'=>true,'conversations'=>$s->fetchAll()]); }
if($action==='messages'){ $cid=(int)post('conversation_id');$s=db()->prepare('SELECT id,role,content,created_at FROM conversation_messages WHERE conversation_id=? AND EXISTS(SELECT 1 FROM conversations c WHERE c.id=? AND c.user_id=?) ORDER BY id');$s->execute([$cid,$cid,$uid]);$rows=$s->fetchAll();$aq=db()->prepare('SELECT id,message_id,name,stored_path,mime_type,size_bytes,kind FROM chat_attachments WHERE conversation_id=? AND user_id=? AND message_id IS NOT NULL ORDER BY id');$aq->execute([$cid,$uid]);$am=[];foreach($aq->fetchAll() as $a){$mid=(int)$a['message_id'];$a['url']='/api/chat-attachment.php?id='.(int)$a['id'];$am[$mid][]=$a;}foreach($rows as &$row){$lc=strtolower((string)$row['content']);$row['legacy_error']=($row['role']==='assistant' && str_contains($lc,'403 forbidden') && str_contains($lc,'infinityfree'));$row['attachments']=$am[(int)$row['id']]??[];}unset($row);json_response(['ok'=>true,'messages'=>$rows]); }
if($action==='share'){
 $cid=(int)post('conversation_id');$mid=(int)post('message_id');
 $s=db()->prepare('SELECT id FROM conversations WHERE id=? AND user_id=?');$s->execute([$cid,$uid]);if(!$s->fetch())json_response(['ok'=>false,'error'=>'Conversation not found.'],404);
 if($mid){$s=db()->prepare('SELECT id FROM conversation_messages WHERE id=? AND conversation_id=? AND role=\'assistant\'');$s->execute([$mid,$cid]);if(!$s->fetch())json_response(['ok'=>false,'error'=>'Assistant message not found.'],404);}
 $type=$mid?'message':'conversation';$tok=hash('sha256',random_token(32));db()->prepare('INSERT INTO shared_items(token,user_id,type,conversation_id,message_id,created_at) VALUES(?,?,?,?,?,NOW())')->execute([$tok,$uid,$type,$cid,$mid?:null,date('Y-m-d H:i:s')]);json_response(['ok'=>true,'url'=>safe_public_url('share/'.$tok)]);
}
$prompt=trim((string)post('prompt',''));if($prompt==='')json_response(['ok'=>false,'error'=>'Please enter a prompt.'],422);
$cid=(int)post('conversation_id');if(!$cid){$s=db()->prepare('INSERT INTO conversations(user_id,title,created_at,updated_at) VALUES(?,?,NOW(),NOW())');$s->execute([$uid,mb_substr($prompt,0,70)]);$cid=(int)db()->lastInsertId();}
$s=db()->prepare('SELECT id FROM conversations WHERE id=? AND user_id=?');$s->execute([$cid,$uid]);if(!$s->fetch())json_response(['ok'=>false,'error'=>'Conversation not found.'],404);
$attachmentIds=[];$rawAttachmentIds=post('attachment_ids','');
if(is_array($rawAttachmentIds)) $attachmentIds=array_values(array_unique(array_filter(array_map('intval',$rawAttachmentIds))));
elseif(trim((string)$rawAttachmentIds)!=='') $attachmentIds=array_values(array_unique(array_filter(array_map('intval',preg_split('/[,\s]+/',(string)$rawAttachmentIds)))));
$attachments=[];
if($attachmentIds){
  $marks=implode(',',array_fill(0,count($attachmentIds),'?'));
  $q=db()->prepare("SELECT id,name,stored_path,mime_type,size_bytes,kind FROM chat_attachments WHERE conversation_id=? AND user_id=? AND message_id IS NULL AND id IN ($marks) ORDER BY id");
  $q->execute(array_merge([$cid,$uid],$attachmentIds)); $attachments=$q->fetchAll();
  if(count($attachments)!==count($attachmentIds)) json_response(['ok'=>false,'error'=>'One or more attachments are no longer available. Please attach them again.'],422);
}
$attachmentNote='';
if($attachments){$lines=[];foreach($attachments as $a)$lines[]=$a['name'].' ('.$a['kind'].', '.$a['mime_type'].', '.(int)$a['size_bytes'].' bytes)';$attachmentNote="\n\nAttached files:\n- ".implode("\n- ",$lines);}
$aiPrompt=$prompt.$attachmentNote;
if(!ai_is_premium(current_user())&&ai_seconds_remaining($uid,current_user())<0.001)json_response(['ok'=>false,'error'=>'Your daily AI active-time allowance is exhausted. Please upgrade your plan.'],429);
$inUnits=0;
$s=db()->prepare('SELECT role,content FROM conversation_messages WHERE conversation_id=? ORDER BY id DESC LIMIT 18');$s->execute([$cid]);$hist=array_reverse($s->fetchAll());$input=[];foreach($hist as $m)$input[]=['role'=>$m['role'],'content'=>$m['content']];$input[]=['role'=>'user','content'=>$aiPrompt];
$started=microtime(true);
[$ok,$answer]=ai_chat_with_input($input,post('agent','0')==='1');if(!$ok){json_response(['ok'=>false,'error'=>$answer],503);}
$inId=db()->prepare('INSERT INTO conversation_messages(conversation_id,role,content,created_at) VALUES(?,?,?,NOW())');$inId->execute([$cid,'user',$prompt]);$userMessageId=(int)$db->lastInsertId();if($attachments){$q=$db->prepare('UPDATE chat_attachments SET message_id=? WHERE id=? AND conversation_id=? AND user_id=? AND message_id IS NULL');foreach($attachments as $a)$q->execute([$userMessageId,(int)$a['id'],$cid,$uid]);}$am=db()->prepare('INSERT INTO conversation_messages(conversation_id,role,content,created_at) VALUES(?,?,?,NOW())');$am->execute([$cid,'assistant',$answer]);$mid=(int)db()->lastInsertId();$activeSeconds=microtime(true)-$started;ai_add_active_time($uid,$activeSeconds,current_user());$outUnits=0;db()->prepare('UPDATE conversations SET title=IF(title=\'New chat\',?,title),updated_at=NOW() WHERE id=?')->execute([mb_substr($prompt,0,70),$cid]);
json_response(['ok'=>true,'conversation_id'=>$cid,'answer'=>$answer,'message_id'=>$mid,'output_units'=>$outUnits,'attachments'=>array_map(fn($a)=>['id'=>(int)$a['id'],'name'=>$a['name'],'mime'=>$a['mime_type'],'size'=>(int)$a['size_bytes'],'kind'=>$a['kind']],$attachments)]);
} catch(Throwable $e){http_response_code(500);json_response(['ok'=>false,'error'=>'AI chat failed: '.$e->getMessage()]);}
function ai_chat_with_input(array $input,bool $agent=false):array{$c=ai_credentials((int)(current_user()['id']??0));if(ai_openai_compatible($c))return $agent?ai_chat_completions_agent_request($input,$c):ai_chat_completions_request($input,$c,4096);return $agent?ai_converse_agent_request($input,$c):ai_converse_request($input,$c);}
