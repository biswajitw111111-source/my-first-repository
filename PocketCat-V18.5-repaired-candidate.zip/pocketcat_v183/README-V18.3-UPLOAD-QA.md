# V18.3 upload implementation and QA notes

## Shared architecture

The existing File Storage uploader continues to use the existing `/api/files.php` session/storage paths, and the Media Library continues to use `/api/upload-chunk.php` and the existing `upload_sessions` persistence. Both are kept inside their original pages and use bounded client concurrency.

## Recovery behavior

- Chunk upload offsets are confirmed through the server status endpoint when a response is lost or uncertain.
- Transient network, timeout, HTTP 429, and HTTP 5xx failures use a bounded exponential retry schedule.
- Pause and cancel abort the in-flight request but preserve the upload session and last confirmed offset for retry/resume.
- Media completion is idempotent when a response is lost after the asset has already been persisted.
- Permanent errors remain visible inline; file-source read failures offer a re-selection action.
- Completed media is added to the existing Media Library DOM and counters without navigation or reload.

## QA checklist for deployment

1. Upload multiple image, audio, video, archive, and document files in both upload areas.
2. Upload a nested directory and verify relative paths/folders.
3. Disconnect the network during a chunk; reconnect and verify server status is probed before resuming.
4. Simulate HTTP 429, 503, and a request timeout; verify the queue remains usable and retries are bounded.
5. Pause/resume, cancel/retry, and remove selected queue items rapidly; check for duplicate requests or stale controls.
6. Lose the local source/read access and verify only the affected item enters File Missing.
7. Verify immediate file/media listing, search, preview, share, download, and counters after completion.
8. Test at 320px, 375px, 768px, and desktop widths; check keyboard operation and reduced-motion settings.

Automated static syntax checks are included in the delivered validation report. A real network/browser/backend integration test requires the target deployment environment.
