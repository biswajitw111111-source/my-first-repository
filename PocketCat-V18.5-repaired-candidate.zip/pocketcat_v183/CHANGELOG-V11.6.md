# PocketCat V11.6 — Hosting Configuration Update

## Changed
- Updated InfinityFree MySQL host to `sql104.infinityfree.com`.
- Updated database name to `if0_42811059_pocketcat_online`.
- Updated database username to `if0_42811059`.
- Updated deployment documentation for `pocketcat.online/htdocs`.
- Recorded current hosting IP `185.27.134.215` and home directory `/home/vol2_8/infinityfree.com/if0_42811059` for deployment reference.
- Updated `.env.example` placeholders to the current database connection values.
- Kept MySQL password, Bedrock API key, relay token, SMTP password and other secrets out of the package.

## No application-code behavior change
This release only updates hosting/deployment configuration defaults and documentation.
