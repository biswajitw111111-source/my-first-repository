(function () {
    'use strict';

    function init() {
        const cfg = window.FILE_PAGE || {};
        const csrf = cfg.csrf || window.POCKETCAT_CSRF || '';
        const queue = document.getElementById('queue');
        const drop = document.getElementById('drop');
        const picker = document.getElementById('picker');
        const folderPicker = document.getElementById('folderPicker');
        const grid = document.getElementById('fileGrid');
        if (!queue || !drop || !picker) return;

        const uploads = new Map();
        const MAX_CONCURRENT_UPLOADS = Math.max(1, Math.min(5, Number(window.POCKETCAT_UPLOAD_CONCURRENCY || 3)));
        const RETRY_DELAYS = [2000, 5000, 10000, 20000, 30000];
        const toast = (message) => { let n=document.getElementById('pcUploadToast'); if(!n){n=document.createElement('div');n.id='pcUploadToast';n.className='pc-upload-toast';n.setAttribute('role','status');n.setAttribute('aria-live','polite');document.body.appendChild(n);} n.textContent=message;n.hidden=false;clearTimeout(n._timer);n._timer=setTimeout(()=>n.hidden=true,3500); };
        let activeUploads = 0;
        let raf = 0;

        const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (m) => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'
        }[m]));

        const formatBytes = (bytes) => {
            const n = Math.max(0, Number(bytes) || 0);
            if (n < 1024) return n.toFixed(0) + ' B';
            const units = ['KB', 'MB', 'GB', 'TB'];
            let value = n / 1024;
            let i = 0;
            while (value >= 1024 && i < units.length - 1) {
                value /= 1024;
                i++;
            }
            const decimals = value >= 100 ? 0 : value >= 10 ? 1 : 2;
            return value.toFixed(decimals) + ' ' + units[i];
        };

        const formatSpeed = (bytesPerSecond) => {
            const n = Number(bytesPerSecond) || 0;
            return n > 0 ? formatBytes(n) + '/s' : '—';
        };

        const formatEta = (seconds) => {
            if (!Number.isFinite(seconds) || seconds < 0 || seconds > 864000) return 'Calculating…';
            const s = Math.ceil(seconds);
            if (s < 60) return s + 's';
            const m = Math.floor(s / 60);
            const r = s % 60;
            if (m < 60) return m + 'm ' + r + 's';
            const h = Math.floor(m / 60);
            return h + 'h ' + (m % 60) + 'm';
        };

        const fileTypeIcon = (f) => { const n=String(f.name||'').toLowerCase(),m=String(f.type||'').toLowerCase(); if(m.startsWith('image/'))return '🖼️ Image';if(m.startsWith('video/'))return '🎬 Video';if(m.startsWith('audio/'))return '🎵 Audio';if(/\.(zip|rar|7z|tar|gz|bz2)$/.test(n))return '🗜️ Archive';if(/\.(pdf|docx?|xlsx?|pptx?|txt|csv|json|md)$/.test(n)||m.includes('document')||m==='application/pdf')return '📄 Document';return '📁 File'; };
        const makeCard = (f) => {
            const d = document.createElement('div');
            d.className = 'upload-card card';
            d.innerHTML = `
                <div class="upload-head">
                    <label class="upload-select-label"><input type="checkbox" class="upload-select" aria-label="Select upload"></label><span class="upload-type-icon">${esc(fileTypeIcon(f))}</span><div class="upload-title-wrap"><b class="upload-name"></b><span class="upload-path"></span></div>
                    <span class="status">Preparing…</span>
                </div>
                <div class="upload-progress-track"><i></i></div>
                <div class="upload-metrics">
                    <span class="upload-size">Upload size: ${esc(formatBytes(f.size))}</span>
                    <span class="upload-percent">Progress: 0% / 100%</span>
                    <span class="upload-speed">Network speed: —</span>
                    <span class="upload-eta">ETA: Calculating…</span>
                </div>
                <div class="upload-actions"></div>
            `;
            d.querySelector('.upload-name').textContent = f.name;
            d.querySelector('.upload-path').textContent = f.webkitRelativePath || '';
            queue.prepend(d);
            return d;
        };

        const ensureMetrics = () => {
            let box = document.getElementById('uploadMetrics');
            if (box) return box;
            box = document.createElement('div');
            box.id = 'uploadMetrics';
            box.className = 'upload-live-summary';
            box.innerHTML = `
                <div><span>Upload progress</span><strong data-metric="progress">0% / 100%</strong></div>
                <div><span>Upload size</span><strong data-metric="bytes">0 B / 0 B</strong></div>
                <div><span>Network speed</span><strong data-metric="speed">—</strong></div>
                <div><span>ETA</span><strong data-metric="eta">—</strong></div>
                <div><span>Queue</span><strong data-metric="queue">0 active · 0 queued</strong></div>
            `;
            queue.before(box);
            return box;
        };

        const setStatus = (state, text) => {
            state.card.querySelector('.status').textContent = text;
            state.card.dataset.state = state.phase;
        };

        const updateCard = (state, force = false) => {
            const now = performance.now();
            const elapsed = Math.max(0.001, (now - state.startedAt) / 1000);
            const uploaded = Math.min(state.total, Math.max(0, state.uploaded));
            state.speed = uploaded > state.speedBaseBytes ? (uploaded - state.speedBaseBytes) / Math.max(0.001, (now - state.speedBaseTime) / 1000) : 0;
            if (now - (state.lastProgressAt || now) > 2000) state.speed = 0;
            if (uploaded >= state.total) state.speed = state.lastSpeed || state.speed;
            state.lastSpeed = state.speed || state.lastSpeed;
            const percent = state.total ? Math.min(100, (uploaded / state.total) * 100) : 0;
            const eta = state.speed > 0 ? (state.total - uploaded) / state.speed : Infinity;

            state.card.querySelector('.upload-progress-track i').style.width = percent.toFixed(2) + '%';
            state.card.querySelector('.upload-size').textContent = 'Upload size: ' + formatBytes(uploaded) + ' / ' + formatBytes(state.total);
            state.card.querySelector('.upload-percent').textContent = 'Progress: ' + percent.toFixed(percent < 10 ? 1 : 0) + '% / 100%';
            state.card.querySelector('.upload-speed').textContent = 'Network speed: ' + formatSpeed(state.speed);
            state.card.querySelector('.upload-eta').textContent = 'ETA: ' + (uploaded >= state.total ? 'Complete' : formatEta(eta));
            state.lastUpdate = now;

            if (force || now - state.speedBaseTime >= 500) {
                state.speedBaseBytes = uploaded;
                state.speedBaseTime = now;
            }
            state.elapsed = elapsed;
        };

        const ensureBatchActions = () => {
            let box = document.getElementById('uploadBatchActions');
            if (box) return box;
            box = document.createElement('div');
            box.id = 'uploadBatchActions';
            box.className = 'upload-batch-actions';
            box.innerHTML = '<label><input type="checkbox" id="uploadSelectAll"> Select all</label><button type="button" class="btn small upload-pause-selected">Pause selected</button><button type="button" class="btn small secondary upload-resume-selected">Resume selected</button><button type="button" class="btn small upload-retry-all">Retry failed</button><button type="button" class="btn small secondary upload-cancel-all">Cancel active uploads</button><button type="button" class="btn small secondary upload-remove-selected">Remove selected</button>';
            queue.before(box);
            box.querySelector('#uploadSelectAll').onchange = (e) => [...uploads.values()].forEach(s => { const c=s.card.querySelector('.upload-select'); if(c)c.checked=e.target.checked; });
            box.querySelector('.upload-pause-selected').onclick = () => [...uploads.values()].filter(s=>s.card.querySelector('.upload-select')?.checked).forEach(pauseUpload);
            box.querySelector('.upload-resume-selected').onclick = () => [...uploads.values()].filter(s=>s.card.querySelector('.upload-select')?.checked).forEach(resumeUpload);
            box.querySelector('.upload-remove-selected').onclick = () => [...uploads.values()].filter(s=>s.card.querySelector('.upload-select')?.checked).forEach(removeUpload);
            box.querySelector('.upload-retry-all').onclick = () => {
                [...uploads.values()].filter((s) => s.phase === 'error' || s.phase === 'cancelled').forEach((s) => enqueueUpload(s, true));
            };
            box.querySelector('.upload-cancel-all').onclick = () => {
                [...uploads.values()].filter((s) => ['queued','preparing','uploading','retrying'].includes(s.phase)).forEach((s) => cancelUpload(s));
            };
            return box;
        };

        const renderSummary = () => {
            raf = 0;
            const now = performance.now();
            const active = [...uploads.values()].filter((s) => s.phase === 'uploading' || s.phase === 'retrying' || s.phase === 'preparing');
            const all = [...uploads.values()];
            const visible = all.filter((s) => s.phase !== 'done');
            const total = all.reduce((n, s) => n + s.total, 0);
            const uploaded = all.reduce((n, s) => n + Math.min(s.total, s.uploaded), 0);
            const speed = active.reduce((n, s) => n + (now - (s.lastProgressAt || now) <= 2000 ? (s.lastSpeed || s.speed || 0) : 0), 0);
            const eta = speed > 0 ? Math.max(0, total - uploaded) / speed : Infinity;
            const box = ensureMetrics();
            const batchActions = ensureBatchActions();
            const failedCount = all.filter((s) => s.phase === 'error' || s.phase === 'cancelled').length;
            batchActions.querySelector('.upload-pause-selected').disabled = !all.some(s=>s.card.querySelector('.upload-select')?.checked && ['uploading','preparing','retrying'].includes(s.phase));
            batchActions.querySelector('.upload-resume-selected').disabled = !all.some(s=>s.card.querySelector('.upload-select')?.checked && s.phase==='paused');
            batchActions.querySelector('.upload-remove-selected').disabled = !all.some(s=>s.card.querySelector('.upload-select')?.checked);
            const cancellableCount = all.filter((s) => ['queued','preparing','uploading','retrying'].includes(s.phase)).length;
            batchActions.hidden = !all.length;
            batchActions.querySelector('.upload-retry-all').disabled = failedCount === 0;
            batchActions.querySelector('.upload-cancel-all').disabled = cancellableCount === 0;
            const pct = total ? Math.min(100, uploaded / total * 100) : 0;
            box.querySelector('[data-metric="progress"]').textContent = pct.toFixed(pct < 10 ? 1 : 0) + '% / 100%';
            box.querySelector('[data-metric="bytes"]').textContent = formatBytes(uploaded) + ' / ' + formatBytes(total);
            box.querySelector('[data-metric="speed"]').textContent = formatSpeed(speed);
            box.querySelector('[data-metric="eta"]').textContent = active.length ? formatEta(eta) : (all.length && uploaded >= total ? 'Complete' : '—');
            const queued = [...uploads.values()].filter((s) => s.phase === 'queued').length;
            box.querySelector('[data-metric="queue"]').textContent = active.length + ' active · ' + queued + ' queued';
            box.hidden = !all.length;
        };

        const scheduleRender = () => {
            if (!raf) raf = requestAnimationFrame(renderSummary);
        };

        const xhrRequest = (url, options, state, baseLoaded = 0) => new Promise((resolve, reject) => {
            const xhr = new XMLHttpRequest();
            state.xhr = xhr;
            xhr.open(options.method || 'POST', url, true);
            if (options.headers) Object.entries(options.headers).forEach(([k, v]) => xhr.setRequestHeader(k, v));
            xhr.responseType = 'text';
            let lastEventAt = performance.now();
            let uploadComplete = false;
            let stallTimer = 0;
            let settled = false;

            const clear = () => {
                if (stallTimer) clearInterval(stallTimer);
                stallTimer = 0;
                if (state.xhr === xhr) state.xhr = null;
            };

            const fail = (message) => {
                if (settled) return;
                settled = true;
                clear();
                reject(new Error(message));
            };

            if (xhr.upload) {
                xhr.upload.onprogress = (event) => {
                    if (!event.lengthComputable) return;
                    lastEventAt = performance.now();
                    uploadComplete = event.loaded >= event.total;
                    state.uploaded = Math.min(state.total, baseLoaded + event.loaded);
                    state.lastProgressAt = lastEventAt;
                    updateCard(state);
                    scheduleRender();
                };
            }

            xhr.onprogress = () => {
                lastEventAt = performance.now();
            };

            xhr.upload?.addEventListener?.('load', () => { uploadComplete = true; lastEventAt = performance.now(); });

            xhr.onload = () => {
                if (settled) return;
                settled = true;
                clear();
                let body = {};
                try { body = xhr.responseText ? JSON.parse(xhr.responseText) : {}; } catch (_) {}
                if (xhr.status >= 200 && xhr.status < 300) return resolve({ xhr, body });
                reject(new Error(body.error || ('Upload request failed (HTTP ' + xhr.status + ').')));
            };
            xhr.onerror = () => fail('Network error while uploading.');
            xhr.onabort = () => fail(state.stalled ? 'Upload stalled. Check the network connection and retry.' : 'Upload cancelled.');
            xhr.ontimeout = () => fail('Upload request timed out. Check the network connection and retry.');
            xhr.timeout = 0;

            stallTimer = window.setInterval(() => {
                if (settled) return;
                if (!uploadComplete && state.uploaded < state.total && performance.now() - lastEventAt > 30000) {
                    state.stalled = true;
                    try { xhr.abort(); } catch (_) {}
                }
            }, 2000);

            xhr.send(options.body || null);
        });

        const readJsonFetch = async (url, options) => {
            const response = await fetch(url, options);
            const text = await response.text();
            let body = {};
            try { body = JSON.parse(text); } catch (_) {}
            if (!response.ok) throw new Error(body.error || ('Server error ' + response.status) + (body.request_id ? ' — ' + body.request_id : ''));
            return body;
        };

        const api = (action, data) => readJsonFetch('/api/files.php?action=' + encodeURIComponent(action), {
            method: 'POST',
            headers: {'Content-Type': 'application/json', 'Accept': 'application/json', 'X-CSRF-Token': csrf},
            body: JSON.stringify(data)
        });

        const createFileCard = (f) => {
            if (!grid || !f || !f.id) return;
            const id = Number(f.id);
            const existing = document.getElementById('file-' + id);
            if (existing) return existing;
            const kind = String(f.kind || 'file');
            const mime = String(f.mime_type || 'application/octet-stream');
            const token = String(f.public_token || '');
            const previewUrl = token ? ('/file/' + encodeURIComponent(token)) : '#';
            const downloadUrl = token ? ('/file/download/?id=' + id + '&token=' + encodeURIComponent(token) + '&download=1') : '#';
            const article = document.createElement('article');
            article.id = 'file-' + id;
            article.className = 'file-card file-card-new';
            article.dataset.fileId = String(id);
            article.dataset.name = String((f.original_name || '') + ' ' + (f.relative_path || '')).toLowerCase();
            article.dataset.kind = kind;
            const icon = kind.charAt(0).toUpperCase();
            let preview = '<span>' + esc(kind.toUpperCase()) + '</span>';
            if (mime.startsWith('image/') && token) preview = '<img src="' + esc('/file/' + encodeURIComponent(token)) + '" alt="">';
            else if (mime.startsWith('video/')) preview = '<span>▶ Video</span>';
            else if (mime.startsWith('audio/')) preview = '<span>♫ Audio</span>';
            else if (mime === 'application/pdf') preview = '<span>PDF</span>';
            article.innerHTML = `
                <div class="file-card-top"><input class="file-select" type="checkbox" value="${id}"><div class="file-icon">${esc(icon)}</div><div class="file-main"><strong title="${esc(f.original_name || '')}">${esc(f.original_name || '')}</strong><span class="muted">${esc(f.relative_path || '')}</span></div><details class="file-menu"><summary>•••</summary><div class="file-menu-pop"><a href="${esc(previewUrl)}" target="_blank">Preview</a><a href="/links/?edit=" aria-disabled="true">Edit Link</a><a href="/qr/file-${esc(token)}" target="_blank">Customize QR</a><button type="button" class="native-share" data-share-url="${esc(previewUrl)}">Share</button><a aria-disabled="true">Analytics</a><a href="${esc(downloadUrl)}">Download</a><button type="button" class="delete-file" data-id="${id}">Delete</button></div></details></div>
                <div class="file-preview-mini">${preview}</div>
                <div class="file-meta"><span>${esc(formatBytes(f.size_bytes || f.size || 0))}</span><span>0 downloads</span><span class="pill">${esc(f.scan_status || f.status || 'clean')}</span></div>
                <div class="file-link-strip"><span>Not shared</span><button type="button" class="quick-share" data-id="${id}">Create link</button></div>
            `;
            grid.prepend(article);
            bindFileActions(article);
            const stat = document.getElementById('fileCountStat');
            if (stat) stat.textContent = String(grid.querySelectorAll('.file-card').length);
            return article;
        };

        const bindFileActions = (root = document) => {
            root.querySelectorAll('.delete-file').forEach((b) => {
                if (b.dataset.bound) return;
                b.dataset.bound = '1';
                b.onclick = async () => {
                    if (!confirm('Delete this file?')) return;
                    try { await api('delete', {id: Number(b.dataset.id)}); b.closest('.file-card')?.remove(); } catch (e) { alert(e.message); }
                };
            });
            root.querySelectorAll('.native-share').forEach((b) => {
                if (b.dataset.bound) return;
                b.dataset.bound = '1';
                b.onclick = () => {
                    const u = b.dataset.shareUrl;
                    if (navigator.share) navigator.share({title: 'PocketCat file', url: u}).catch(() => {});
                    else if (navigator.clipboard) navigator.clipboard.writeText(u).then(() => alert('Link copied.'));
                };
            });
            root.querySelectorAll('.quick-share').forEach((b) => {
                if (b.dataset.bound) return;
                b.dataset.bound = '1';
                b.addEventListener('click', () => {
                    document.querySelectorAll('.file-select').forEach((x) => x.checked = Number(x.value) === Number(b.dataset.id));
                    document.getElementById('selectionCount').textContent = '1 selected';
                    document.getElementById('createShare')?.click();
                });
            });
        };

        const fetchCompletedFile = async (id) => {
            const url = '/api/files.php?action=status&id=' + encodeURIComponent(id);
            const f = await readJsonFetch(url, {method: 'GET', headers: {'Accept': 'application/json'}});
            createFileCard(f);
        };

        const setQueuedActions = (state) => {
            const actions = state.card.querySelector('.upload-actions');
            actions.innerHTML = '<button type="button" class="btn small secondary upload-pause">Pause</button><button type="button" class="btn small secondary upload-cancel">Cancel</button>';
            actions.querySelector('.upload-cancel').onclick = () => cancelUpload(state);
            actions.querySelector('.upload-pause').onclick = () => pauseUpload(state);
        };

        const pumpQueue = () => {
            while (activeUploads < MAX_CONCURRENT_UPLOADS) {
                const next = [...uploads.values()].find((s) => s.phase === 'queued' && !s.cancelled && !s.running);
                if (!next) break;
                activeUploads++;
                const retry = !!next.retryRequested;
                next.phase = retry ? 'retrying' : 'preparing';
                runUpload(next, retry).finally(() => {
                    activeUploads = Math.max(0, activeUploads - 1);
                    pumpQueue();
                });
            }
            scheduleRender();
        };

        const enqueueUpload = (state, retry = false) => {
            if (state.phase === 'done' || state.running) return;
            state.cancelled = false;
            state.retryRequested = !!retry;
            state.phase = 'queued';
            state.card.classList.remove('upload-error');
            setStatus(state, retry ? 'Queued for retry…' : 'Queued…');
            setQueuedActions(state);
            scheduleRender();
            pumpQueue();
        };

        const setError = (state, message) => {
            state.phase = 'error';
            state.card.classList.add('upload-error');
            setStatus(state, message || 'Upload failed.');
            const actions = state.card.querySelector('.upload-actions');
            actions.innerHTML = '<button type="button" class="btn small upload-retry">Retry upload</button><button type="button" class="btn small secondary upload-cancel">Cancel</button>';
            actions.querySelector('.upload-retry').onclick = () => enqueueUpload(state, true);
            actions.querySelector('.upload-cancel').onclick = () => cancelUpload(state);
            scheduleRender();
        };

        const cancelUpload = async (state) => {
            if (state.phase === 'done' || state.phase === 'cancelled') return;
            state.cancelled = true;
            state.phase = 'cancelled';
            setStatus(state, 'Cancelling…');
            const xhr = state.xhr;
            if (xhr) { try { xhr.abort(); } catch (_) {} }
            clearTimeout(state.retryTimer);
            /* Keep the server session and verified offset so Retry can resume safely. */
            state.phase = 'cancelled';
            state.card.classList.remove('upload-error');
            setStatus(state, 'Cancelled');
            state.card.querySelector('.upload-actions').innerHTML = '<button type="button" class="btn small upload-retry">Retry upload</button>';
            state.card.querySelector('.upload-retry').onclick = () => enqueueUpload(state, true);
            updateCard(state, true);
            scheduleRender();
        };

        const setUploadingActions = (state) => {
            const actions = state.card.querySelector('.upload-actions');
            actions.innerHTML = '<button type="button" class="btn small secondary upload-pause">Pause</button><button type="button" class="btn small secondary upload-cancel">Cancel</button>';
            actions.querySelector('.upload-cancel').onclick = () => cancelUpload(state);
            actions.querySelector('.upload-pause').onclick = () => pauseUpload(state);
        };

        const pauseUpload = (state) => { if (!state || !['uploading','preparing','retrying','queued'].includes(state.phase)) return; state.paused=true; state.phase='paused'; state.card.querySelector('.status').textContent='Paused'; try{state.xhr?.abort()}catch(_){} state.card.dataset.state='paused'; state.card.querySelector('.upload-actions').innerHTML='<button type="button" class="btn small upload-resume">Resume</button><button type="button" class="btn small secondary upload-cancel">Cancel</button>'; state.card.querySelector('.upload-resume').onclick=()=>resumeUpload(state); state.card.querySelector('.upload-cancel').onclick=()=>cancelUpload(state); scheduleRender(); };
        const resumeUpload = (state) => { if(!state || state.phase!=='paused') return; state.paused=false; enqueueUpload(state,true); };
        const removeUpload = (state) => { if(!state) return; state.removed=true; state.cancelled=true; clearTimeout(state.retryTimer); try{state.xhr?.abort()}catch(_){} uploads.delete(state.id); state.card.remove(); scheduleRender(); pumpQueue(); };
        const isMissingError = (e) => /file not found|file is not readable|invalidstateerror|could not read|source file unavailable/i.test(String(e?.message||''));
        const markFileMissing = (state, error) => { state.phase='missing';state.error=error?.message||'The selected local file is no longer readable.';state.card.classList.add('upload-error');setStatus(state,'File Missing');let warning=state.card.querySelector('.upload-missing-warning');if(!warning){warning=document.createElement('div');warning.className='upload-missing-warning';warning.setAttribute('role','alert');state.card.querySelector('.upload-metrics').after(warning)}warning.textContent='File Not Found: This file is no longer readable from the selected local source. Re-select the original file to continue.';const actions=state.card.querySelector('.upload-actions');actions.innerHTML='<button type="button" class="btn small upload-reselect">Re-select File</button><button type="button" class="btn small secondary upload-cancel">Cancel</button>';const input=document.createElement('input');input.type='file';input.hidden=true;input.setAttribute('aria-label','Re-select '+state.file.name);state.card.appendChild(input);actions.querySelector('.upload-reselect').onclick=()=>input.click();input.onchange=()=>{const f=input.files?.[0];if(!f)return;if(f.name!==state.file.name||f.size!==state.total){warning.textContent='Selected file does not match the original filename and size. Choose the original file.';return}state.file=f;state.cancelled=false;state.paused=false;state.card.querySelector('.upload-path').textContent=f.webkitRelativePath||f.name;warning.remove();enqueueUpload(state,true)};actions.querySelector('.upload-cancel').onclick=()=>cancelUpload(state);scheduleRender();};
        const isTemporaryError = (e) => { const m=String(e?.message||'').toLowerCase(); return !navigator.onLine || /network|timeout|timed out|http 429|http 5\d\d|server error 429|server error 5\d\d|stalled|failed to fetch|upload aborted/i.test(m); };
        const scheduleRetry = (state, error) => { if(state.cancelled||state.paused||state.removed)return; state.retryCount=(state.retryCount||0)+1; const delay=RETRY_DELAYS[Math.min(state.retryCount-1,RETRY_DELAYS.length-1)]; state.phase=navigator.onLine?'retrying':'waiting-network'; setStatus(state, navigator.onLine?'Retrying (Network/Server) in '+Math.round(delay/1000)+'s':'Waiting for Network'); state.card.classList.add('upload-error'); state.card.querySelector('.upload-actions').innerHTML='<button type="button" class="btn small secondary upload-cancel">Cancel</button><button type="button" class="btn small" disabled>Auto-retry scheduled</button>'; state.card.querySelector('.upload-cancel').onclick=()=>cancelUpload(state); state.retryTimer=setTimeout(()=>{if(state.removed||state.cancelled||state.paused)return; if(!navigator.onLine){state.phase='waiting-network';setStatus(state,'Waiting for Network');scheduleRetry(state,error);return;} state.retryRequested=true;enqueueUpload(state,true);},delay); scheduleRender(); };
        window.addEventListener('online',()=>[...uploads.values()].filter(s=>s.phase==='waiting-network'&&!s.retryTimer).forEach(s=>scheduleRetry(s,Error('Network restored'))));

        const uploadLocalChunked = async (state) => {
            const x = state.session;
            const chunk = Math.max(131072, Math.min(Number(x.chunk_size || 524288), Number(x.max_bytes || 524288)));
            let start = state.offset || 0;
            while (start < state.total) {
                if (state.cancelled || state.removed) throw new Error('Upload cancelled.');
                if (state.paused) throw new Error('Upload paused.');
                state.phase = 'uploading';
                state.stalled = false;
                const end = Math.min(state.total, start + chunk);
                let result = null;
                let lastError = null;
                for (let attempt = 0; attempt < 3; attempt++) {
                    try {
                        const fd = new FormData();
                        fd.append('id', x.id);
                        fd.append('start', String(start));
                        fd.append('total', String(state.total));
                        fd.append('chunk', state.file.slice(start, end, state.file.type || 'application/octet-stream'), state.file.name + '.part');
                        result = await xhrRequest('/api/files.php?action=local_chunk', {
                            method: 'POST',
                            headers: {'Accept': 'application/json', 'X-CSRF-Token': csrf},
                            body: fd
                        }, state, start);
                        lastError = null;
                        break;
                    } catch (e) {
                        if (state.cancelled || state.paused || state.removed) throw e;
                        lastError = e;
                        // A lost response can mean the server already appended the chunk.
                        // Ask the server for the authoritative offset before retrying.
                        try {
                            const probe = await readJsonFetch('/api/files.php?action=local_status&id=' + encodeURIComponent(x.id), {
                                method: 'GET', headers: {'Accept': 'application/json'}
                            });
                            const received = Number(probe.received || 0);
                            if (received > start) {
                                start = Math.min(state.total, received);
                                state.offset = start;
                                state.uploaded = start;
                                updateCard(state, true);
                                scheduleRender();
                                lastError = null;
                                break;
                            }
                        } catch (_) {}
                        if (attempt < 2) await new Promise((r) => setTimeout(r, 500 * (attempt + 1)));
                    }
                }
                if (lastError) throw lastError;
                if (!result) continue;
                const received = Number(result.body.received || end);
                start = Math.max(start, received);
                state.offset = start;
                state.uploaded = start;
                state.lastProgressAt = performance.now();
                updateCard(state, true);
                scheduleRender();
                if (result.body.complete) return result.body;
            }
            return {id: x.id, status: 'pending_scan', public_url: x.public_url};
        };

        const uploadServer = async (state) => {
            const x = state.session;
            const fd = new FormData();
            fd.append('id', String(x.id));
            fd.append('file', state.file, state.file.name);
            const result = await xhrRequest('/api/files.php?action=server_upload', {
                method: 'POST', headers: {'Accept': 'application/json', 'X-CSRF-Token': csrf}, body: fd
            }, state, 0);
            state.uploaded = state.total;
            return result.body;
        };

        const uploadSingle = async (state) => {
            const result = await xhrRequest(state.session.upload_url, {
                method: 'PUT', headers: {'Content-Type': state.file.type || 'application/octet-stream'}, body: state.file
            }, state, 0);
            state.uploaded = state.total;
            const body = await api('complete', {id: Number(state.session.id)});
            return body;
        };

        const uploadMultipart = async (state) => {
            const x = state.session;
            if (!state.parts) state.parts = [];
            const partSize = Number(x.part_size || 104857600);
            for (let i = state.currentPart || 1; i <= x.parts.length; i++) {
                state.currentPart = i;
                const start = (i - 1) * partSize;
                const end = Math.min(state.total, i * partSize);
                const part = state.file.slice(start, end, state.file.type || 'application/octet-stream');
                const result = await xhrRequest(x.parts[i - 1], {
                    method: 'PUT', headers: {'Content-Type': state.file.type || 'application/octet-stream'}, body: part
                }, state, start);
                const etag = (result.xhr.getResponseHeader('ETag') || '').replaceAll('"', '');
                state.parts = state.parts.filter((p) => p.part !== i);
                state.parts.push({part: i, etag});
                state.parts.sort((a, b) => a.part - b.part);
                state.uploaded = end;
                updateCard(state, true);
                setStatus(state, 'Uploaded ' + i + '/' + x.parts.length + ' parts');
                scheduleRender();
                state.currentPart = i + 1;
            }
            return await api('complete', {id: Number(x.id), parts: state.parts});
        };

        async function runUpload(state, retry) {
            if (state.running || state.removed || state.phase==='paused') return;
            state.running = true;
            state.phase = retry ? 'retrying' : 'preparing';
            state.retryRequested = false;
            state.stalled = false;
            state.cancelled = false;
            state.card.classList.remove('upload-error');
            state.card.querySelector('.upload-actions').innerHTML = '';
            setStatus(state, retry ? 'Retrying…' : 'Preparing…');
            if (!retry) {
                state.startedAt = performance.now();
                state.speedBaseTime = state.startedAt;
                state.speedBaseBytes = state.uploaded;
            } else {
                state.lastProgressAt = performance.now();
            }
            scheduleRender();
            try {
                if (!state.session) {
                    state.session = await api('create', {
                        name: state.file.name,
                        size: state.file.size,
                        mime: state.file.type || 'application/octet-stream',
                        relative_path: state.file.webkitRelativePath || state.file.name
                    });
                }
                if (state.cancelled) throw new Error('Upload cancelled.');
                if (state.session.name) {
                    state.card.querySelector('.upload-name').textContent = state.session.name;
                }
                setUploadingActions(state);
                let result;
                if (state.session.mode === 'local') result = await uploadLocalChunked(state);
                else if (state.session.mode === 'server') result = await uploadServer(state);
                else if (state.session.mode === 'single') result = await uploadSingle(state);
                else if (state.session.mode === 'multipart') result = await uploadMultipart(state);
                else throw new Error('Unsupported upload mode.');

                state.uploaded = state.total;
                state.phase = 'done';
                state.retryCount=0; clearTimeout(state.retryTimer);
                updateCard(state, true);
                setStatus(state, result.status === 'clean' ? 'Uploaded successfully' : 'Uploaded · scanning');
                toast('Upload complete: ' + (state.session.name || state.file.name));
                state.card.classList.add('upload-success');
                state.card.querySelector('.upload-actions').innerHTML = '<span class="upload-complete-badge">✓ Ready in Files</span>';
                try {
                    await fetchCompletedFile(Number(state.session.id));
                } catch (_) {
                    /* The upload itself succeeded; leave the success state visible. */
                }
                scheduleRender();
            } catch (e) {
                if (state.removed) return;
                if (state.paused) { state.phase='paused'; setStatus(state,'Paused'); state.card.querySelector('.upload-actions').innerHTML='<button type="button" class="btn small upload-resume">Resume</button><button type="button" class="btn small secondary upload-cancel">Cancel</button>';state.card.querySelector('.upload-resume').onclick=()=>resumeUpload(state);state.card.querySelector('.upload-cancel').onclick=()=>cancelUpload(state); } else if (state.cancelled) {
                    state.phase = 'cancelled';
                    setStatus(state, 'Cancelled');
                    state.card.querySelector('.upload-actions').innerHTML = '<button type="button" class="btn small upload-retry">Retry upload</button>';
                    state.card.querySelector('.upload-retry').onclick = () => enqueueUpload(state, true);
                } else if (isMissingError(e)) { markFileMissing(state,e); } else if (isTemporaryError(e)) { scheduleRetry(state,e); } else { setError(state, e.message || 'Upload failed.'); }
            } finally {
                state.running = false;
                scheduleRender();
            }
        }

        const add = (list) => {
            const files = [...list].filter((file) => file && Number(file.size || 0) > 0);
            files.forEach((file) => {
                const state = {
                    id: 'up-' + Date.now() + '-' + Math.random().toString(36).slice(2),
                    retryCount: 0, paused: false, removed: false, retryTimer: 0,
                    file,
                    total: Number(file.size || 0),
                    uploaded: 0,
                    offset: 0,
                    currentPart: 1,
                    parts: [],
                    phase: 'queued',
                    card: null,
                    session: null,
                    running: false,
                    cancelled: false,
                    retryRequested: false,
                    speed: 0,
                    lastSpeed: 0,
                    speedBaseBytes: 0,
                    speedBaseTime: performance.now(),
                    lastProgressAt: performance.now()
                };
                state.card = makeCard(file);
                uploads.set(state.id, state);
                setStatus(state, 'Queued…');
                setQueuedActions(state);
            });
            picker.value = '';
            scheduleRender();
            pumpQueue();
        };

        picker.addEventListener('change', () => add(picker.files));
        folderPicker?.addEventListener('change', () => { add(folderPicker.files); folderPicker.value = ''; });
        document.getElementById('bulkUpload')?.addEventListener('click', () => picker.click());
        ['dragenter', 'dragover'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('drag'); }));
        ['dragleave', 'drop'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove('drag'); }));
        const droppedFiles = async (dt) => {
            const direct = [...(dt?.files || [])];
            const items = [...(dt?.items || [])];
            if (!items.length) return direct;
            const out = [];
            const walk = async (entry, path = '') => {
                if (!entry) return;
                if (entry.isFile) {
                    await new Promise((resolve) => entry.file((file) => {
                        try { Object.defineProperty(file, 'webkitRelativePath', {value: path + file.name, configurable: true}); } catch (_) {}
                        out.push(file); resolve();
                    }, resolve));
                    return;
                }
                if (entry.isDirectory) {
                    const reader = entry.createReader();
                    await new Promise((resolve) => {
                        const read = () => reader.readEntries(async (entries) => {
                            if (!entries.length) return resolve();
                            for (const child of entries) await walk(child, path + entry.name + '/');
                            read();
                        }, resolve);
                        read();
                    });
                }
            };
            for (const item of items) {
                const entry = item.webkitGetAsEntry?.();
                if (entry) await walk(entry);
                else { const file = item.getAsFile?.(); if (file) out.push(file); }
            }
            return out.length ? out : direct;
        };
        drop.addEventListener('drop', async (e) => add(await droppedFiles(e.dataTransfer)));
        document.getElementById('choose')?.addEventListener('click', () => picker.click());
        document.getElementById('chooseFolder')?.addEventListener('click', () => folderPicker?.click());

        const search = document.getElementById('fileSearch');
        const kind = document.getElementById('kindFilter');
        const filter = () => {
            const text = (search?.value || '').toLowerCase();
            const k = kind?.value || '';
            grid?.querySelectorAll('.file-card').forEach((c) => {
                c.hidden = !!((text && !c.dataset.name.includes(text)) || (k && c.dataset.kind !== k));
            });
        };
        search?.addEventListener('input', filter);
        kind?.addEventListener('change', filter);
        document.getElementById('tableToggle')?.addEventListener('click', (e) => { grid.classList.toggle('table-view'); e.currentTarget.textContent = grid.classList.contains('table-view') ? 'Grid view' : 'Table view'; });

        const count = () => {
            const n = document.querySelectorAll('.file-select:checked').length;
            const el = document.getElementById('selectionCount');
            if (el) el.textContent = n + ' selected';
            return n;
        };
        document.addEventListener('change', (e) => { if (e.target.classList.contains('file-select')) count(); });
        document.getElementById('selectAllFiles')?.addEventListener('change', (e) => { document.querySelectorAll('.file-select').forEach((x) => x.checked = e.target.checked); count(); });
        const refreshFileCard = (id, name, path) => {
            const card = document.getElementById('file-' + id); if (!card) return;
            const title = card.querySelector('.file-main strong'); if (title) { title.textContent = name; title.title = name; }
            const sub = card.querySelector('.file-main .muted'); if (sub) sub.textContent = path || '';
            card.dataset.name = (name + ' ' + (path || '')).toLowerCase();
        };
        const selectedIds = () => [...document.querySelectorAll('.file-select:checked')].map(x => Number(x.value));
        document.getElementById('newFolder')?.addEventListener('click', async () => {
            const path = prompt('New folder path (e.g. Projects/2026):'); if (!path) return;
            const b = document.getElementById('newFolder'); b.disabled = true;
            try { const r = await api('folder_create', {path}); alert('Folder created: ' + r.path); }
            catch (e) { alert(e.message || 'Folder creation failed.'); }
            finally { b.disabled = false; }
        });
        document.getElementById('renameSelected')?.addEventListener('click', async () => {
            const ids = selectedIds(); if (ids.length !== 1) return alert('Select exactly one file to rename.');
            const card = document.getElementById('file-' + ids[0]); const current = card?.querySelector('.file-main strong')?.textContent || '';
            const name = prompt('New filename:', current); if (!name || name === current) return;
            try { const r = await api('rename', {id: ids[0], name}); refreshFileCard(ids[0], r.name, r.relative_path); }
            catch (e) { alert(e.message || 'Rename failed.'); }
        });
        document.getElementById('moveSelected')?.addEventListener('click', async () => {
            const ids = selectedIds(); if (!ids.length) return alert('Select one or more files to move.');
            const folder = prompt('Destination folder path (leave blank for root):', ''); if (folder === null) return;
            try { const r = await api('move', {ids, folder}); ids.forEach(id=>{const c=document.getElementById('file-'+id);if(c){const path=c.querySelector('.file-main .muted');const name=c.querySelector('.file-main strong')?.textContent||'';if(path)path.textContent=(folder?folder+'/':'')+name;c.dataset.name=((folder?folder+'/':'')+name).toLowerCase();}}); filter(); alert(`Move complete: ${r.moved} moved, ${r.skipped} skipped due to name conflicts.`); }
            catch (e) { alert(e.message || 'Move failed.'); }
        });
        document.getElementById('deleteSelected')?.addEventListener('click', async () => {
            const ids = selectedIds(); if (!ids.length) return alert('Select files to delete.');
            if (!confirm(`Delete ${ids.length} selected file(s)? This cannot be undone.`)) return;
            const b = document.getElementById('deleteSelected'); b.disabled = true;
            try { const r = await api('delete_bulk', {ids}); ids.forEach(id => { if (document.getElementById('file-' + id)) document.getElementById('file-' + id).remove(); }); count(); alert(`Deleted: ${r.deleted}. Failed: ${r.failed}.`); }
            catch (e) { alert(e.message || 'Bulk delete failed.'); }
            finally { b.disabled = false; }
        });
        document.getElementById('infoSelected')?.addEventListener('click', async () => {
            const ids = selectedIds(); if (ids.length !== 1) return alert('Select exactly one file to inspect.');
            try { const r = await api('info', {id: ids[0]}); const f = r.file; alert(`${f.original_name}\nPath: ${f.relative_path || '(root)'}\nType: ${f.mime_type}\nSize: ${formatBytes(f.size_bytes)}\nStatus: ${f.status} / ${f.scan_status}\nDownloads: ${f.downloads}\nCreated: ${f.created_at}\nModified: ${f.updated_at}`); }
            catch (e) { alert(e.message || 'File information unavailable.'); }
        });
        document.addEventListener('click', async (e) => {
            const rename = e.target.closest('.rename-file'); if (rename) {
                const id = Number(rename.dataset.id), card = document.getElementById('file-' + id), current = card?.querySelector('.file-main strong')?.textContent || '';
                const name = prompt('New filename:', current); if (!name || name === current) return;
                try { const r = await api('rename', {id, name}); refreshFileCard(id, r.name, r.relative_path); } catch (err) { alert(err.message || 'Rename failed.'); }
            }
            const info = e.target.closest('.info-file'); if (info) {
                try { const r = await api('info', {id: Number(info.dataset.id)}); const f = r.file; alert(`${f.original_name}\nPath: ${f.relative_path || '(root)'}\nType: ${f.mime_type}\nSize: ${formatBytes(f.size_bytes)}\nStatus: ${f.status} / ${f.scan_status}\nDownloads: ${f.downloads}`); } catch (err) { alert(err.message || 'File information unavailable.'); }
            }
        });

        bindFileActions();

        const selected = () => [...document.querySelectorAll('.file-select:checked')].map((x) => Number(x.value));
        document.getElementById('downloadZip')?.addEventListener('click', async () => {
            const ids = selected();
            if (!ids.length) return alert('Select at least one file.');
            const response = await fetch('/api/files.php?action=zip', {method: 'POST', headers: {'Content-Type': 'application/json', 'X-CSRF-Token': csrf}, body: JSON.stringify({ids})});
            if (!response.ok) { const j = await response.json().catch(() => ({})); return alert(j.error || 'ZIP download failed'); }
            const blob = await response.blob(); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'pocketcat-files.zip'; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 1000);
        });

        const modal = document.getElementById('shareModal');
        const openShare = () => { if (!selected().length) return alert('Select at least one file.'); if (modal) modal.hidden = false; };
        document.getElementById('createShare')?.addEventListener('click', openShare);
        document.querySelectorAll('.quick-share').forEach((b) => b.addEventListener('click', () => { document.querySelectorAll('.file-select').forEach((x) => x.checked = Number(x.value) === Number(b.dataset.id)); count(); openShare(); }));
        document.getElementById('closeShare')?.addEventListener('click', () => { if (modal) modal.hidden = true; });
        document.getElementById('saveShare')?.addEventListener('click', async () => {
            const btn = document.getElementById('saveShare'); btn.disabled = true;
            try {
                const j = await api('share_create', {ids: selected(), title: document.getElementById('shareTitle').value, password: document.getElementById('sharePassword').value, expires_at: document.getElementById('shareExpiry').value, max_downloads: Number(document.getElementById('shareMax').value || 0), view_only: document.getElementById('shareViewOnly').checked, theme_accent: document.getElementById('themeAccent').value, theme_background: document.getElementById('themeBackground').value, theme_card: document.getElementById('themeCard').value, og_description: document.getElementById('ogDescription').value, og_image_url: document.getElementById('ogImage').value, os: {iOS: document.getElementById('routeIos').value, Android: document.getElementById('routeAndroid').value, Windows: document.getElementById('routeWindows').value, macOS: document.getElementById('routeMac').value}, country_code: document.getElementById('routeCountry').value, country_url: document.getElementById('routeCountryUrl').value, deep_link_url: document.getElementById('deepLink').value, web_fallback_url: document.getElementById('webFallback').value, utm_source: document.getElementById('utmSource').value, utm_medium: document.getElementById('utmMedium').value, utm_campaign: document.getElementById('utmCampaign').value, utm_term: document.getElementById('utmTerm').value, utm_content: document.getElementById('utmContent').value, meta_pixel: document.getElementById('metaPixel').value, gtm_id: document.getElementById('gtmId').value, tiktok_pixel: document.getElementById('tiktokPixel').value, linkedin_tag: document.getElementById('linkedinTag').value});
                document.getElementById('shareResult').innerHTML = '<strong>Share ready.</strong><br><a target="_blank" href="' + esc(j.short_url) + '">' + esc(j.short_url) + '</a><br><small>Analytics: <a href="/link-analytics/?id=' + j.link_id + '">Open link analytics</a> · <a target="_blank" href="' + esc(j.qr_url) + '">Customize QR</a></small>';
            } catch (e) { alert(e.message); } finally { btn.disabled = false; }
        });

        window.FILE_UPLOAD_FORMAT = {formatBytes, formatSpeed, formatEta};
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, {once: true});
    else init();
}());
