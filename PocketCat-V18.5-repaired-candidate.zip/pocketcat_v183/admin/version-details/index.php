<?php
require __DIR__.'/../version-details.php';
