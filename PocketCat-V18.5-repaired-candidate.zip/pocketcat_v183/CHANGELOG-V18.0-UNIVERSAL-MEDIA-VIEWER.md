# PocketCat V18.0 — Universal Media Viewer Foundation

- Added reusable, mobile-first image/video/audio viewer modal with keyboard dismissal, fullscreen, image zoom/pan/rotate, playback speed, loop, A-B repeat, volume, UI lock, night mode, PiP, lazy HLS.js loading, quality controls, Data Saver, subtitle upload (VTT/SRT), subtitle offset, lazy five-band equalizer and presets.
- Added secure application stream endpoint for existing file tokens, optional public-share authorization, inline disposition, HTTP byte-range responses for local storage, and server-side S3 proxy streaming with Range forwarding.
- Integrated viewer launch controls in File Storage & Sharing, Media Library grid/list cards, and unauthenticated public share pages while keeping public visitors on the same share page.
- Download requests use the application stream endpoint and enforce file/share view-only and download limits server-side.
- Existing upload, file management, Media Library filters and sharing flows were retained.

## Validation
PHP syntax lint and JavaScript syntax checks were run on the changed files. This archive is a source-level implementation against the available V17.9 baseline; live DB/storage integration and browser/device playback still require deployment-environment testing.
