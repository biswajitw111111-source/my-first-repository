# PocketCat V18.1 — Bulk Selection & Streaming Downloads

## Changes

- **File Storage & Sharing** → Existing selection actions were always visible and archive downloads buffered whole files into PHP memory and staged an archive on disk → Added a selection-aware contextual bar and a dedicated streaming endpoint for local storage files.
- **Media Library** → Selection could move/delete/copy URLs but could not use the shared download controls → Integrated the same contextual download controls; canonical PocketCat files and locally stored media uploads can be streamed into archives.
- **Public shared page** → Public visitors had a ZIP-all action but no per-item selection or archive-format choice → Added per-file checkboxes, a contextual bar, selection counter, select/deselect controls and the shared download endpoint. Existing password, expiry, view-only and download-limit checks are applied.
- **Archive processing** → The former ZIP action called `file_get_contents()` for each source file and wrote a temporary ZIP → New endpoint pipes local files through system archive tools and writes the process output directly to the HTTP response in 1 MiB chunks. It does not stage the resulting archive.
- **Security** → Added a 200-item request cap, user/share membership checks, storage-key traversal checks, realpath containment checks, POST+CSRF protection, no-store headers and disabled reverse-proxy buffering.

## Supported behavior and deployment notes

- Streaming archive formats use server-side `tar`, `zip`, `gzip`, `bzip2`, and `xz` commands where installed. `.gz`, `.bz2`, and `.xz` are emitted as compressed TAR streams so multiple selected files remain together. They are not single-file compression of each input.
- `.7z` and `.rar` remain listed in the UI but return a clear HTTP 501/503 error: a verified streaming-to-response mode is not implemented for these formats in this patch. Install and integrate a tested streaming-capable backend before enabling those options in production.
- Archives currently require local storage. S3/cloud-backed selected files return HTTP 501 rather than silently omitting files or buffering them in memory.
- “Separate archives” downloads one selected item per request; the frontend submits one request per item. Browsers may require permission for multiple downloads.
- Folder selection is represented through selected file records and their relative paths; this patch does not add standalone folder rows to the existing File Storage UI.
- `file_zip_downloads` policy continues to govern archive downloads. Direct original-format streaming currently passes through the same policy gate.

## Files changed

- `api/bulk-download.php` (new)
- `assets/css/bulk-selection-v18.css` (new)
- `assets/js/bulk-selection-v18.js` (new)
- `files/index.php`
- `media/index.php`
- `file/share/index.php`

## Verification

PHP syntax checks and JavaScript syntax checks are run as part of packaging. A live integration test still requires the deployed database, configured storage root, server command-line utilities, and authenticated/share sessions.
