<?php
declare(strict_types=1);
require __DIR__.'/../../bootstrap.php';
require_admin();
require __DIR__.'/../../includes/cloud-storage.php';
$provider=trim((string)($_GET['provider']??''));
$allowed=['google_drive','onedrive','dropbox'];
if(!in_array($provider,$allowed,true)){http_response_code(400);exit('Unsupported OAuth provider.');}
$expected=(string)($_SESSION['cloud_oauth_state']??'');
$expectedProvider=(string)($_SESSION['cloud_oauth_provider']??'');
$received=(string)($_GET['state']??'');
// Consume state on every callback attempt to prevent replay.
unset($_SESSION['cloud_oauth_state'],$_SESSION['cloud_oauth_provider']);
if($expected===''||$received===''||!hash_equals($expected,$received)||$expectedProvider!==$provider){http_response_code(400);exit('Cloud authorization failed: invalid or expired state. Please try connecting again.');}
if(isset($_GET['error'])){$_SESSION['flash_error']='Cloud authorization was cancelled or denied by the provider.';redirect('/admin/files/');}
$code=(string)($_GET['code']??'');
if($code===''){http_response_code(400);exit('Cloud authorization failed: authorization code was missing.');}
try{cloud_oauth_callback($provider,$code);$_SESSION['flash_success']=cloud_provider_label($provider).' connected successfully.';redirect('/admin/files/');}
catch(Throwable $e){error_log('[PocketCat cloud OAuth] Provider callback failed for '.$provider.'; details redacted.');$_SESSION['flash_error']='Could not connect '.cloud_provider_label($provider).'. Check provider settings and try again.';redirect('/admin/files/');}
