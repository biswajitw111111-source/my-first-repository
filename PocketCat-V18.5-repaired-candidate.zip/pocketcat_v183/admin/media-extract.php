<?php
declare(strict_types=1);
require __DIR__.'/../bootstrap.php';require_admin();
if($_SERVER['REQUEST_METHOD']!=='POST')redirect('/admin/media/');verify_csrf();
$id=(int)post('id');$s=db()->prepare("SELECT * FROM media_assets WHERE id=? AND kind='archive'");$s->execute([$id]);$m=$s->fetch();
if(!$m||empty($m['storage_path'])){flash('error','Archive not found.');redirect('/admin/media/');}
if(!class_exists('ZipArchive')){flash('error','ZipArchive is not enabled on this hosting.');redirect('/admin/media-archive/?id='.$id);}
try {
 $path=pc_upload_path_from_url((string)$m['storage_path']);if(!is_file($path)||is_link($path))throw new RuntimeException('Archive file is unavailable.');
 $zip=new ZipArchive();if($zip->open($path)!==true)throw new RuntimeException('Could not open archive.');
 if($zip->numFiles>5000)throw new RuntimeException('Archive contains too many entries.');
 $token=bin2hex(random_bytes(12));$dir=pc_path('uploads','media/extracted/'.$token);if(!mkdir($dir,0750,true))throw new RuntimeException('Could not create extraction directory.');
 $seen=[];$expanded=0;
 try {
  for($i=0;$i<$zip->numFiles;$i++){
   $st=$zip->statIndex($i);$name=str_replace('\\','/',(string)($st['name']??''));$isDir=str_ends_with($name,'/');$rel=rtrim($name,'/');
   if($rel===''||str_starts_with($rel,'/')||preg_match('/^[A-Za-z]:/',$rel)||str_contains($rel,"\0"))throw new RuntimeException('Unsafe archive path rejected.');
   foreach(explode('/',$rel) as $seg)if($seg===''||$seg==='.'||$seg==='..')throw new RuntimeException('Archive path traversal rejected.');
   if(isset($seen[$rel]))throw new RuntimeException('Duplicate archive entry rejected.');$seen[$rel]=true;
   $size=(int)($st['size']??0);$expanded+=$size;if($size>0&&$size/max(1,(int)($st['comp_size']??0))>200)throw new RuntimeException('Suspicious compression ratio rejected.');if($expanded>250*1024*1024)throw new RuntimeException('Archive expanded size exceeds 250 MiB.');
   $ops=0;$attr=0;$zip->getExternalAttributesIndex($i,$ops,$attr);if(((($attr>>16)&0170000)===0120000))throw new RuntimeException('Archive symbolic links are not permitted.');
   $dest=$dir.'/'.$rel;PocketCatPaths::assertWithin($dest,$dir);
   if($isDir){if(!is_dir($dest)&&!mkdir($dest,0750,true))throw new RuntimeException('Could not create extracted folder.');continue;}
   $parent=dirname($dest);if(!is_dir($parent)&&!mkdir($parent,0750,true))throw new RuntimeException('Could not create extracted folder.');
   $in=$zip->getStream((string)$st['name']);$out=fopen($dest,'xb');if(!$in||!$out)throw new RuntimeException('Could not write extracted file.');$n=stream_copy_to_stream($in,$out);fclose($in);fclose($out);if($n!==$size)throw new RuntimeException('Extracted file size mismatch.');
  }
 } finally {$zip->close();}
 flash('success','Archive extracted safely into a new isolated media folder.');
} catch(Throwable $e){error_log('[PocketCat media extract] '.$e->getMessage());flash('error','Archive extraction failed safely: '.$e->getMessage());}
redirect('/admin/media/');
