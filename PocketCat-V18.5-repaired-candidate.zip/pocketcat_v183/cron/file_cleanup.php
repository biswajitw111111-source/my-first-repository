<?php
declare(strict_types=1);
require __DIR__.'/../bootstrap.php';
if(PHP_SAPI!=='cli') exit("CLI only\n");
$trashDays=max(1,min(90,(int)policy_global('file_trash_retention_days',30)));
$sql="SELECT id,object_key,storage_driver FROM file_objects WHERE ((status='deleted' AND ((deleted_at IS NOT NULL AND deleted_at < DATE_SUB(NOW(), INTERVAL {$trashDays} DAY)) OR (deleted_at IS NULL AND updated_at < DATE_SUB(NOW(), INTERVAL 7 DAY)))) OR status='expired' OR (expires_at IS NOT NULL AND expires_at<NOW())) LIMIT 200";
$s=db()->query($sql);$n=0;
while($f=$s->fetch()){
    try{
        $q=db()->prepare('SELECT * FROM file_objects WHERE id=?');$q->execute([(int)$f['id']]);$row=$q->fetch();
        if(!$row)continue;
        if(($row['storage_driver']??'')==='local'){
            $path=file_local_path($row);
            if(is_file($path)&&!@unlink($path))throw new RuntimeException('Local object cleanup failed');
        }elseif(($row['storage_driver']??'')==='s3'&&s3_cfg_ok()){
            s3_request('DELETE',(string)$row['object_key']);
        }
        $del=db()->prepare("DELETE FROM file_objects WHERE id=? AND (status='expired' OR (status='deleted' AND ((deleted_at IS NOT NULL AND deleted_at < DATE_SUB(NOW(), INTERVAL {$trashDays} DAY)) OR (deleted_at IS NULL AND updated_at < DATE_SUB(NOW(), INTERVAL 7 DAY)))))");
        $del->execute([(int)$f['id']]);$n++;
    }catch(Throwable $e){error_log('[PocketCat file cleanup] '.$e->getMessage());}
}
try{
    $db=db();$fileDays=max(1,(int)policy_global('file_log_retention_days',90));$linkDays=max(1,(int)policy_global('link_log_retention_days',365));
    $db->exec("DELETE FROM file_events WHERE occurred_at < DATE_SUB(NOW(), INTERVAL {$fileDays} DAY)");
    $db->exec("DELETE FROM link_clicks WHERE clicked_at < DATE_SUB(NOW(), INTERVAL {$linkDays} DAY)");
    $db->exec("DELETE FROM link_rate_limits WHERE window_start < DATE_SUB(NOW(), INTERVAL 1 DAY)");
    $db->exec("DELETE FROM policy_user_overrides WHERE expires_at IS NOT NULL AND expires_at<NOW()");
    $db->exec("DELETE FROM file_operation_keys WHERE created_at < DATE_SUB(NOW(), INTERVAL 7 DAY)");
}catch(Throwable $e){error_log('[PocketCat cleanup retention] '.$e->getMessage());}
echo "cleaned {$n}\n";
