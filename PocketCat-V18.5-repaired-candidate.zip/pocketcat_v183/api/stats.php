<?php
require __DIR__.'/../bootstrap.php';header('Content-Type: application/json; charset=utf-8');json_response(platform_stats());
