# PocketCat V11.2 — Enterprise Hybrid Editor Suite

- Replaced the basic admin page editor with a modular enterprise editor suite.
- Added File/Edit/View/Insert/Format/Table/Tools menu hierarchy.
- Added rich formatting toolbar, semantic blocks, font family/size, alignment, lists and quicktags.
- Added Visual / Code-HTML tabs and source-code modal.
- Added responsive table insertion and table row/column operations.
- Added media upload abstraction through `onMediaUpload(file)`.
- Added draft/autosave separation from published content.
- Added 15-second local draft preservation and server draft storage.
- Added last-10 revision history with rollback.
- Added server-side HTML sanitization.
- Replaced the prior visual customizer runtime with a hybrid in-context editor surface: pencil activation, floating toolbar, viewport collision handling and live style inspector.
- Added frontend publish through the same editor API.
- Kept custom JavaScript disabled by design.
