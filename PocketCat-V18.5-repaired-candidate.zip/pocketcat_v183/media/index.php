<?php
require __DIR__.'/../bootstrap.php';
require_login();
$cu=current_user();
$db=db();
ensure_file_workspace_schema();
$uid=(int)$cu['id'];
$msg='';$msgType='info';

function media_kind(string $mime,string $name):string{
    $m=strtolower($mime);$n=strtolower($name);
    if(str_starts_with($m,'image/'))return'image';
    if(str_starts_with($m,'audio/'))return'audio';
    if(str_starts_with($m,'video/'))return'video';
    if($m==='application/zip'||str_ends_with($n,'.zip'))return'archive';
    return'file';
}
function media_clean_folder(string $v):string{
    $v=trim(str_replace('\\','/',$v));
    $v=preg_replace('/[^A-Za-z0-9._\/-]+/','-',substr($v,0,180));
    $v=trim((string)$v," /.-");
    return $v!==''?$v:'General';
}
function media_clean_name(string $v):string{return trim(mb_substr(basename(str_replace('\\','/',$v)),0,180));}
function media_user_folder_exists(PDO $db,int $uid,string $folder):bool{
    $q=$db->prepare('SELECT 1 FROM media_assets WHERE user_id=? AND folder_name=? LIMIT 1');$q->execute([$uid,$folder]);return(bool)$q->fetchColumn();
}
function media_scope_ids(array $ids):array{return array_values(array_unique(array_filter(array_map('intval',$ids),fn($v)=>$v>0)));}

if($_SERVER['REQUEST_METHOD']==='POST'){
    verify_csrf();
    $a=(string)post('action');
    try{
        if($a==='create_folder'){
            $folder=media_clean_folder((string)post('folder'));
            if(media_user_folder_exists($db,$uid,$folder)){$msg='That folder already exists.';$msgType='error';}
            else{
                $db->prepare('INSERT INTO media_assets(user_id,name,folder_name,source_type,source_url,mime_type,size_bytes,kind,auto_fit,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,1,NOW(),NOW())')
                   ->execute([$uid,'.folder-marker',$folder,'url','about:blank','application/x-folder-marker',0,'file']);
                $msg='Folder created: '.$folder;
            }
        } elseif($a==='rename_folder'){
            $old=media_clean_folder((string)post('old_folder'));$new=media_clean_folder((string)post('new_folder'));
            if($old===$new){$msg='No folder name change was made.';}
            elseif(!media_user_folder_exists($db,$uid,$old)){$msg='Folder not found.';$msgType='error';}
            elseif(media_user_folder_exists($db,$uid,$new)){$msg='A folder with that name already exists.';$msgType='error';}
            else{
                $q=$db->prepare('UPDATE media_assets SET folder_name=?,updated_at=NOW() WHERE user_id=? AND folder_name=?');$q->execute([$new,$uid,$old]);
                $msg='Folder renamed. '.$q->rowCount().' asset(s) updated.';
            }
        } elseif($a==='delete_folder'){
            $folder=media_clean_folder((string)post('folder'));
            $q=$db->prepare('SELECT COUNT(*) FROM media_assets WHERE user_id=? AND folder_name=? AND name<>?');$q->execute([$uid,$folder,'.folder-marker']);
            if((int)$q->fetchColumn()>0){$msg='Folder is not empty. Move or delete its assets first.';$msgType='error';}
            else{$db->prepare('DELETE FROM media_assets WHERE user_id=? AND folder_name=? AND name=?')->execute([$uid,$folder,'.folder-marker']);$msg='Folder deleted: '.$folder;}
        } elseif($a==='upload' && !empty($_FILES['media']['tmp_name'])){
            $fs=$_FILES['media'];
            $tmp=is_array($fs['tmp_name'])?$fs['tmp_name']:[$fs['tmp_name']];
            $names=is_array($fs['name'])?$fs['name']:[$fs['name']];
            $sizes=is_array($fs['size'])?$fs['size']:[$fs['size']];
            $errors=is_array($fs['error'])?$fs['error']:[$fs['error']];
            $paths=is_array($fs['full_path']??null)?$fs['full_path']:[];
            $folder=media_clean_folder((string)post('folder','General'));
            if(!media_user_folder_exists($db,$uid,$folder)){
                $db->prepare('INSERT INTO media_assets(user_id,name,folder_name,source_type,source_url,mime_type,size_bytes,kind,auto_fit,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,1,NOW(),NOW())')->execute([$uid,'.folder-marker',$folder,'url','about:blank','application/x-folder-marker',0,'file']);
            }
            $dir=pc_path('media',(string)$uid);
            if(!is_dir($dir) && !@mkdir($dir,0750,true) && !is_dir($dir))throw new RuntimeException('Media upload directory could not be created. Check server write permissions.');
            $ok=0;$skipped=0;$skipReasons=[];
            foreach($tmp as $i=>$tp){
                $err=(int)($errors[$i]??UPLOAD_ERR_NO_FILE);
                if($err!==UPLOAD_ERR_OK || !is_uploaded_file($tp)){$skipped++;$skipReasons[]='invalid upload';continue;}
                $size=(int)($sizes[$i]??0);
                if($size<=0){$skipped++;$skipReasons[]='empty file';continue;}
                if($size>file_local_max_bytes()){$skipped++;$skipReasons[]='over the current PHP upload limit';continue;}
                $name=media_clean_name((string)($names[$i]??''));if($name===''){$skipped++;$skipReasons[]='invalid filename';continue;}
                $relative=trim((string)($paths[$i]??''));
                if($relative!==''){
                    $relative=str_replace('\\','/',$relative);
                    $segments=array_values(array_filter(explode('/',$relative),fn($x)=>$x!==''&&$x!=='.'&&$x!=='..'));
                    if(count($segments)>1){$dirName=media_clean_folder(implode('/',array_slice($segments,0,-1)));if($dirName!=='General')$folderForFile=$folder.'/'.$dirName;else $folderForFile=$folder;}else{$folderForFile=$folder;}
                }else{$folderForFile=$folder;}
                if(!media_user_folder_exists($db,$uid,$folderForFile)){
                    $db->prepare('INSERT INTO media_assets(user_id,name,folder_name,source_type,source_url,mime_type,size_bytes,kind,auto_fit,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,1,NOW(),NOW())')->execute([$uid,'.folder-marker',$folderForFile,'url','about:blank','application/x-folder-marker',0,'file']);
                }
                $mime=function_exists('mime_content_type')?(mime_content_type($tp)?:'application/octet-stream'):(string)($fs['type'][$i]??'application/octet-stream');if(function_exists('file_blacklisted')&&file_blacklisted($name,$mime)){$skipped++;$skipReasons[]='blocked file type';continue;}
                $kind=media_kind($mime,$name);$ext=pathinfo($name,PATHINFO_EXTENSION);$safeExt=$ext?'.'.preg_replace('/[^a-zA-Z0-9]+/','',$ext):'';
                $file=bin2hex(random_bytes(16)).$safeExt;$path=$dir.'/'.$file;
                if(!@move_uploaded_file($tp,$path) && !@copy($tp,$path)){$skipped++;$skipReasons[]='server could not write file';continue;}
                $url='/uploads/media/'.$uid.'/'.$file;$w=null;$h=null;
                if($kind==='image'){$info=@getimagesize($path);$w=$info[0]??null;$h=$info[1]??null;}
                file_create_from_media_upload(['path'=>$path,'url'=>$url,'name'=>$name,'mime'=>$mime,'size'=>$size,'relative_path'=>$relative],$uid,$folderForFile);$ok++;
            }
            $msg=$ok?'Uploaded '.$ok.' asset(s).':'No files were uploaded.';
            if($skipped){$msg.=' '.$skipped.' file(s) were skipped.';if($skipReasons)$msg.=' '.implode(', ',array_slice(array_unique($skipReasons),0,3)).'.';}
        } elseif($a==='url'){
            $url=trim((string)post('source_url'));$name=media_clean_name((string)post('name','Remote media'));$folder=media_clean_folder((string)post('folder','General'));$mime=trim((string)post('mime_type','application/octet-stream'));
            if(!filter_var($url,FILTER_VALIDATE_URL)||!preg_match('~^https?://~i',$url)){$msg='Only valid HTTP/HTTPS public URLs are allowed.';$msgType='error';}
            elseif($name===''){$msg='A media name is required.';$msgType='error';}
            else{
                if(!media_user_folder_exists($db,$uid,$folder))$db->prepare('INSERT INTO media_assets(user_id,name,folder_name,source_type,source_url,mime_type,size_bytes,kind,auto_fit,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,1,NOW(),NOW())')->execute([$uid,'.folder-marker',$folder,'url','about:blank','application/x-folder-marker',0,'file']);
                $db->prepare('INSERT INTO media_assets(user_id,name,folder_name,source_type,source_category,source_ref_id,source_url,mime_type,size_bytes,kind,auto_fit,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,1,NOW(),NOW())')->execute([$uid,$name,$folder,'url','Media Assets',0,$url,$mime,0,media_kind($mime,$name)]);$mediaId=(int)$db->lastInsertId();$db->prepare('UPDATE media_assets SET source_ref_id=? WHERE id=? AND user_id=?')->execute([$mediaId,$mediaId,$uid]);
                $msg='Public media URL saved.';
            }
        } elseif($a==='edit'){
            $id=(int)post('id');$name=media_clean_name((string)post('name'));$folder=media_clean_folder((string)post('folder'));$alt=trim((string)post('alt_text'));$desc=trim((string)post('description'));$fav=!empty($_POST['is_favorite'])?1:0;
            if($id>0&&$name!==''){
                if(!media_user_folder_exists($db,$uid,$folder))$db->prepare('INSERT INTO media_assets(user_id,name,folder_name,source_type,source_url,mime_type,size_bytes,kind,auto_fit,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,1,NOW(),NOW())')->execute([$uid,'.folder-marker',$folder,'url','about:blank','application/x-folder-marker',0,'file']);
                $q=$db->prepare('UPDATE media_assets SET name=?,folder_name=?,alt_text=?,description=?,is_favorite=?,updated_at=NOW() WHERE id=? AND user_id=? AND name<>?');$q->execute([$name,$folder,mb_substr($alt,0,500),mb_substr($desc,0,2000),$fav,$id,$uid,'.folder-marker']);$msg=$q->rowCount()?'Media details saved.':'Media item not found.';$msgType=$q->rowCount()?'info':'error';
            }else{$msg='Could not save media details.';$msgType='error';}
        } elseif($a==='favorite'){
            $id=(int)post('id');$q=$db->prepare('UPDATE media_assets SET is_favorite=1-is_favorite,updated_at=NOW() WHERE id=? AND user_id=? AND name<>?');$q->execute([$id,$uid,'.folder-marker']);$msg=$q->rowCount()?'Favorite status updated.':'Media item not found.';$msgType=$q->rowCount()?'info':'error';
        } elseif($a==='bulk_move'){
            $ids=media_scope_ids((array)post('ids',[]));$folder=media_clean_folder((string)post('target_folder','General'));
            if(!$ids){$msg='Select at least one media item.';$msgType='error';}
            elseif($folder!=='General'&&!media_user_folder_exists($db,$uid,$folder)){$msg='Target folder does not exist.';$msgType='error';}
            else{$ph=implode(',',array_fill(0,count($ids),'?'));$q=$db->prepare("UPDATE media_assets SET folder_name=?,updated_at=NOW() WHERE user_id=? AND name<>'.folder-marker' AND id IN ($ph)");$q->execute(array_merge([$folder,$uid],$ids));$msg='Moved '.$q->rowCount().' asset(s) to '.$folder.'.';}
        } elseif($a==='bulk_delete'){
            $ids=media_scope_ids((array)post('ids',[]));
            if(!$ids){$msg='Select at least one media item.';$msgType='error';}
            else{
                $ph=implode(',',array_fill(0,count($ids),'?'));$q=$db->prepare("SELECT id,canonical_file_id,storage_path FROM media_assets WHERE user_id=? AND name<>'.folder-marker' AND id IN ($ph)");$q->execute(array_merge([$uid],$ids));$rowsToDelete=$q->fetchAll();
                foreach($rowsToDelete as $m){if(!empty($m['canonical_file_id'])){ $fq=$db->prepare('SELECT * FROM file_objects WHERE id=? AND user_id=?');$fq->execute([(int)$m['canonical_file_id'],$uid]);$f=$fq->fetch();if($f){if(($f['storage_driver']??'')==='local'){ $fp=file_local_path($f);if(is_file($fp))@unlink($fp); }$db->prepare("UPDATE file_objects SET status='deleted',updated_at=NOW() WHERE id=? AND user_id=?")->execute([(int)$f['id'],$uid]);} } elseif(!empty($m['storage_path'])&&str_starts_with((string)$m['storage_path'],'/uploads/media/'))@unlink(pc_upload_path_from_url((string)parse_url((string)$m['storage_path'],PHP_URL_PATH)));}
                $q=$db->prepare("DELETE FROM media_assets WHERE user_id=? AND name<>'.folder-marker' AND id IN ($ph)");$q->execute(array_merge([$uid],$ids));$msg='Deleted '.$q->rowCount().' asset(s).';
            }
        } elseif($a==='delete'){
            $id=(int)post('id');$q=$db->prepare('SELECT * FROM media_assets WHERE id=? AND user_id=? AND name<>?');$q->execute([$id,$uid,'.folder-marker']);$m=$q->fetch();
            if(!$m){$msg='Media item not found.';$msgType='error';}
            else{if(!empty($m['canonical_file_id'])){ $fq=$db->prepare('SELECT * FROM file_objects WHERE id=? AND user_id=?');$fq->execute([(int)$m['canonical_file_id'],$uid]);$f=$fq->fetch();if($f){if(($f['storage_driver']??'')==='local'){ $fp=file_local_path($f);if(is_file($fp))@unlink($fp); }$db->prepare("UPDATE file_objects SET status='deleted',updated_at=NOW() WHERE id=? AND user_id=?")->execute([(int)$f['id'],$uid]);}} elseif(!empty($m['storage_path'])&&str_starts_with((string)$m['storage_path'],'/uploads/media/'))@unlink(pc_upload_path_from_url((string)parse_url((string)$m['storage_path'],PHP_URL_PATH)));$db->prepare('DELETE FROM media_assets WHERE id=? AND user_id=?')->execute([$id,$uid]);$msg='Media deleted.';}
        }
    }catch(Throwable $e){$msg='Media operation failed safely: '.($e->getMessage()?:'unknown server error').'.';$msgType='error';}
}

$folder=(string)getv('folder','');$q=trim((string)getv('q',''));$kind=(string)getv('kind','');$category=(string)getv('category','');$date=(string)getv('date','');$sort=(string)getv('sort','newest');$view=(string)getv('view','grid');
$allowedCategories=[''=>'All sources','Media Assets'=>'Media Assets','Shared Files'=>'Shared Files','Support Attachments'=>'Support Attachments','AI Workspace'=>'AI Workspace'];if(!array_key_exists($category,$allowedCategories))$category='';
$allowedKinds=['image','video','audio','archive','file'];if(!in_array($kind,$allowedKinds,true))$kind='';
$allowedDates=['','today','7d','30d','90d','year'];if(!in_array($date,$allowedDates,true))$date='';
$sortSql=['newest'=>'created_at DESC','oldest'=>'created_at ASC','name'=>'name ASC','largest'=>'size_bytes DESC','favorites'=>'is_favorite DESC, created_at DESC'][$sort]??'created_at DESC';
$sql='SELECT m.*,f.id AS canonical_file_id,f.public_token AS file_public_token,f.object_key AS file_object_key,f.storage_driver AS file_storage_driver,f.provider_url AS file_provider_url,f.status AS file_status,f.scan_status AS file_scan_status FROM media_assets m LEFT JOIN file_objects f ON f.id=m.canonical_file_id AND f.user_id=m.user_id WHERE m.user_id=? AND m.name<>?';$params=[$uid,'.folder-marker'];
if($folder!==''){$sql.=' AND m.folder_name=?';$params[]=$folder;}
if($kind!==''){$sql.=' AND m.kind=?';$params[]=$kind;}if($category!==''){$sql.=' AND m.source_category=?';$params[]=$category;}
if($q!==''){$sql.=' AND (m.name LIKE ? OR m.alt_text LIKE ? OR m.description LIKE ?)';$like='%'.$q.'%';array_push($params,$like,$like,$like);}
if($date!==''){$days=['today'=>0,'7d'=>7,'30d'=>30,'90d'=>90,'year'=>365][$date];$sql.=$days===0?' AND m.created_at>=CURDATE()':' AND m.created_at>=DATE_SUB(NOW(),INTERVAL '.$days.' DAY)';}
$sortSql=str_replace(['created_at','name','size_bytes','is_favorite'],['m.created_at','m.name','m.size_bytes','m.is_favorite'],$sortSql);$sql.=' ORDER BY '.$sortSql.' LIMIT 500';$st=$db->prepare($sql);$st->execute($params);$rows=$st->fetchAll();
$st=$db->prepare("SELECT folder_name,SUM(name<>'.folder-marker') n,MAX(name='.folder-marker') has_marker FROM media_assets WHERE user_id=? GROUP BY folder_name ORDER BY folder_name");$st->execute([$uid]);$folders=$st->fetchAll();$categoryCounts=array_fill_keys(array_keys($allowedCategories),0);$st=$db->prepare("SELECT source_category,COUNT(*) n FROM media_assets WHERE user_id=? AND name<>'.folder-marker' GROUP BY source_category");$st->execute([$uid]);foreach($st->fetchAll() as $cr){$key=(string)$cr['source_category'];if(isset($categoryCounts[$key]))$categoryCounts[$key]=(int)$cr['n'];}
$stats=['total'=>0,'image'=>0,'video'=>0,'audio'=>0,'file'=>0,'archive'=>0,'favorite'=>0];$sq=$db->prepare("SELECT kind,COUNT(*) n,SUM(is_favorite) fav FROM media_assets WHERE user_id=? AND name<>'.folder-marker' GROUP BY kind");$sq->execute([$uid]);foreach($sq as $r){$stats['total']+=(int)$r['n'];$k2=$r['kind'];if(isset($stats[$k2]))$stats[$k2]+=(int)$r['n'];$stats['favorite']+=(int)$r['fav'];}
$title='Media Library';require __DIR__.'/../includes/header.php';
?>
<link rel="stylesheet" href="/assets/css/universal-media-viewer.css?v=18.0"><link rel="stylesheet" href="/assets/css/bulk-selection-v18.css?v=18.1"><link rel="stylesheet" href="/assets/css/file-organization-v18.2.css?v=18.3"><script>window.POCKETCAT_ORG_USER=<?=json_encode((string)$uid)?>;</script><div class="page-head media-library-head"><div><span class="eyebrow">MEDIA PLATFORM</span><h1>Media Library</h1><p>Organize, preview, search and reuse your media from one responsive workspace.</p></div><a class="btn" href="#media-upload">Add media</a></div>
<?php if($msg):?><div class="flash <?=e($msgType)?>"><?=e($msg)?></div><?php endif;?>
<section class="media-stats"><div class="card"><b><?=number_format($stats['total'])?></b><span>Total assets</span></div><div class="card"><b><?=number_format($stats['image'])?></b><span>Images</span></div><div class="card"><b><?=number_format($stats['video']+$stats['audio'])?></b><span>Audio + video</span></div><div class="card"><b><?=number_format($stats['favorite'])?></b><span>Favorites</span></div></section>
<section class="card media-toolbar"><form method="get" class="media-filter-form"><label>Search<input name="q" value="<?=e($q)?>" placeholder="Filename, alt text, description"></label><label>Type<select name="kind"><option value="">All types</option><?php foreach($allowedKinds as $k):?><option value="<?=$k?>" <?=$kind===$k?'selected':''?>><?=e(ucfirst($k))?></option><?php endforeach;?></select></label><label>Folder<select name="folder"><option value="">All folders</option><?php foreach($folders as $f):?><option value="<?=e($f['folder_name'])?>" <?=$folder===$f['folder_name']?'selected':''?>><?=e($f['folder_name'])?> (<?=number_format((int)$f['n'])?>)</option><?php endforeach;?></select></label><label>Date<select name="date"><option value="">Any date</option><option value="today" <?=$date==='today'?'selected':''?>>Today</option><option value="7d" <?=$date==='7d'?'selected':''?>>Last 7 days</option><option value="30d" <?=$date==='30d'?'selected':''?>>Last 30 days</option><option value="90d" <?=$date==='90d'?'selected':''?>>Last 90 days</option><option value="year" <?=$date==='year'?'selected':''?>>Last year</option></select></label><label>Sort<select name="sort"><option value="newest" <?=$sort==='newest'?'selected':''?>>Newest</option><option value="oldest" <?=$sort==='oldest'?'selected':''?>>Oldest</option><option value="name" <?=$sort==='name'?'selected':''?>>Name</option><option value="largest" <?=$sort==='largest'?'selected':''?>>Largest</option><option value="favorites" <?=$sort==='favorites'?'selected':''?>>Favorites</option></select></label><input type="hidden" name="view" value="<?=e($view)?>"><button class="btn">Filter</button><a class="btn secondary" href="/media/">Reset</a></form>
<div class="media-category-tabs" role="tablist"><?php foreach($allowedCategories as $cat=>$label):?><a class="btn small <?=($category===$cat)?'':'secondary'?>" href="<?=e('?'.http_build_query(array_merge($_GET,['category'=>$cat])))?>"><?=e($label)?> <span class="muted">(<?=number_format((int)($categoryCounts[$cat]??0))?>)</span></a><?php endforeach;?></div><div class="media-folder-bar"><a class="btn small <?=$folder===''?'':'secondary'?>" href="/media/">All</a><?php foreach($folders as $f):?><a class="btn small <?=$folder===$f['folder_name']?'':'secondary'?>" href="/media/?folder=<?=rawurlencode($f['folder_name'])?>"><?=e($f['folder_name'])?> <span class="muted">(<?=number_format((int)$f['n'])?>)</span></a><?php endforeach;?></div>
<div class="media-view-toggle"><span class="muted"><?=count($rows)?> shown</span><a class="btn small <?=$view==='grid'?'':'secondary'?>" href="<?=e('?'.http_build_query(array_merge($_GET,['view'=>'grid'])))?>">Grid</a><a class="btn small <?=$view==='list'?'':'secondary'?>" href="<?=e('?'.http_build_query(array_merge($_GET,['view'=>'list'])))?>">List</a></div></section>
<section class="grid2" id="media-upload"><form class="card form-card" method="post" enctype="multipart/form-data"><?=csrf_field()?><input type="hidden" name="action" value="upload"><h2>Upload media</h2><label>Folder<select name="folder"><?php $hasGeneral=false;foreach($folders as $f):$hasGeneral=$hasGeneral||$f['folder_name']==='General';?><option value="<?=e($f['folder_name'])?>" <?=$folder===$f['folder_name']?'selected':''?>><?=e($f['folder_name'])?></option><?php endforeach;if(!$hasGeneral):?><option value="General" <?=!$folder?'selected':''?>>General</option><?php endif;?></select></label><label>Files<input id="mediaFilesPicker" type="file" name="media[]" multiple accept="image/*,audio/*,video/*,.zip,.pdf,.txt,.csv,.json,.doc,.docx,.xls,.xlsx,.ppt,.pptx"></label><div class="upload-picker-actions"><button class="btn small secondary" type="button" id="chooseMediaFolder">Choose folder</button><input id="mediaFolderPicker" type="file" multiple webkitdirectory directory accept="image/*,audio/*,video/*,.zip,.pdf,.txt,.csv,.json,.doc,.docx,.xls,.xlsx,.ppt,.pptx" hidden><span class="muted small-text">Select files, a whole folder, or drag a folder here.</span></div><div id="mediaDrop" class="media-drop">Drop files or a folder here. Large files are uploaded in small resumable chunks to stay within shared-hosting request limits.</div>
<div id="mediaUploadMetrics" class="media-upload-metrics" hidden aria-live="polite">
  <div><span>Upload progress</span><strong data-media-metric="progress">0%</strong></div>
  <div><span>Upload size</span><strong data-media-metric="size">0 B / 0 B</strong></div>
  <div><span>Network speed</span><strong data-media-metric="speed">—</strong></div>
  <div><span>Files</span><strong data-media-metric="files">0 / 0</strong></div>
</div>
<div id="mediaQueue" class="upload-list"></div><button class="btn">Upload selected</button></form><form class="card form-card" method="post"><?=csrf_field()?><input type="hidden" name="action" value="url"><h2>Add public URL</h2><label>Name<input name="name" required placeholder="Logo or banner"></label><label>Folder<input name="folder" value="<?=e($folder?:'General')?>"></label><label>Public URL<input name="source_url" type="url" placeholder="https://example.com/image.jpg" required></label><label>MIME type<input name="mime_type" value="image/jpeg"></label><button class="btn">Save URL</button></form></section>
<details class="card media-folder-manager"><summary><b>Folder management</b><span class="muted">Create, rename or remove empty folders</span></summary><div class="grid3"><form method="post"><?=csrf_field()?><input type="hidden" name="action" value="create_folder"><label>New folder<input name="folder" required placeholder="Campaigns"></label><button class="btn small">Create</button></form><form method="post"><?=csrf_field()?><input type="hidden" name="action" value="rename_folder"><label>Rename<select name="old_folder"><?php foreach($folders as $f):?><option value="<?=e($f['folder_name'])?>"><?=e($f['folder_name'])?></option><?php endforeach;?></select></label><label>New name<input name="new_folder" required></label><button class="btn small">Rename</button></form><form method="post" onsubmit="return confirm('Delete this folder? Only empty folders can be removed.')"><?=csrf_field()?><input type="hidden" name="action" value="delete_folder"><label>Remove empty folder<select name="folder"><?php foreach($folders as $f):?><option value="<?=e($f['folder_name'])?>"><?=e($f['folder_name'])?> (<?=number_format((int)$f['n'])?>)</option><?php endforeach;?></select></label><button class="btn small danger">Delete folder</button></form></div></details>
<form method="post" id="bulkMediaForm"><?=csrf_field()?><input type="hidden" name="action" id="bulkAction" value="bulk_move"><div class="media-bulkbar card"><label class="select-all"><input type="checkbox" id="selectAll"> Select all shown</label><select name="target_folder" id="bulkFolder"><option value="">Move to folder…</option><?php foreach($folders as $f):?><option value="<?=e($f['folder_name'])?>"><?=e($f['folder_name'])?></option><?php endforeach;?></select><button class="btn small" type="submit" onclick="document.getElementById('bulkAction').value='bulk_move'">Move selected</button><button class="btn small danger" type="submit" onclick="if(!confirm('Delete selected media permanently?'))return false;document.getElementById('bulkAction').value='bulk_delete'">Delete selected</button><button class="btn small secondary" type="button" id="copySelected">Copy selected URLs</button></div>
<div class="media-grid <?=$view==='list'?'media-list-view':''?>" id="media-grid">
<?php foreach($rows as $m):$url=!empty($m['canonical_file_id'])?('/file/stream/?token='.rawurlencode((string)$m['file_public_token'])):(string)$m['source_url'];$fav=(int)($m['is_favorite']??0);?><article class="media-card" id="media-<?=e((string)$m['id'])?>" data-kind="<?=e($m['kind']??'file')?>" data-created="<?=e((string)($m['created_at']??''))?>" data-file-id="<?=e((string)($m['canonical_file_id']??''))?>"><div class="media-select"><input class="media-check" type="checkbox" name="ids[]" value="<?=$m['id']?>" data-url="<?=e($url)?>" aria-label="Select <?=e($m['name'])?>"></div><div class="media-preview" data-preview-kind="<?=e($m['kind']??'file')?>"><?php if(($m['kind']??'')==='image'):?><img src="<?=e($url)?>" alt="<?=e($m['alt_text']??$m['name'])?>" loading="lazy" data-preview-url="<?=e($url)?>"><?php elseif(($m['kind']??'')==='audio'):?><audio controls preload="metadata" src="<?=e($url)?>"></audio><?php elseif(($m['kind']??'')==='video'):?><video controls preload="metadata" src="<?=e($url)?>"></video><?php else:?><div class="file-icon"><?=($m['kind']??'')==='archive'?'🗜️':'📄'?></div><?php endif;?></div><div class="media-card-body"><div class="media-title-row"><strong title="<?=e($m['name'])?>"><?=e($m['name'])?></strong><details class="asset-menu"><summary aria-label="Asset actions">⋮</summary><div class="asset-menu-pop"><?php if(!empty($m['canonical_file_id'])):?><a href="/files/?highlight=<?=e((string)$m['canonical_file_id'])?>">Open in Files</a><?php endif;?><button type="button" data-copy-url="<?=e($url)?>">Share / Copy URL</button><a href="<?=e($url)?>" target="_blank" rel="noopener" download>Direct download</a><button type="button" data-open-edit>Rename / Edit</button><button type="button" data-delete-media="<?=$m['id']?>">Delete</button></div></details><form method="post"><?=csrf_field()?><input type="hidden" name="action" value="favorite"><input type="hidden" name="id" value="<?=$m['id']?>"><button class="media-fav <?=$fav?'active':''?>" title="<?=$fav?'Remove favorite':'Add favorite'?>" aria-label="Favorite">★</button></form></div><small><?=e($m['source_category']??'Media Assets')?> · <?=e($m['folder_name']??'General')?> · <?=e(strtoupper($m['kind']??'file'))?> · <?=e($m['size_bytes']?storage_human((int)$m['size_bytes']):'Remote')?></small><?php if(!empty($m['width'])&&$m['height']):?><small><?=e($m['width'])?> × <?=e($m['height'])?> px</small><?php endif;?><div class="media-actions"><?php if(!empty($m['canonical_file_id'])):?><a class="edit-btn primary" href="/files/?highlight=<?=e((string)$m['canonical_file_id'])?>">Open in Files</a><?php endif;?><button class="edit-btn" type="button" data-copy-url="<?=e($url)?>">Copy URL</button><a class="edit-btn" href="<?=e(!empty($m['canonical_file_id'])?'/file/stream/?token='.rawurlencode((string)$m['file_public_token']).'&download=1':$url)?>" target="_blank" rel="noopener" <?=(!empty($m['canonical_file_id'])||str_starts_with($m['source_url'],'/uploads/'))?'download':''?>>Download</a><?php if(in_array($m['kind'],['image','video','audio'],true)):?><button class="edit-btn" type="button" data-open-preview data-url="<?=e(!empty($m['canonical_file_id'])?'/file/stream/?token='.rawurlencode((string)$m['file_public_token']):$url)?>" data-name="<?=e($m['name'])?>" data-mime="<?=e($m['mime_type']??'')?>">Preview</button><?php endif;?><a class="edit-btn" href="<?=e(!empty($m['canonical_file_id'])?'/file/stream/?token='.rawurlencode((string)$m['file_public_token']).'&download=1':$url)?>" target="_blank" rel="noopener" <?=(!empty($m['canonical_file_id'])||str_starts_with($m['source_url'],'/uploads/'))?'download':''?>>Open</a><form method="post" onsubmit="return confirm('Delete this media item?')"><?=csrf_field()?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=$m['id']?>"><button class="edit-btn danger" type="submit">Delete</button></form></div><details class="media-edit"><summary>Edit details</summary><form method="post"><?=csrf_field()?><input type="hidden" name="action" value="edit"><input type="hidden" name="id" value="<?=$m['id']?>"><label>Name<input name="name" value="<?=e($m['name'])?>" required></label><label>Folder<select name="folder"><?php foreach($folders as $f):?><option value="<?=e($f['folder_name'])?>" <?=$m['folder_name']===$f['folder_name']?'selected':''?>><?=e($f['folder_name'])?></option><?php endforeach;?></select></label><label>Alt text<input name="alt_text" value="<?=e($m['alt_text']??'')?>" placeholder="Useful description for images"></label><label>Description<textarea name="description" rows="3"><?=e($m['description']??'')?></textarea></label><label class="check"><input type="checkbox" name="is_favorite" value="1" <?=$fav?'checked':''?>> Favorite</label><button class="btn small">Save details</button></form></details></div></article><?php endforeach;if(!$rows):?><div class="card"><p class="muted">No media matched these filters.</p></div><?php endif;?></div></form>
<div class="media-modal" id="mediaModal" hidden><div class="media-modal-backdrop" data-close-media></div><div class="media-modal-dialog"><button class="modal-close" type="button" data-close-media>×</button><div id="mediaModalBody"></div></div></div>
<script>
(function(){
 'use strict';
 const form=document.querySelector('#media-upload form.form-card'),
       p=document.getElementById('mediaFilesPicker'),
       folderPicker=document.getElementById('mediaFolderPicker'),
       chooseFolder=document.getElementById('chooseMediaFolder'),
       q=document.getElementById('mediaQueue'),
       drop=document.getElementById('mediaDrop'),
       metrics=document.getElementById('mediaUploadMetrics'),
       submit=form?.querySelector('button[type="submit"]');
 if(!form||!p||!q)return;
 const csrf=form.querySelector('input[name="_csrf"]')?.value||window.POCKETCAT_CSRF||'';
 const retryDelays=[2000,5000,10000,20000,30000];
 function toast(message){let n=document.getElementById('pcUploadToast');if(!n){n=document.createElement('div');n.id='pcUploadToast';n.className='pc-upload-toast';n.setAttribute('role','status');n.setAttribute('aria-live','polite');document.body.appendChild(n)}n.textContent=message;n.hidden=false;clearTimeout(n._timer);n._timer=setTimeout(()=>n.hidden=true,3500)}
 const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
 const bytes=n=>{
   n=Math.max(0,Number(n)||0);
   if(n<1024)return n.toFixed(0)+' B';
   const u=['KB','MB','GB','TB']; let v=n/1024,i=0;
   while(v>=1024&&i<u.length-1){v/=1024;i++}
   return v.toFixed(v>=100?0:v>=10?1:2)+' '+u[i];
 };
 const speedText=n=>(Number(n)>0?bytes(n)+'/s':'—');
 const etaText=(sec)=>{
   if(!Number.isFinite(sec)||sec<0)return 'Calculating…';
   const s=Math.ceil(sec); if(s<60)return s+'s';
   const m=Math.floor(s/60),r=s%60; if(m<60)return m+'m '+r+'s';
   return Math.floor(m/60)+'h '+(m%60)+'m';
 };
 let fs=[], states=new Map(), renderTimer=0, active=0, queueCursor=0;
 const MAX_CONCURRENT=3;

 function sync(){
   try{const dt=new DataTransfer();fs.forEach(f=>dt.items.add(f));p.files=dt.files}catch(e){}
   q.innerHTML='';
   fs.forEach((f,i)=>{
     const d=document.createElement('div');d.className='upload-chip';
     d.innerHTML='<span>'+esc(f.webkitRelativePath||f.name)+' · '+bytes(f.size)+'</span>';
     const x=document.createElement('button');x.type='button';x.textContent='×';x.setAttribute('aria-label','Remove '+f.name);
     x.disabled=[...states.values()].some(s=>s.file===f&&s.running);
     x.onclick=()=>{const st=[...states.values()].find(st=>st.file===f&&!st.running);if(st)removeUpload(st);else if(![...states.values()].some(st=>st.file===f&&st.running)){fs.splice(i,1);sync();updateMetrics()}};d.appendChild(x);q.appendChild(d);
   });
 }
 function updateMetrics(){
   const list=[...states.values()];
   const live=list.filter(s=>['uploading','retrying','preparing'].includes(s.phase));
   const total=list.reduce((n,s)=>n+s.total,0), uploaded=list.reduce((n,s)=>n+Math.min(s.total,s.uploaded),0);
   const now=performance.now();
   const net=live.reduce((n,s)=>n+(now-(s.lastProgressAt||now)<=2000?(s.lastSpeed||s.speed||0):0),0);
   const pct=total?Math.min(100,uploaded/total*100):0;
   if(metrics){
     metrics.hidden=!list.length;
     metrics.querySelector('[data-media-metric="progress"]').textContent=pct.toFixed(pct<10?1:0)+'% / 100%';
     metrics.querySelector('[data-media-metric="size"]').textContent=bytes(uploaded)+' / '+bytes(total);
     metrics.querySelector('[data-media-metric="speed"]').textContent=speedText(net);
     metrics.querySelector('[data-media-metric="files"]').textContent=list.filter(s=>s.phase==='done').length+' / '+list.length;
   }
   let actions=document.getElementById('mediaUploadBatchActions');
   if(!actions&&metrics){
     actions=document.createElement('div');actions.id='mediaUploadBatchActions';actions.className='upload-batch-actions';
     actions.innerHTML='<label><input type="checkbox" id="mediaUploadSelectAll"> Select all</label><button type="button" class="btn small media-pause-selected">Pause selected</button><button type="button" class="btn small secondary media-resume-selected">Resume selected</button><button type="button" class="btn small media-retry-all">Retry failed</button><button type="button" class="btn small secondary media-cancel-all">Cancel active uploads</button><button type="button" class="btn small secondary media-remove-selected">Remove selected</button>';
     metrics.after(actions);
     actions.querySelector('#mediaUploadSelectAll').onchange=e=>list.forEach(s=>{const c=s.card.querySelector('.media-upload-check');if(c)c.checked=e.target.checked});
     actions.querySelector('.media-pause-selected').onclick=()=>[...states.values()].filter(s=>s.card.querySelector('.media-upload-check')?.checked).forEach(pause);
     actions.querySelector('.media-resume-selected').onclick=()=>[...states.values()].filter(s=>s.card.querySelector('.media-upload-check')?.checked).forEach(resume);
     actions.querySelector('.media-remove-selected').onclick=()=>[...states.values()].filter(s=>s.card.querySelector('.media-upload-check')?.checked).forEach(removeUpload);
     actions.querySelector('.media-retry-all').onclick=()=>list.filter(s=>s.phase==='error'||s.phase==='cancelled').forEach(s=>enqueue(s,true));
     actions.querySelector('.media-cancel-all').onclick=()=>list.filter(s=>['queued','preparing','uploading','retrying'].includes(s.phase)).forEach(cancel);
   }
   if(actions){
     const failed=list.filter(s=>s.phase==='error'||s.phase==='cancelled').length;
     const cancellable=list.filter(s=>['queued','preparing','uploading','retrying'].includes(s.phase)).length;
     actions.hidden=!list.length;actions.querySelector('.media-retry-all').disabled=!failed;actions.querySelector('.media-cancel-all').disabled=!cancellable;actions.querySelector('.media-pause-selected').disabled=!list.some(s=>s.card.querySelector('.media-upload-check')?.checked&&['queued','preparing','uploading','retrying'].includes(s.phase));actions.querySelector('.media-resume-selected').disabled=!list.some(s=>s.card.querySelector('.media-upload-check')?.checked&&s.phase==='paused');actions.querySelector('.media-remove-selected').disabled=!list.some(s=>s.card.querySelector('.media-upload-check')?.checked);
   }
 }
 function fileTypeIcon(f){const n=String(f.name||'').toLowerCase(),m=String(f.type||'').toLowerCase();if(m.startsWith('image/'))return '🖼️ Image';if(m.startsWith('video/'))return '🎬 Video';if(m.startsWith('audio/'))return '🎵 Audio';if(/\.(zip|rar|7z|tar|gz|bz2)$/.test(n))return '🗜️ Archive';if(/\.(pdf|docx?|xlsx?|pptx?|txt|csv|json|md)$/.test(n)||m.includes('document')||m==='application/pdf')return '📄 Document';return '📁 File'}
 function card(f){
   const d=document.createElement('div');d.className='upload-card card';
   d.innerHTML='<div class="upload-head"><label><input type="checkbox" class="media-upload-check" aria-label="Select upload"></label><span class="upload-type-icon">'+esc(fileTypeIcon(f))+'</span><div class="upload-title-wrap"><b class="upload-name"></b><span class="upload-path"></span></div><span class="status">Queued…</span></div>'+
     '<div class="media-upload-size"><span>Upload size</span><strong class="upload-size">'+esc(bytes(f.size))+'</strong></div>'+
     '<div class="upload-progress-track"><i></i></div>'+
     '<div class="upload-metrics"><span class="upload-bytes">0 B / '+esc(bytes(f.size))+'</span><span class="upload-percent">0% / 100%</span><span class="upload-speed">—</span><span class="upload-eta">Calculating…</span></div><div class="upload-actions"></div>';
   d.querySelector('.upload-name').textContent=f.name;d.querySelector('.upload-path').textContent=f.webkitRelativePath||'';q.appendChild(d);return d;
 }
 function setStatus(s,text){s.card.querySelector('.status').textContent=text;s.card.dataset.state=s.phase}
 function updateCard(s){
   const now=performance.now(),uploaded=Math.min(s.total,Math.max(0,s.uploaded));
   const dt=Math.max(.001,(now-s.speedBaseTime)/1000),db=uploaded-s.speedBaseBytes;
   if(db>0)s.speed=db/dt;s.lastSpeed=s.speed||s.lastSpeed||0;
   if(now-(s.lastProgressAt||now)>2000)s.lastSpeed=0;
   const pct=s.total?Math.min(100,uploaded/s.total*100):0,eta=s.lastSpeed>0?(s.total-uploaded)/s.lastSpeed:Infinity;
   s.card.querySelector('.upload-progress-track i').style.width=pct.toFixed(2)+'%';
   s.card.querySelector('.upload-bytes').textContent=bytes(uploaded)+' / '+bytes(s.total);
   s.card.querySelector('.upload-percent').textContent=pct.toFixed(pct<10?1:0)+'% / 100%';
   s.card.querySelector('.upload-speed').textContent='Network speed: '+speedText(s.lastSpeed);
   s.card.querySelector('.upload-eta').textContent='ETA: '+(uploaded>=s.total?'Complete':etaText(eta));
   s.card.querySelector('.upload-size').textContent=bytes(s.total);
   if(now-s.speedBaseTime>=400){s.speedBaseBytes=uploaded;s.speedBaseTime=now}
   updateMetrics();
 }
 function actions(s,mode){
   const box=s.card.querySelector('.upload-actions');
   if(mode==='cancel')box.innerHTML='<button type="button" class="btn small secondary upload-pause">Pause</button><button type="button" class="btn small secondary upload-cancel">Cancel</button>';
   else if(mode==='paused')box.innerHTML='<button type="button" class="btn small upload-resume">Resume</button><button type="button" class="btn small secondary upload-cancel">Cancel</button>';
   else if(mode==='retry')box.innerHTML='<button type="button" class="btn small upload-retry">Retry upload</button>';
   else if(mode==='done')box.innerHTML='<span class="upload-complete-badge">✓ Uploaded</span>';
   else box.innerHTML='';
   box.querySelector('.upload-cancel')?.addEventListener('click',()=>cancel(s));
   box.querySelector('.upload-pause')?.addEventListener('click',()=>pause(s));
   box.querySelector('.upload-resume')?.addEventListener('click',()=>resume(s));
   box.querySelector('.upload-retry')?.addEventListener('click',()=>enqueue(s,true));
 }
 async function json(r){const text=await r.text();let j={};try{j=JSON.parse(text)}catch(e){}if(!r.ok||j.ok===false)throw Error(j.error||('Upload failed (HTTP '+r.status+')')+(j.request_id?' ['+j.request_id+']':''));return j}
 async function post(fd){return json(await fetch('/api/upload-chunk.php',{method:'POST',body:fd,credentials:'same-origin',headers:{Accept:'application/json'}}))}
 async function api(action,data={}){const fd=new FormData();fd.append('_csrf',csrf);fd.append('action',action);Object.entries(data).forEach(([k,v])=>fd.append(k,String(v)));return post(fd)}
 function xhrChunk(s,offset,chunkFile){
   return new Promise((resolve,reject)=>{
     const xhr=new XMLHttpRequest();s.xhr=xhr;let settled=false,started=performance.now();
     const finish=(fn,v)=>{if(settled)return;settled=true;if(s.xhr===xhr)s.xhr=null;fn(v)};
     xhr.open('POST','/api/upload-chunk.php',true);xhr.setRequestHeader('Accept','application/json');
     const fd=new FormData();fd.append('_csrf',csrf);fd.append('action','chunk');fd.append('token',s.token);fd.append('offset',String(offset));fd.append('chunk',chunkFile,s.file.name+'.part');
     xhr.upload.onprogress=e=>{if(!e.lengthComputable)return;const now=performance.now(),elapsed=Math.max(.001,(now-started)/1000);s.uploaded=Math.min(s.total,offset+e.loaded);s.lastSpeed=e.loaded/elapsed;s.lastProgressAt=now;updateCard(s)};
     xhr.onload=()=>{let j={};try{j=xhr.responseText?JSON.parse(xhr.responseText):{}}catch(e){}if(xhr.status>=200&&xhr.status<300&&j.ok!==false)return finish(resolve,j);finish(reject,Error(j.error||('Upload failed (HTTP '+xhr.status+')')+(j.request_id?' ['+j.request_id+']':'')))};
     xhr.onerror=()=>finish(reject,Error('Network error while uploading.'));xhr.ontimeout=()=>finish(reject,Error('Upload request timed out. Check the network connection and retry.'));xhr.onabort=()=>finish(reject,Error(s.cancelled?'Upload cancelled.':'Upload aborted.'));xhr.timeout=0;xhr.send(fd);
   });
 }
 async function initSession(s,folder){if(s.token)return {token:s.token,chunk_size:s.chunkSize,name:s.name};const x=await api('init',{scope:'media',context_id:0,name:s.file.name,size:s.file.size,mime:s.file.type||'application/octet-stream',relative_path:s.file.webkitRelativePath||s.file.name,folder});s.token=x.token;s.chunkSize=Math.max(131072,Math.min(5*1024*1024,Number(x.chunk_size||262144)));s.name=x.name||s.file.name;s.card.querySelector('.upload-name').textContent=s.name;return x}
 async function abortSession(token){if(!token)return;try{await api('abort',{token})}catch(e){}}
 async function chunkUpload(s,folder){
   await initSession(s,folder);let offset=0,chunk=s.chunkSize;
   if(s.cancelled||s.removed)throw Error('Upload cancelled.');
   const st=await api('status',{token:s.token});offset=Number(st.received||0);s.uploaded=offset;updateCard(s);
   while(offset<s.total){if(s.cancelled||s.removed)throw Error('Upload cancelled.');if(s.paused)throw Error('Upload paused.');const end=Math.min(s.total,offset+chunk);let result=null,last=null;
     for(let attempt=0;attempt<3;attempt++){
       try{result=await xhrChunk(s,offset,s.file.slice(offset,end,s.file.type||'application/octet-stream'));last=null;break}
       catch(e){last=e;if(s.cancelled||s.paused||s.removed)throw e;try{const probe=await api('status',{token:s.token});const received=Number(probe.received||0);if(received>offset){offset=Math.min(s.total,received);s.uploaded=offset;updateCard(s);last=null;break}}catch(_e){}if(attempt<2)await new Promise(r=>setTimeout(r,Math.min(2000,500*(attempt+1))))}
     }
     if(last)throw last;if(!result)continue;const next=Number(result.received||end);if(next<=offset)throw Error('Upload made no progress. Please retry.');offset=next;s.uploaded=offset;updateCard(s);setStatus(s,'Uploading '+Math.round(offset/s.total*100)+'%');
   }
   return api('complete',{token:s.token,folder});
 }
 async function run(s,retry=false){
   if(s.running||s.removed||s.phase==='paused')return;s.running=true;s.cancelled=false;s.phase=retry?'retrying':'preparing';s.error='';s.card.classList.remove('upload-error','upload-success');actions(s,'cancel');
   if(!retry){s.uploaded=0;s.startedAt=performance.now()}s.speedBaseTime=performance.now();s.speedBaseBytes=s.uploaded;s.lastProgressAt=performance.now();s.lastSpeed=0;setStatus(s,retry?'Retrying upload…':'Preparing…');updateCard(s);
   try{const result=await chunkUpload(s,form.querySelector('[name="folder"]')?.value||'General');if(s.removed)return;s.uploaded=s.total;s.phase='done';s.retryCount=0;clearTimeout(s.retryTimer);updateCard(s);setStatus(s,'Uploaded successfully');s.card.classList.add('upload-success');actions(s,'done');insertMediaAsset(result,s);toast('Upload complete: '+(result.name||s.file.name))}
   catch(err){if(s.removed)return;if(s.paused){s.phase='paused';setStatus(s,'Paused');actions(s,'paused')}else if(s.cancelled){s.phase='cancelled';setStatus(s,'Cancelled');actions(s,'retry')}else if(isMissing(err)){markMissing(s,err)}else if(isTemporary(err)){scheduleRetry(s,err)}else{s.phase='error';s.error=err.message||'Upload failed.';s.card.classList.add('upload-error');setStatus(s,s.error);actions(s,'retry')}}
   finally{s.running=false;active=Math.max(0,active-1);pump();updateMetrics()}
 }
 function enqueue(s,retry=false){if(s.phase==='done'||s.running||s.removed)return;clearTimeout(s.retryTimer);s.paused=false;s.cancelled=false;s.retryRequested=retry;s.phase='queued';s.card.classList.remove('upload-error');setStatus(s,retry?'Queued for retry…':'Queued…');actions(s,'cancel');pump();updateMetrics()}
 function cancel(s){if(s.phase==='done'||s.phase==='cancelled'||s.removed)return;s.cancelled=true;clearTimeout(s.retryTimer);setStatus(s,'Cancelling…');try{s.xhr?.abort()}catch(e){}s.phase='cancelled';setStatus(s,'Cancelled');actions(s,'retry');updateMetrics()}
 function removeUpload(s){if(!s||s.removed)return;s.removed=true;s.cancelled=true;clearTimeout(s.retryTimer);try{s.xhr?.abort()}catch(e){}if(s.token)abortSession(s.token);states.delete(s.id);s.card.remove();fs=fs.filter(f=>f!==s.file);sync();updateMetrics();pump()}
 function pause(s){if(!s||s.removed||!['queued','preparing','uploading','retrying'].includes(s.phase))return;s.paused=true;s.phase='paused';clearTimeout(s.retryTimer);setStatus(s,'Paused');try{s.xhr?.abort()}catch(e){}actions(s,'paused');updateMetrics()}
 function resume(s){if(!s||s.phase!=='paused'||s.removed)return;s.paused=false;enqueue(s,true)}
 function isMissing(e){return /file not found|file is not readable|invalidstateerror|could not read|source file unavailable/i.test(String(e?.message||''))}
 function markMissing(s,e){s.phase='missing';s.error=e?.message||'Local file unavailable';s.card.classList.add('upload-error');setStatus(s,'File Missing');let w=s.card.querySelector('.upload-missing-warning');if(!w){w=document.createElement('div');w.className='upload-missing-warning';w.setAttribute('role','alert');s.card.querySelector('.upload-metrics').after(w)}w.textContent='File Not Found: This file is no longer readable from the selected local source. Re-select the original file to continue.';const a=s.card.querySelector('.upload-actions');a.innerHTML='<button type="button" class="btn small upload-reselect">Re-select File</button><button type="button" class="btn small secondary upload-cancel">Cancel</button>';let input=s.card.querySelector('input.upload-reselect-input');if(!input){input=document.createElement('input');input.type='file';input.hidden=true;input.className='upload-reselect-input';input.setAttribute('aria-label','Re-select '+s.file.name);s.card.appendChild(input)}a.querySelector('.upload-reselect').onclick=()=>input.click();a.querySelector('.upload-cancel').onclick=()=>cancel(s);input.onchange=()=>{const f=input.files?.[0];if(!f)return;if(f.name!==s.file.name||f.size!==s.total){w.textContent='Selected file does not match the original filename and size. Choose the original file.';return}s.file=f;s.cancelled=false;s.paused=false;w.remove();enqueue(s,true)}}
 function isTemporary(e){const m=String(e?.message||'').toLowerCase();return !navigator.onLine||/network|timeout|timed out|http 429|http 5\d\d|server error 429|server error 5\d\d|failed to fetch|upload aborted|no progress/i.test(m)}
 function scheduleRetry(s,e){if(s.removed||s.cancelled||s.paused)return;s.retryCount=(s.retryCount||0)+1;const delay=retryDelays[Math.min(s.retryCount-1,retryDelays.length-1)];s.phase=navigator.onLine?'retrying':'waiting-network';setStatus(s,navigator.onLine?'Retrying automatically in '+Math.ceil(delay/1000)+'s':'Waiting for Network');s.card.classList.add('upload-error');const a=s.card.querySelector('.upload-actions');a.innerHTML='<button type="button" class="btn small secondary upload-cancel">Cancel</button>';a.querySelector('.upload-cancel').onclick=()=>cancel(s);s.retryTimer=setTimeout(()=>{if(s.removed||s.cancelled||s.paused)return;if(!navigator.onLine){s.phase='waiting-network';setStatus(s,'Waiting for Network');scheduleRetry(s,e);return;}enqueue(s,true)},delay);updateMetrics()}
 window.addEventListener('online',()=>[...states.values()].filter(s=>s.phase==='waiting-network'&&!s.retryTimer).forEach(s=>scheduleRetry(s,Error('Network restored'))));
 function insertMediaAsset(r,s){const grid=document.getElementById('media-grid');if(!grid||!r||!r.id||document.getElementById('media-'+r.id))return;const kind=r.kind||'file',url=r.url||'';const card=document.createElement('article');card.className='media-card';card.id='media-'+r.id;card.dataset.kind=kind;card.dataset.created=new Date().toISOString();const preview=kind==='image'?'<img loading="lazy" data-preview-url="'+esc(url)+'" src="'+esc(url)+'" alt="">':kind==='video'?'<video controls preload="metadata" src="'+esc(url)+'"></video>':kind==='audio'?'<audio controls preload="metadata" src="'+esc(url)+'"></audio>':'<div class="file-icon">'+(kind==='archive'?'🗜️':'📄')+'</div>';card.innerHTML='<div class="media-select"><input class="media-check" type="checkbox" name="ids[]" value="'+Number(r.id)+'" data-url="'+esc(url)+'" aria-label="Select '+esc(r.name||s.file.name)+'"></div><div class="media-preview" data-preview-kind="'+esc(kind)+'">'+preview+'</div><div class="media-card-body"><div class="media-title-row"><strong title="'+esc(r.name||s.file.name)+'">'+esc(r.name||s.file.name)+'</strong></div><small>Media Assets · '+esc(r.folder||'General')+' · '+esc(kind.toUpperCase())+' · '+esc(bytes(s.total))+'</small><div class="media-actions"><button class="edit-btn" type="button" data-copy-url="'+esc(url)+'">Copy URL</button><a class="edit-btn" href="'+esc(url)+'" target="_blank" rel="noopener" download>Download</a>'+(['image','video','audio'].includes(kind)?'<button class="edit-btn" type="button" data-open-preview data-url="'+esc(url)+'" data-name="'+esc(r.name||s.file.name)+'" data-mime="'+esc(s.file.type||'')+'">Preview</button>':'')+'</div></div>';const search=new URLSearchParams(location.search),qText=(search.get('q')||'').toLowerCase(),k=search.get('kind')||'',folder=search.get('folder')||'';if((qText&&!String(r.name||s.file.name).toLowerCase().includes(qText))||(k&&k!==kind)||(folder&&(r.folder||'General')!==folder))card.hidden=true;const empty=grid.querySelector('.card p.muted');if(empty)empty.closest('.card')?.remove();grid.prepend(card);card.querySelectorAll('[data-copy-url]').forEach(b=>b.addEventListener('click',async()=>{try{await navigator.clipboard.writeText(url);b.textContent='Copied'}catch(_){}}));card.querySelector('[data-open-preview]')?.addEventListener('click',b=>{const el=b.currentTarget;if(window.openMediaViewer)window.openMediaViewer(url,r.name||s.file.name,s.file.type||'');else window.open(url,'_blank','noopener')});const stats=document.querySelectorAll('.media-stats .card b');if(stats[0])stats[0].textContent=String((parseInt(stats[0].textContent,10)||0)+1);if(stats[1]&&kind==='image')stats[1].textContent=String((parseInt(stats[1].textContent,10)||0)+1);if(stats[2]&&['audio','video'].includes(kind))stats[2].textContent=String((parseInt(stats[2].textContent,10)||0)+1);}
 function makeState(f){const s={id:'mu-'+Date.now()+'-'+Math.random().toString(36).slice(2),file:f,total:Number(f.size),uploaded:0,phase:'queued',card:null,running:false,cancelled:false,paused:false,removed:false,token:'',chunkSize:262144,speed:0,lastSpeed:0,speedBaseBytes:0,speedBaseTime:performance.now(),startedAt:performance.now(),lastProgressAt:performance.now(),error:'',retryRequested:false,retryCount:0,retryTimer:0};s.card=card(f);states.set(s.id,s);setStatus(s,'Queued…');actions(s,'cancel');return s}
 function pump(){while(active<MAX_CONCURRENT){const next=[...states.values()].find(s=>s.phase==='queued'&&!s.running);if(!next)break;active++;run(next,!!next.retryRequested)}updateMetrics()}
 function add(list){const files=[...list].filter(f=>f&&Number(f.size)>0);files.forEach(f=>{fs.push(f);makeState(f)});pickerValueReset();sync();updateMetrics()}
 function pickerValueReset(){try{p.value=''}catch(e){}}
 p.addEventListener('change',()=>add(p.files));folderPicker?.addEventListener('change',()=>{add(folderPicker.files);folderPicker.value=''})
 chooseFolder?.addEventListener('click',()=>folderPicker?.click());
 ['dragenter','dragover'].forEach(ev=>drop?.addEventListener(ev,e=>{e.preventDefault();drop.classList.add('drag')}));['dragleave','drop'].forEach(ev=>drop?.addEventListener(ev,e=>{e.preventDefault();drop.classList.remove('drag')}));
 async function droppedFiles(dt){const direct=[...(dt?.files||[])],items=[...(dt?.items||[])];if(!items.length)return direct;const out=[];async function walk(entry,path=''){if(!entry)return;if(entry.isFile){await new Promise(resolve=>entry.file(f=>{try{Object.defineProperty(f,'webkitRelativePath',{value:path+f.name,configurable:true})}catch(e){}out.push(f);resolve()},resolve));return}if(entry.isDirectory){const reader=entry.createReader();await new Promise(resolve=>{const read=()=>reader.readEntries(async entries=>{if(!entries.length)return resolve();for(const child of entries)await walk(child,path+entry.name+'/');read()},resolve);read()})}}for(const item of items){const entry=item.webkitGetAsEntry?.();if(entry)await walk(entry);else{const f=item.getAsFile?.();if(f)out.push(f)}}return out.length?out:direct}
 drop?.addEventListener('drop',async e=>add(await droppedFiles(e.dataTransfer)));
 form.addEventListener('submit',e=>{e.preventDefault();if(!fs.length){toast('Choose at least one file or folder.');return}if(![...states.values()].length)fs.forEach(makeState);submit.disabled=true;submit.textContent='Uploading…';pump();const watch=()=>{const active=[...states.values()].some(s=>['queued','preparing','uploading','retrying'].includes(s.phase));if(!active){submit.disabled=false;submit.textContent='Upload selected';return}setTimeout(watch,250)};watch()});
 // Existing media controls
 document.querySelectorAll('[data-delete-media]').forEach(b=>b.addEventListener('click',()=>{if(!confirm('Delete this media item?'))return;const f=document.createElement('form');f.method='post';f.style.display='none';f.innerHTML='<?=csrf_field()?>'+'<input type="hidden" name="action" value="delete">'+'<input type="hidden" name="id" value="'+b.dataset.deleteMedia+'">';document.body.appendChild(f);f.submit()}));
 document.querySelectorAll('[data-copy-url]').forEach(b=>b.addEventListener('click',async()=>{const url=b.dataset.copyUrl;try{await navigator.clipboard.writeText(url);b.textContent='Copied';setTimeout(()=>b.textContent='Copy URL',1200)}catch(e){window.prompt('Copy public URL',url)}}));
 const all=document.getElementById('selectAll');
 all?.addEventListener('change',()=>document.querySelectorAll('.media-check').forEach(x=>x.checked=all.checked));
 document.getElementById('copySelected')?.addEventListener('click',async()=>{const urls=[...document.querySelectorAll('.media-check')].filter(x=>x.checked).map(x=>x.dataset.url);if(!urls.length){toast('Select at least one media item.');return}const text=urls.join('\n');try{await navigator.clipboard.writeText(text);toast(urls.length+' URL(s) copied.')}catch(e){window.prompt('Copy selected URLs',text)}});
 const modal=document.getElementById('mediaModal'),body=document.getElementById('mediaModalBody');
 document.querySelectorAll('[data-open-preview]').forEach(btn=>btn.addEventListener('click',()=>{const card=btn.closest('.media-card'),src=btn.dataset.url||card.querySelector('[data-preview-url]')?.dataset.previewUrl||card.querySelector('video,audio')?.src;if(!src)return;if(window.openMediaViewer){window.openMediaViewer(src,btn.dataset.name||card.querySelector('.media-title-row strong')?.textContent||'Media',btn.dataset.mime||'')}else{window.open(src,'_blank','noopener')}}));
 document.querySelectorAll('[data-open-edit]').forEach(b=>b.addEventListener('click',()=>{b.closest('.media-card')?.querySelector('.media-edit')?.setAttribute('open','')}));
 document.querySelectorAll('[data-close-media]').forEach(x=>x.onclick=()=>{modal.hidden=true;body.innerHTML=''});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&modal&&!modal.hidden){modal.hidden=true;body.innerHTML=''}});
})();
</script>
<script src="/assets/js/universal-media-viewer.js?v=18.0" defer></script><script src="/assets/js/bulk-selection-v18.js?v=18.1" defer></script><script src="/assets/js/file-organization-v18.2.js?v=18.2" defer></script><?php require __DIR__.'/../includes/footer.php';
