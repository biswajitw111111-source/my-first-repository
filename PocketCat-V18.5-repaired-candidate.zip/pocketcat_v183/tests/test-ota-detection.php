<?php
declare(strict_types=1);
require __DIR__.'/../includes/path-resolver.php';
require __DIR__.'/../includes/ota-updater.php';
$tests=0;$failed=0;
$check=function(string $name,callable $fn)use(&$tests,&$failed):void{try{$fn();$tests++;echo "PASS $name\n";}catch(Throwable $e){$failed++;echo "FAIL $name: {$e->getMessage()}\n";}};
$tmp=sys_get_temp_dir().'/pc-ota-test-'.bin2hex(random_bytes(5));mkdir($tmp,0700);
try{
 $zip=$tmp.'/sig.zip';file_put_contents($zip,"PK\x03\x04".str_repeat("\0",32));$check('ZIP signature detection',fn()=>PocketCatUpdater::detect($zip)==='zip'||throw new RuntimeException('Wrong format'));
 $tarBytes=str_repeat("\0",512);$tarBytes=substr_replace($tarBytes,'fixture.txt',0,11);$tarBytes=substr_replace($tarBytes,'ustar',257,5);$tar=$tmp.'/fixture.tar';file_put_contents($tar,$tarBytes);$check('TAR signature detection',fn()=>PocketCatUpdater::detect($tar)==='tar'||throw new RuntimeException('Wrong format'));
 if(function_exists('gzencode')){$gz=$tmp.'/fixture.gz';file_put_contents($gz,gzencode($tarBytes));$check('TAR.GZ inner TAR detection',fn()=>PocketCatUpdater::detect($gz)==='tar.gz'||throw new RuntimeException('Wrong format'));}
 $check('archive traversal path rejected',function(){try{PocketCatUpdater::validateArchivePath('../escape.php');throw new RuntimeException('Traversal accepted');}catch(RuntimeException $e){if($e->getMessage()==='Traversal accepted')throw $e;}});
 $check('absolute archive path rejected',function(){try{PocketCatUpdater::validateArchivePath('/etc/passwd');throw new RuntimeException('Absolute path accepted');}catch(RuntimeException $e){if($e->getMessage()==='Absolute path accepted')throw $e;}});
 $seven=$tmp.'/seven';file_put_contents($seven,"7z\xBC\xAF\x27\x1C".str_repeat("\0",16));$check('7Z signature detection',fn()=>PocketCatUpdater::detect($seven)==='7z'||throw new RuntimeException('Wrong format'));
 $rar=$tmp.'/rar';file_put_contents($rar,"Rar!\x1A\x07\x01\x00".str_repeat("\0",16));$check('RAR signature detection',fn()=>PocketCatUpdater::detect($rar)==='rar'||throw new RuntimeException('Wrong format'));
 $gzip=$tmp.'/gzip';file_put_contents($gzip,gzencode('standalone payload'));$check('standalone GZ signature detection',fn()=>PocketCatUpdater::detect($gzip)==='gz'||throw new RuntimeException('Wrong format'));
 $bz=$tmp.'/bz2';file_put_contents($bz,'BZh9'.str_repeat("\0",16));$check('BZ2 signature detection',fn()=>PocketCatUpdater::detect($bz)==='bz2'||throw new RuntimeException('Wrong format'));
 $xz=$tmp.'/xz';file_put_contents($xz,"\xFD7zXZ\x00".str_repeat("\0",16));$check('XZ signature detection',fn()=>PocketCatUpdater::detect($xz)==='xz'||throw new RuntimeException('Wrong format'));
 $unknown=$tmp.'/unknown';file_put_contents($unknown,'not an archive');$check('Unknown signatures rejected',function()use($unknown){try{PocketCatUpdater::detect($unknown);throw new RuntimeException('Unknown format accepted');}catch(RuntimeException $e){if($e->getMessage()==='Unknown format accepted')throw $e;}});
} finally {foreach(glob($tmp.'/*')?:[] as $f)@unlink($f);@rmdir($tmp);}
echo "RESULT passed=$tests failed=$failed\n";exit($failed?1:0);
