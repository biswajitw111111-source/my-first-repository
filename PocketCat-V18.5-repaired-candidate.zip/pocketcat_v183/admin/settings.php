<?php
require __DIR__.'/../bootstrap.php';require_admin();
if($_SERVER['REQUEST_METHOD']==='POST'){
 verify_csrf();
 if(post('action')==='reset'){
  set_setting('app_name','PocketCat');set_setting('app_url','https://pocketcat.online');set_setting('site_meta_description','PocketCat productivity workspace');set_setting('redirect_brand_transition','0');
  flash('success','Site settings restored to defaults.');redirect('/admin/settings/');
 }
 set_setting('app_name',trim((string)post('app_name','PocketCat')));
 set_setting('app_url',rtrim(trim((string)post('app_url','https://pocketcat.online')),'/'));
 set_setting('redirect_brand_transition',post('redirect_brand_transition')==='1'?'1':'0');
 flash('success','Site settings saved.');redirect('/admin/settings/');
}
$title='Site Settings';require __DIR__.'/../includes/header.php';
?>
<div class="page-head"><div><span class="eyebrow">Administration</span><h1>Site settings</h1><p>Core public-facing configuration and redirect presentation.</p></div></div>
<p><a class="btn secondary small" href="/admin/site-editor/">Open Live Site Editor</a></p>
<form class="card form-card" id="website-name" method="post"><?=csrf_field()?>
<label data-help-key="core-site">Website Name<input name="app_name" value="<?=e(setting('app_name','PocketCat'))?>" required></label>
<label id="website-url" data-help-key="core-site">Website URL<input name="app_url" value="<?=e(setting('app_url','https://pocketcat.online'))?>" required></label>
<hr>
<h2>Short-link redirect transition</h2>
<p class="muted">Default is Off. When enabled, intermediate redirect screens can briefly show your PocketCat brand before the visitor is sent to the destination. The page has no manual “Continue” link.</p>
<label class="check redirect-toggle"><input type="checkbox" name="redirect_brand_transition" value="1" <?=setting('redirect_brand_transition','0')==='1'?'checked':''?>> <span>Show PocketCat brand briefly during intermediate redirects</span></label>
<div class="settings-actions"><button class="btn" type="submit">Save Site Settings</button></div>
</form>
<form class="card form-card settings-reset" method="post" onsubmit="return confirm('Reset core site settings?')"><?=csrf_field()?><input type="hidden" name="action" value="reset"><button class="btn danger small">Reset to Default</button></form>
<?php require __DIR__.'/../includes/footer.php'; ?>