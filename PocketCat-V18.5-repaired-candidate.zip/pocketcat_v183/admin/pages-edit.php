<?php $_GET['type']='page'; require __DIR__.'/content-edit.php';
