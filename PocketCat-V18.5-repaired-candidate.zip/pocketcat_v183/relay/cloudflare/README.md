# Cloudflare Worker files

Deploy `worker.js` as a Cloudflare Worker. Use the included `wrangler.toml` if deploying with Wrangler.

Secrets:
- `BEDROCK_API_KEY`
- `RELAY_TOKEN`

Variables:
- `BEDROCK_REGION`
- `BEDROCK_MODEL_ID`
